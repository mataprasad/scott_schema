﻿// Decompiled with JetBrains decompiler
// Type: Elmah.ErrorSignalEventArgs
// Assembly: Elmah, Version=1.2.14706.0, Culture=neutral, PublicKeyToken=null
// MVID: 6B433430-60BC-4287-8770-D3B3555B0D2B
// Assembly location: D:\Mata\transport-corp\trans-corp\transport-corp\App\Bin\Elmah.dll

using System;
using System.Web;

namespace Elmah
{
  [Serializable]
  public sealed class ErrorSignalEventArgs : EventArgs
  {
    private readonly Exception _exception;
    [NonSerialized]
    private readonly HttpContext _context;

    public Exception Exception
    {
      get
      {
        return this._exception;
      }
    }

    public HttpContext Context
    {
      get
      {
        return this._context;
      }
    }

    public ErrorSignalEventArgs(Exception e, HttpContext context)
    {
      if (e == null)
        throw new ArgumentNullException("e");
      this._exception = e;
      this._context = context;
    }

    public override string ToString()
    {
      return Mask.EmptyString(this.Exception.Message, this.Exception.GetType().FullName);
    }
  }
}
