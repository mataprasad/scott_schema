﻿// Decompiled with JetBrains decompiler
// Type: Elmah.ConfigurationSectionHelper
// Assembly: Elmah, Version=1.2.14706.0, Culture=neutral, PublicKeyToken=null
// MVID: 6B433430-60BC-4287-8770-D3B3555B0D2B
// Assembly location: D:\Mata\transport-corp\trans-corp\transport-corp\App\Bin\Elmah.dll

using System;
using System.Configuration;
using System.Xml;

namespace Elmah
{
  internal sealed class ConfigurationSectionHelper
  {
    private ConfigurationSectionHelper()
    {
      throw new NotSupportedException();
    }

    public static string GetValueAsString(XmlAttribute attribute)
    {
      return ConfigurationSectionHelper.GetValueAsString(attribute, string.Empty);
    }

    public static string GetValueAsString(XmlAttribute attribute, string defaultValue)
    {
      if (attribute == null)
        return defaultValue;
      return Mask.EmptyString(attribute.Value, defaultValue);
    }

    public static bool GetValueAsBoolean(XmlAttribute attribute)
    {
      if (attribute == null)
        return false;
      try
      {
        return XmlConvert.ToBoolean(attribute.Value);
      }
      catch (FormatException ex)
      {
        throw new ConfigurationException(string.Format("Error in parsing the '{0}' attribute of the '{1}' element as a boolean value. Use either 1, 0, true or false (latter two being case-sensitive).", (object) attribute.Name, (object) attribute.OwnerElement.Name), (Exception) ex, (XmlNode) attribute);
      }
    }
  }
}
