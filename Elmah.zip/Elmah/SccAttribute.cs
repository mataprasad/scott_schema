﻿// Decompiled with JetBrains decompiler
// Type: Elmah.SccAttribute
// Assembly: Elmah, Version=1.2.14706.0, Culture=neutral, PublicKeyToken=null
// MVID: 6B433430-60BC-4287-8770-D3B3555B0D2B
// Assembly location: D:\Mata\transport-corp\trans-corp\transport-corp\App\Bin\Elmah.dll

using System;

namespace Elmah
{
  [AttributeUsage(AttributeTargets.Assembly | AttributeTargets.Class, AllowMultiple = true)]
  [Serializable]
  public sealed class SccAttribute : Attribute
  {
    private string _id;

    public string Id
    {
      get
      {
        return Mask.NullString(this._id);
      }
      set
      {
        this._id = value;
      }
    }

    public SccAttribute(string id)
    {
      this._id = id;
    }

    public override string ToString()
    {
      return this.Id;
    }
  }
}
