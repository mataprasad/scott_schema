﻿// Decompiled with JetBrains decompiler
// Type: Elmah.ConnectionStringHelper
// Assembly: Elmah, Version=1.2.14706.0, Culture=neutral, PublicKeyToken=null
// MVID: 6B433430-60BC-4287-8770-D3B3555B0D2B
// Assembly location: D:\Mata\transport-corp\trans-corp\transport-corp\App\Bin\Elmah.dll

using System;
using System.Collections;
using System.Configuration;
using System.Data.Common;
using System.IO;
using System.Runtime.CompilerServices;
using System.Web.Hosting;

namespace Elmah
{
  internal class ConnectionStringHelper
  {
    private static readonly char[] _dirSeparators = new char[1]
    {
      Path.DirectorySeparatorChar
    };

    private ConnectionStringHelper()
    {
    }

    public static string GetConnectionString(IDictionary config)
    {
      string index1 = (string) config[(object) "connectionStringName"] ?? string.Empty;
      if (index1.Length > 0)
      {
        ConnectionStringSettings connectionString = ConfigurationManager.ConnectionStrings[index1];
        if (connectionString == null)
          return string.Empty;
        return connectionString.ConnectionString ?? string.Empty;
      }
      string str = Mask.NullString((string) config[(object) "connectionString"]);
      if (str.Length > 0)
        return str;
      string index2 = Mask.NullString((string) config[(object) "connectionStringAppKey"]);
      if (index2.Length == 0)
        return string.Empty;
      return Elmah.Configuration.AppSettings[index2];
    }

    public static string GetDataSourceFilePath(string connectionString)
    {
      return ConnectionStringHelper.GetDataSourceFilePath(new DbConnectionStringBuilder(), connectionString);
    }

    public static string GetConnectionString(IDictionary config, bool resolveDataSource)
    {
      string connectionString = ConnectionStringHelper.GetConnectionString(config);
      if (!resolveDataSource)
        return connectionString;
      return ConnectionStringHelper.GetResolvedConnectionString(connectionString);
    }

    public static string GetResolvedConnectionString(string connectionString)
    {
      DbConnectionStringBuilder builder = new DbConnectionStringBuilder();
      builder["Data Source"] = (object) ConnectionStringHelper.GetDataSourceFilePath(builder, connectionString);
      return builder.ToString();
    }

    [MethodImpl(MethodImplOptions.NoInlining)]
    private static string MapPath(string path)
    {
      return HostingEnvironment.MapPath(path);
    }

    private static string GetDataSourceFilePath(DbConnectionStringBuilder builder, string connectionString)
    {
      builder.ConnectionString = connectionString;
      if (!builder.ContainsKey("Data Source"))
        throw new ArgumentException("A 'Data Source' parameter was expected in the supplied connection string, but it was not found.");
      return ConnectionStringHelper.ResolveDataSourceFilePath(builder["Data Source"].ToString());
    }

    private static string ResolveDataSourceFilePath(string path)
    {
      if (path.StartsWith("~/"))
        return ConnectionStringHelper.MapPath(path);
      if (!path.StartsWith("|DataDirectory|", StringComparison.OrdinalIgnoreCase))
        return path;
      string s = AppDomain.CurrentDomain.GetData("DataDirectory") as string;
      if (string.IsNullOrEmpty(s))
        s = AppDomain.CurrentDomain.BaseDirectory;
      return Mask.NullString(s).TrimEnd(ConnectionStringHelper._dirSeparators) + (object) Path.DirectorySeparatorChar + path.Substring("|DataDirectory|".Length).TrimStart(ConnectionStringHelper._dirSeparators);
    }
  }
}
