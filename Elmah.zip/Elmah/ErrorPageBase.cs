﻿// Decompiled with JetBrains decompiler
// Type: Elmah.ErrorPageBase
// Assembly: Elmah, Version=1.2.14706.0, Culture=neutral, PublicKeyToken=null
// MVID: 6B433430-60BC-4287-8770-D3B3555B0D2B
// Assembly location: D:\Mata\transport-corp\trans-corp\transport-corp\App\Bin\Elmah.dll

using System;
using System.Globalization;
using System.IO;
using System.Web.UI;

namespace Elmah
{
  internal abstract class ErrorPageBase : Page
  {
    private string _title;
    private ErrorLog _log;

    protected string BasePageName
    {
      get
      {
        return this.Request.ServerVariables["URL"];
      }
    }

    protected virtual ErrorLog ErrorLog
    {
      get
      {
        if (this._log == null)
          this._log = ErrorLog.GetDefault(this.Context);
        return this._log;
      }
    }

    protected virtual string PageTitle
    {
      get
      {
        return Mask.NullString(this._title);
      }
      set
      {
        this._title = value;
      }
    }

    protected virtual string ApplicationName
    {
      get
      {
        return this.ErrorLog.ApplicationName;
      }
    }

    protected virtual void RenderDocumentStart(HtmlTextWriter writer)
    {
      if (writer == null)
        throw new ArgumentNullException("writer");
      writer.WriteLine("<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\">");
      writer.AddAttribute("xmlns", "http://www.w3.org/1999/xhtml");
      writer.RenderBeginTag(HtmlTextWriterTag.Html);
      writer.RenderBeginTag(HtmlTextWriterTag.Head);
      this.RenderHead(writer);
      writer.RenderEndTag();
      writer.WriteLine();
      writer.RenderBeginTag(HtmlTextWriterTag.Body);
    }

    protected virtual void RenderHead(HtmlTextWriter writer)
    {
      writer.AddAttribute("http-equiv", "X-UA-Compatible");
      writer.AddAttribute("content", "IE=EmulateIE7");
      writer.RenderBeginTag(HtmlTextWriterTag.Meta);
      writer.RenderEndTag();
      writer.WriteLine();
      writer.RenderBeginTag(HtmlTextWriterTag.Title);
      this.Server.HtmlEncode(this.PageTitle, (TextWriter) writer);
      writer.RenderEndTag();
      writer.WriteLine();
      writer.AddAttribute(HtmlTextWriterAttribute.Rel, "stylesheet");
      writer.AddAttribute(HtmlTextWriterAttribute.Type, "text/css");
      writer.AddAttribute(HtmlTextWriterAttribute.Href, this.BasePageName + "/stylesheet");
      writer.RenderBeginTag(HtmlTextWriterTag.Link);
      writer.RenderEndTag();
      writer.WriteLine();
    }

    protected virtual void RenderDocumentEnd(HtmlTextWriter writer)
    {
      writer.AddAttribute(HtmlTextWriterAttribute.Id, "Footer");
      writer.RenderBeginTag(HtmlTextWriterTag.P);
      new PoweredBy().RenderControl(writer);
      DateTime now = DateTime.Now;
      writer.Write("Server date is ");
      this.Server.HtmlEncode(now.ToString("D", (IFormatProvider) CultureInfo.InvariantCulture), (TextWriter) writer);
      writer.Write(". Server time is ");
      this.Server.HtmlEncode(now.ToString("T", (IFormatProvider) CultureInfo.InvariantCulture), (TextWriter) writer);
      writer.Write(". All dates and times displayed are in the ");
      writer.Write(TimeZone.CurrentTimeZone.IsDaylightSavingTime(now) ? TimeZone.CurrentTimeZone.DaylightName : TimeZone.CurrentTimeZone.StandardName);
      writer.Write(" zone. ");
      writer.Write("This log is provided by the ");
      this.Server.HtmlEncode(this.ErrorLog.Name, (TextWriter) writer);
      writer.Write('.');
      writer.RenderEndTag();
      writer.RenderEndTag();
      writer.WriteLine();
      writer.RenderEndTag();
      writer.WriteLine();
    }

    protected override void Render(HtmlTextWriter writer)
    {
      this.RenderDocumentStart(writer);
      this.RenderContents(writer);
      this.RenderDocumentEnd(writer);
    }

    protected virtual void RenderContents(HtmlTextWriter writer)
    {
      base.Render(writer);
    }
  }
}
