﻿// Decompiled with JetBrains decompiler
// Type: Elmah.ErrorXml
// Assembly: Elmah, Version=1.2.14706.0, Culture=neutral, PublicKeyToken=null
// MVID: 6B433430-60BC-4287-8770-D3B3555B0D2B
// Assembly location: D:\Mata\transport-corp\trans-corp\transport-corp\App\Bin\Elmah.dll

using System;
using System.Collections.Specialized;
using System.IO;
using System.Xml;

namespace Elmah
{
  [Serializable]
  public sealed class ErrorXml
  {
    private ErrorXml()
    {
      throw new NotSupportedException();
    }

    public static Error DecodeString(string xml)
    {
      using (StringReader stringReader = new StringReader(xml))
      {
        XmlTextReader xmlTextReader = new XmlTextReader((TextReader) stringReader);
        if (!xmlTextReader.IsStartElement("error"))
          throw new ApplicationException("The error XML is not in the expected format.");
        return ErrorXml.Decode((XmlReader) xmlTextReader);
      }
    }

    public static Error Decode(XmlReader reader)
    {
      if (reader == null)
        throw new ArgumentNullException("reader");
      if (!reader.IsStartElement())
        throw new ArgumentException("Reader is not positioned at the start of an element.", "reader");
      Error error = new Error();
      ErrorXml.ReadXmlAttributes(reader, error);
      bool isEmptyElement = reader.IsEmptyElement;
      reader.Read();
      if (!isEmptyElement)
      {
        ErrorXml.ReadInnerXml(reader, error);
        while (reader.NodeType != XmlNodeType.EndElement)
          reader.Skip();
        reader.ReadEndElement();
      }
      return error;
    }

    private static void ReadXmlAttributes(XmlReader reader, Error error)
    {
      if (reader == null)
        throw new ArgumentNullException("reader");
      if (!reader.IsStartElement())
        throw new ArgumentException("Reader is not positioned at the start of an element.", "reader");
      error.ApplicationName = reader.GetAttribute("application");
      error.HostName = reader.GetAttribute("host");
      error.Type = reader.GetAttribute("type");
      error.Message = reader.GetAttribute("message");
      error.Source = reader.GetAttribute("source");
      error.Detail = reader.GetAttribute("detail");
      error.User = reader.GetAttribute("user");
      string s1 = Mask.NullString(reader.GetAttribute("time"));
      error.Time = s1.Length == 0 ? new DateTime() : XmlConvert.ToDateTime(s1);
      string s2 = Mask.NullString(reader.GetAttribute("statusCode"));
      error.StatusCode = s2.Length == 0 ? 0 : XmlConvert.ToInt32(s2);
      error.WebHostHtmlMessage = reader.GetAttribute("webHostHtmlMessage");
    }

    private static void ReadInnerXml(XmlReader reader, Error error)
    {
      if (reader == null)
        throw new ArgumentNullException("reader");
      while (reader.IsStartElement())
      {
        NameValueCollection collection;
        switch (reader.Name)
        {
          case "serverVariables":
            collection = error.ServerVariables;
            break;
          case "queryString":
            collection = error.QueryString;
            break;
          case "form":
            collection = error.Form;
            break;
          case "cookies":
            collection = error.Cookies;
            break;
          default:
            reader.Skip();
            continue;
        }
        if (reader.IsEmptyElement)
          reader.Read();
        else
          ErrorXml.UpcodeTo(reader, collection);
      }
    }

    public static string EncodeString(Error error)
    {
      StringWriter stringWriter = new StringWriter();
      XmlWriter writer = XmlWriter.Create((TextWriter) stringWriter, new XmlWriterSettings() { Indent = true, NewLineOnAttributes = true, CheckCharacters = false, OmitXmlDeclaration = true });
      try
      {
        writer.WriteStartElement("error");
        ErrorXml.Encode(error, writer);
        writer.WriteEndElement();
        writer.Flush();
      }
      finally
      {
        writer.Close();
      }
      return stringWriter.ToString();
    }

    public static void Encode(Error error, XmlWriter writer)
    {
      if (writer == null)
        throw new ArgumentNullException("writer");
      if (writer.WriteState != WriteState.Element)
        throw new ArgumentException("Writer is not in the expected Element state.", "writer");
      ErrorXml.WriteXmlAttributes(error, writer);
      ErrorXml.WriteInnerXml(error, writer);
    }

    private static void WriteXmlAttributes(Error error, XmlWriter writer)
    {
      if (writer == null)
        throw new ArgumentNullException("writer");
      ErrorXml.WriteXmlAttribute(writer, "application", error.ApplicationName);
      ErrorXml.WriteXmlAttribute(writer, "host", error.HostName);
      ErrorXml.WriteXmlAttribute(writer, "type", error.Type);
      ErrorXml.WriteXmlAttribute(writer, "message", error.Message);
      ErrorXml.WriteXmlAttribute(writer, "source", error.Source);
      ErrorXml.WriteXmlAttribute(writer, "detail", error.Detail);
      ErrorXml.WriteXmlAttribute(writer, "user", error.User);
      if (error.Time != DateTime.MinValue)
        ErrorXml.WriteXmlAttribute(writer, "time", XmlConvert.ToString(error.Time.ToUniversalTime(), "yyyy-MM-dd\\THH:mm:ss.fffffff\\Z"));
      if (error.StatusCode != 0)
        ErrorXml.WriteXmlAttribute(writer, "statusCode", XmlConvert.ToString(error.StatusCode));
      ErrorXml.WriteXmlAttribute(writer, "webHostHtmlMessage", error.WebHostHtmlMessage);
    }

    private static void WriteInnerXml(Error error, XmlWriter writer)
    {
      if (writer == null)
        throw new ArgumentNullException("writer");
      ErrorXml.WriteCollection(writer, "serverVariables", error.ServerVariables);
      ErrorXml.WriteCollection(writer, "queryString", error.QueryString);
      ErrorXml.WriteCollection(writer, "form", error.Form);
      ErrorXml.WriteCollection(writer, "cookies", error.Cookies);
    }

    private static void WriteCollection(XmlWriter writer, string name, NameValueCollection collection)
    {
      if (collection == null || collection.Count == 0)
        return;
      writer.WriteStartElement(name);
      ErrorXml.Encode(collection, writer);
      writer.WriteEndElement();
    }

    private static void WriteXmlAttribute(XmlWriter writer, string name, string value)
    {
      if (value == null || value.Length == 0)
        return;
      writer.WriteAttributeString(name, value);
    }

    private static void Encode(NameValueCollection collection, XmlWriter writer)
    {
      if (collection == null)
        throw new ArgumentNullException("collection");
      if (writer == null)
        throw new ArgumentNullException("writer");
      if (collection.Count == 0)
        return;
      foreach (string key in collection.Keys)
      {
        writer.WriteStartElement("item");
        writer.WriteAttributeString("name", key);
        string[] values = collection.GetValues(key);
        if (values != null)
        {
          foreach (string str in values)
          {
            writer.WriteStartElement("value");
            writer.WriteAttributeString("string", str);
            writer.WriteEndElement();
          }
        }
        writer.WriteEndElement();
      }
    }

    private static void UpcodeTo(XmlReader reader, NameValueCollection collection)
    {
      if (collection == null)
        throw new ArgumentNullException("collection");
      if (reader == null)
        throw new ArgumentNullException("reader");
      reader.Read();
      while (reader.NodeType != XmlNodeType.EndElement)
      {
        if (reader.IsStartElement("item"))
        {
          string attribute1 = reader.GetAttribute("name");
          bool isEmptyElement = reader.IsEmptyElement;
          reader.Read();
          if (!isEmptyElement)
          {
            while (reader.NodeType != XmlNodeType.EndElement)
            {
              if (reader.IsStartElement("value"))
              {
                string attribute2 = reader.GetAttribute("string");
                collection.Add(attribute1, attribute2);
                if (reader.IsEmptyElement)
                {
                  reader.Read();
                }
                else
                {
                  reader.Read();
                  while (reader.NodeType != XmlNodeType.EndElement)
                    reader.Skip();
                  reader.ReadEndElement();
                }
              }
              else
                reader.Skip();
              int content = (int) reader.MoveToContent();
            }
            reader.ReadEndElement();
          }
          else
            collection.Add(attribute1, (string) null);
        }
        else
          reader.Skip();
        int content1 = (int) reader.MoveToContent();
      }
      reader.ReadEndElement();
    }
  }
}
