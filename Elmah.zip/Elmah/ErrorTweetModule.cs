﻿// Decompiled with JetBrains decompiler
// Type: Elmah.ErrorTweetModule
// Assembly: Elmah, Version=1.2.14706.0, Culture=neutral, PublicKeyToken=null
// MVID: 6B433430-60BC-4287-8770-D3B3555B0D2B
// Assembly location: D:\Mata\transport-corp\trans-corp\transport-corp\App\Bin\Elmah.dll

using System;
using System.Collections;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Net;
using System.Text;
using System.Web;

namespace Elmah
{
  public class ErrorTweetModule : HttpModuleBase, IExceptionFiltering
  {
    private ICredentials _credentials;
    private string _statusFormat;
    private Uri _url;
    private int _maxStatusLength;
    private string _ellipsis;
    private string _formFormat;
    private ArrayList _requests;

    protected override bool SupportDiscoverability
    {
      get
      {
        return true;
      }
    }

    public event ExceptionFilterEventHandler Filtering;

    protected override void OnInit(HttpApplication application)
    {
      if (application == null)
        throw new ArgumentNullException("application");
      IDictionary config = (IDictionary) this.GetConfig();
      if (config == null)
        return;
      string setting1 = ErrorTweetModule.GetSetting(config, "userName", string.Empty);
      string setting2 = ErrorTweetModule.GetSetting(config, "password", string.Empty);
      string setting3 = ErrorTweetModule.GetSetting(config, "statusFormat", "{Message}");
      int num = int.Parse(ErrorTweetModule.GetSetting(config, "maxStatusLength", "140"), NumberStyles.None, (IFormatProvider) CultureInfo.InvariantCulture);
      string setting4 = ErrorTweetModule.GetSetting(config, "ellipsis", "…");
      string setting5 = ErrorTweetModule.GetSetting(config, "formFormat", "status={0}");
      Uri uri = new Uri(ErrorTweetModule.GetSetting(config, "url", "http://twitter.com/statuses/update.xml"), UriKind.Absolute);
      this._credentials = (ICredentials) new NetworkCredential(setting1, setting2);
      this._statusFormat = setting3;
      this._url = uri;
      this._maxStatusLength = num;
      this._ellipsis = setting4;
      this._formFormat = setting5;
      this._requests = ArrayList.Synchronized(new ArrayList(4));
      application.Error += new EventHandler(this.OnError);
      ErrorSignal.Get(application).Raised += new ErrorSignalEventHandler(this.OnErrorSignaled);
    }

    protected virtual ErrorLog GetErrorLog(HttpContext context)
    {
      return ErrorLog.GetDefault(context);
    }

    protected virtual void OnError(object sender, EventArgs args)
    {
      HttpApplication httpApplication = (HttpApplication) sender;
      this.LogException(httpApplication.Server.GetLastError(), httpApplication.Context);
    }

    protected virtual void OnErrorSignaled(object sender, ErrorSignalEventArgs args)
    {
      this.LogException(args.Exception, args.Context);
    }

    protected virtual void LogException(Exception e, HttpContext context)
    {
      if (e == null)
        throw new ArgumentNullException("e");
      ExceptionFilterEventArgs args = new ExceptionFilterEventArgs(e, (object) context);
      this.OnFiltering(args);
      if (args.Dismissed)
        return;
      HttpWebRequest httpWebRequest = (HttpWebRequest) null;
      try
      {
        string str = StringFormatter.Format(this._statusFormat, (object) new Error(e, context));
        int maxStatusLength = this._maxStatusLength;
        if (str.Length > maxStatusLength)
        {
          string ellipsis = this._ellipsis;
          int length = maxStatusLength - ellipsis.Length;
          str = length >= 0 ? str.Substring(0, length) + ellipsis : str.Substring(0, maxStatusLength);
        }
        httpWebRequest = (HttpWebRequest) WebRequest.Create(this._url);
        httpWebRequest.Method = "POST";
        httpWebRequest.ContentType = "application/x-www-form-urlencoded";
        if (this._credentials != null)
        {
          httpWebRequest.Credentials = this._credentials;
          httpWebRequest.PreAuthenticate = true;
        }
        httpWebRequest.ServicePoint.Expect100Continue = false;
        byte[] bytes = Encoding.ASCII.GetBytes(string.Format(this._formFormat, (object) HttpUtility.UrlEncode(str)));
        httpWebRequest.ContentLength = (long) bytes.Length;
        this._requests.Add((object) httpWebRequest);
        httpWebRequest.BeginGetRequestStream(new AsyncCallback(this.OnGetRequestStreamCompleted), (object) ErrorTweetModule.AsyncArgs((object) httpWebRequest, (object) bytes));
      }
      catch (Exception ex)
      {
        this.OnWebPostError((WebRequest) httpWebRequest, ex);
      }
    }

    private void OnWebPostError(WebRequest request, Exception e)
    {
      Trace.WriteLine((object) e);
      if (request == null)
        return;
      this._requests.Remove((object) request);
    }

    private static object[] AsyncArgs(params object[] args)
    {
      return args;
    }

    private void OnGetRequestStreamCompleted(IAsyncResult ar)
    {
      if (ar == null)
        throw new ArgumentNullException("ar");
      object[] asyncState = (object[]) ar.AsyncState;
      this.OnGetRequestStreamCompleted(ar, (WebRequest) asyncState[0], (byte[]) asyncState[1]);
    }

    private void OnGetRequestStreamCompleted(IAsyncResult ar, WebRequest request, byte[] data)
    {
      try
      {
        using (Stream requestStream = request.EndGetRequestStream(ar))
          requestStream.Write(data, 0, data.Length);
        request.BeginGetResponse(new AsyncCallback(this.OnGetResponseCompleted), (object) request);
      }
      catch (Exception ex)
      {
        this.OnWebPostError(request, ex);
      }
    }

    private void OnGetResponseCompleted(IAsyncResult ar)
    {
      if (ar == null)
        throw new ArgumentNullException("ar");
      this.OnGetResponseCompleted(ar, (WebRequest) ar.AsyncState);
    }

    private void OnGetResponseCompleted(IAsyncResult ar, WebRequest request)
    {
      try
      {
        request.EndGetResponse(ar).Close();
        this._requests.Remove((object) request);
      }
      catch (Exception ex)
      {
        this.OnWebPostError(request, ex);
      }
    }

    protected virtual void OnFiltering(ExceptionFilterEventArgs args)
    {
      ExceptionFilterEventHandler filtering = this.Filtering;
      if (filtering == null)
        return;
      filtering((object) this, args);
    }

    protected virtual object GetConfig()
    {
      return Configuration.GetSubsection("errorTweet");
    }

    private static string GetSetting(IDictionary config, string name, string defaultValue)
    {
      string str = Mask.NullString((string) config[(object) name]);
      if (str.Length == 0)
      {
        if (defaultValue == null)
          throw new ApplicationException(string.Format("The required configuration setting '{0}' is missing for the error tweeting module.", (object) name));
        str = defaultValue;
      }
      return str;
    }
  }
}
