﻿// Decompiled with JetBrains decompiler
// Type: Elmah.Build
// Assembly: Elmah, Version=1.2.14706.0, Culture=neutral, PublicKeyToken=null
// MVID: 6B433430-60BC-4287-8770-D3B3555B0D2B
// Assembly location: D:\Mata\transport-corp\trans-corp\transport-corp\App\Bin\Elmah.dll

namespace Elmah
{
  internal sealed class Build
  {
    public const bool IsDebug = false;
    public const bool IsRelease = true;
    public const string Type = "Release";
    public const string TypeUppercase = "RELEASE";
    public const string TypeLowercase = "release";
    public const string Framework = "net-2.0";
    public const string Configuration = "release; RTM; net-2.0";
    public const string Status = "RTM";

    public static string ImageRuntimeVersion
    {
      get
      {
        return typeof (ErrorLog).Assembly.ImageRuntimeVersion;
      }
    }

    private Build()
    {
    }
  }
}
