﻿// Decompiled with JetBrains decompiler
// Type: Elmah.SqlErrorLog
// Assembly: Elmah, Version=1.2.14706.0, Culture=neutral, PublicKeyToken=null
// MVID: 6B433430-60BC-4287-8770-D3B3555B0D2B
// Assembly location: D:\Mata\transport-corp\trans-corp\transport-corp\App\Bin\Elmah.dll

using System;
using System.Collections;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Text;
using System.Threading;
using System.Xml;

namespace Elmah
{
  public class SqlErrorLog : ErrorLog
  {
    private const int _maxAppNameLength = 60;
    private readonly string _connectionString;

    public override string Name
    {
      get
      {
        return "Microsoft SQL Server Error Log";
      }
    }

    public virtual string ConnectionString
    {
      get
      {
        return this._connectionString;
      }
    }

    public SqlErrorLog(IDictionary config)
    {
      if (config == null)
        throw new ArgumentNullException("config");
      string connectionString = ConnectionStringHelper.GetConnectionString(config);
      if (connectionString.Length == 0)
        throw new ApplicationException("Connection string is missing for the SQL error log.");
      this._connectionString = connectionString;
      string str = Mask.NullString((string) config[(object) "applicationName"]);
      if (str.Length > 60)
        throw new ApplicationException(string.Format("Application name is too long. Maximum length allowed is {0} characters.", (object) 60.ToString("N0")));
      this.ApplicationName = str;
    }

    public SqlErrorLog(string connectionString)
    {
      if (connectionString == null)
        throw new ArgumentNullException("connectionString");
      if (connectionString.Length == 0)
        throw new ArgumentException((string) null, "connectionString");
      this._connectionString = connectionString;
    }

    public override string Log(Error error)
    {
      if (error == null)
        throw new ArgumentNullException("error");
      string xml = ErrorXml.EncodeString(error);
      Guid id = Guid.NewGuid();
      using (SqlConnection sqlConnection = new SqlConnection(this.ConnectionString))
      {
        using (SqlCommand sqlCommand = SqlErrorLog.Commands.LogError(id, this.ApplicationName, error.HostName, error.Type, error.Source, error.Message, error.User, error.StatusCode, error.Time.ToUniversalTime(), xml))
        {
          sqlCommand.Connection = sqlConnection;
          sqlConnection.Open();
          sqlCommand.ExecuteNonQuery();
          return id.ToString();
        }
      }
    }

    public override int GetErrors(int pageIndex, int pageSize, IList errorEntryList)
    {
      if (pageIndex < 0)
        throw new ArgumentOutOfRangeException("pageIndex", (object) pageIndex, (string) null);
      if (pageSize < 0)
        throw new ArgumentOutOfRangeException("pageSize", (object) pageSize, (string) null);
      using (SqlConnection sqlConnection = new SqlConnection(this.ConnectionString))
      {
        using (SqlCommand errorsXml = SqlErrorLog.Commands.GetErrorsXml(this.ApplicationName, pageIndex, pageSize))
        {
          errorsXml.Connection = sqlConnection;
          sqlConnection.Open();
          this.ErrorsXmlToList(SqlErrorLog.ReadSingleXmlStringResult(errorsXml.ExecuteReader()), errorEntryList);
          int totalCount;
          SqlErrorLog.Commands.GetErrorsXmlOutputs(errorsXml, out totalCount);
          return totalCount;
        }
      }
    }

    private static string ReadSingleXmlStringResult(SqlDataReader reader)
    {
      using (reader)
      {
        if (!reader.Read())
          return (string) null;
        StringBuilder stringBuilder = new StringBuilder(2033);
        do
        {
          stringBuilder.Append(reader.GetString(0));
        }
        while (reader.Read());
        return stringBuilder.ToString();
      }
    }

    public override IAsyncResult BeginGetErrors(int pageIndex, int pageSize, IList errorEntryList, AsyncCallback asyncCallback, object asyncState)
    {
      if (pageIndex < 0)
        throw new ArgumentOutOfRangeException("pageIndex", (object) pageIndex, (string) null);
      if (pageSize < 0)
        throw new ArgumentOutOfRangeException("pageSize", (object) pageSize, (string) null);
      SqlConnection connection = new SqlConnection(new SqlConnectionStringBuilder(this.ConnectionString) { AsynchronousProcessing = true }.ConnectionString);
      SqlCommand command = SqlErrorLog.Commands.GetErrorsXml(this.ApplicationName, pageIndex, pageSize);
      command.Connection = connection;
      SqlErrorLog.AsyncResultWrapper asyncResult = (SqlErrorLog.AsyncResultWrapper) null;
      SqlErrorLog.Function<int, IAsyncResult> function = (SqlErrorLog.Function<int, IAsyncResult>) delegate
      {
        using (connection)
        {
          using (command)
          {
            this.ErrorsXmlToList(SqlErrorLog.ReadSingleXmlStringResult(command.EndExecuteReader(asyncResult.InnerResult)), errorEntryList);
            int totalCount;
            SqlErrorLog.Commands.GetErrorsXmlOutputs(command, out totalCount);
            return totalCount;
          }
        }
      };
      try
      {
        connection.Open();
        asyncResult = new SqlErrorLog.AsyncResultWrapper(command.BeginExecuteReader(asyncCallback != null ? (AsyncCallback) delegate
        {
          asyncCallback((IAsyncResult) asyncResult);
        } : (AsyncCallback) null, (object) function), asyncState);
        return (IAsyncResult) asyncResult;
      }
      catch (Exception ex)
      {
        connection.Dispose();
        throw;
      }
    }

    private void ErrorsXmlToList(string xml, IList errorEntryList)
    {
      if (xml == null || xml.Length == 0)
        return;
      using (XmlReader reader = XmlReader.Create((TextReader) new StringReader(xml), new XmlReaderSettings() { CheckCharacters = false, ConformanceLevel = ConformanceLevel.Fragment }))
        this.ErrorsXmlToList(reader, errorEntryList);
    }

    public override int EndGetErrors(IAsyncResult asyncResult)
    {
      if (asyncResult == null)
        throw new ArgumentNullException("asyncResult");
      SqlErrorLog.AsyncResultWrapper asyncResultWrapper = asyncResult as SqlErrorLog.AsyncResultWrapper;
      if (asyncResultWrapper == null)
        throw new ArgumentException("Unexepcted IAsyncResult type.", "asyncResult");
      return ((SqlErrorLog.Function<int, IAsyncResult>) asyncResultWrapper.InnerResult.AsyncState)(asyncResultWrapper.InnerResult);
    }

    private void ErrorsXmlToList(XmlReader reader, IList errorEntryList)
    {
      if (errorEntryList == null)
        return;
      while (reader.IsStartElement("error"))
      {
        string attribute = reader.GetAttribute("errorId");
        Error error = ErrorXml.Decode(reader);
        errorEntryList.Add((object) new ErrorLogEntry((ErrorLog) this, attribute, error));
      }
    }

    public override ErrorLogEntry GetError(string id)
    {
      if (id == null)
        throw new ArgumentNullException("id");
      if (id.Length == 0)
        throw new ArgumentException((string) null, "id");
      Guid id1;
      try
      {
        id1 = new Guid(id);
      }
      catch (FormatException ex)
      {
        throw new ArgumentException(ex.Message, "id", (Exception) ex);
      }
      string xml;
      using (SqlConnection sqlConnection = new SqlConnection(this.ConnectionString))
      {
        using (SqlCommand errorXml = SqlErrorLog.Commands.GetErrorXml(this.ApplicationName, id1))
        {
          errorXml.Connection = sqlConnection;
          sqlConnection.Open();
          xml = (string) errorXml.ExecuteScalar();
        }
      }
      if (xml == null)
        return (ErrorLogEntry) null;
      Error error = ErrorXml.DecodeString(xml);
      return new ErrorLogEntry((ErrorLog) this, id, error);
    }

    private delegate RV Function<RV, A>(A a);

    private sealed class Commands
    {
      private Commands()
      {
      }

      public static SqlCommand LogError(Guid id, string appName, string hostName, string typeName, string source, string message, string user, int statusCode, DateTime time, string xml)
      {
        SqlCommand sqlCommand = new SqlCommand("ELMAH_LogError");
        sqlCommand.CommandType = CommandType.StoredProcedure;
        SqlParameterCollection parameters = sqlCommand.Parameters;
        parameters.Add("@ErrorId", SqlDbType.UniqueIdentifier).Value = (object) id;
        parameters.Add("@Application", SqlDbType.NVarChar, 60).Value = (object) appName;
        parameters.Add("@Host", SqlDbType.NVarChar, 30).Value = (object) hostName;
        parameters.Add("@Type", SqlDbType.NVarChar, 100).Value = (object) typeName;
        parameters.Add("@Source", SqlDbType.NVarChar, 60).Value = (object) source;
        parameters.Add("@Message", SqlDbType.NVarChar, 500).Value = (object) message;
        parameters.Add("@User", SqlDbType.NVarChar, 50).Value = (object) user;
        parameters.Add("@AllXml", SqlDbType.NText).Value = (object) xml;
        parameters.Add("@StatusCode", SqlDbType.Int).Value = (object) statusCode;
        parameters.Add("@TimeUtc", SqlDbType.DateTime).Value = (object) time;
        return sqlCommand;
      }

      public static SqlCommand GetErrorXml(string appName, Guid id)
      {
        SqlCommand sqlCommand = new SqlCommand("ELMAH_GetErrorXml");
        sqlCommand.CommandType = CommandType.StoredProcedure;
        SqlParameterCollection parameters = sqlCommand.Parameters;
        parameters.Add("@Application", SqlDbType.NVarChar, 60).Value = (object) appName;
        parameters.Add("@ErrorId", SqlDbType.UniqueIdentifier).Value = (object) id;
        return sqlCommand;
      }

      public static SqlCommand GetErrorsXml(string appName, int pageIndex, int pageSize)
      {
        SqlCommand sqlCommand = new SqlCommand("ELMAH_GetErrorsXml");
        sqlCommand.CommandType = CommandType.StoredProcedure;
        SqlParameterCollection parameters = sqlCommand.Parameters;
        parameters.Add("@Application", SqlDbType.NVarChar, 60).Value = (object) appName;
        parameters.Add("@PageIndex", SqlDbType.Int).Value = (object) pageIndex;
        parameters.Add("@PageSize", SqlDbType.Int).Value = (object) pageSize;
        parameters.Add("@TotalCount", SqlDbType.Int).Direction = ParameterDirection.Output;
        return sqlCommand;
      }

      public static void GetErrorsXmlOutputs(SqlCommand command, out int totalCount)
      {
        totalCount = (int) command.Parameters["@TotalCount"].Value;
      }
    }

    private sealed class AsyncResultWrapper : IAsyncResult
    {
      private readonly IAsyncResult _inner;
      private readonly object _asyncState;

      public IAsyncResult InnerResult
      {
        get
        {
          return this._inner;
        }
      }

      public bool IsCompleted
      {
        get
        {
          return this._inner.IsCompleted;
        }
      }

      public WaitHandle AsyncWaitHandle
      {
        get
        {
          return this._inner.AsyncWaitHandle;
        }
      }

      public object AsyncState
      {
        get
        {
          return this._asyncState;
        }
      }

      public bool CompletedSynchronously
      {
        get
        {
          return this._inner.CompletedSynchronously;
        }
      }

      public AsyncResultWrapper(IAsyncResult inner, object asyncState)
      {
        this._inner = inner;
        this._asyncState = asyncState;
      }
    }
  }
}
