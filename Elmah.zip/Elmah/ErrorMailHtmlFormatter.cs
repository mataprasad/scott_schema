﻿// Decompiled with JetBrains decompiler
// Type: Elmah.ErrorMailHtmlFormatter
// Assembly: Elmah, Version=1.2.14706.0, Culture=neutral, PublicKeyToken=null
// MVID: 6B433430-60BC-4287-8770-D3B3555B0D2B
// Assembly location: D:\Mata\transport-corp\trans-corp\transport-corp\App\Bin\Elmah.dll

using System;
using System.Collections.Specialized;
using System.IO;
using System.Web;
using System.Web.UI;

namespace Elmah
{
  public class ErrorMailHtmlFormatter : ErrorTextFormatter
  {
    private HtmlTextWriter _writer;
    private Error _error;

    public override string MimeType
    {
      get
      {
        return "text/html";
      }
    }

    protected HtmlTextWriter Writer
    {
      get
      {
        return this._writer;
      }
    }

    protected Error Error
    {
      get
      {
        return this._error;
      }
    }

    public override void Format(TextWriter writer, Error error)
    {
      if (writer == null)
        throw new ArgumentNullException("writer");
      if (error == null)
        throw new ArgumentNullException("error");
      Html32TextWriter html32TextWriter = new Html32TextWriter(writer);
      html32TextWriter.RenderBeginTag(HtmlTextWriterTag.Html);
      this._writer = (HtmlTextWriter) html32TextWriter;
      this._error = error;
      try
      {
        this.RenderHead();
        this.RenderBody();
      }
      finally
      {
        this._writer = (HtmlTextWriter) null;
        this._error = (Error) null;
      }
      html32TextWriter.RenderEndTag();
      html32TextWriter.WriteLine();
    }

    protected virtual void RenderHead()
    {
      HtmlTextWriter writer = this.Writer;
      writer.RenderBeginTag(HtmlTextWriterTag.Head);
      writer.RenderBeginTag(HtmlTextWriterTag.Title);
      writer.Write("Error: ");
      HttpUtility.HtmlEncode(this.Error.Message, (TextWriter) writer);
      writer.RenderEndTag();
      writer.WriteLine();
      this.RenderStyle();
      writer.RenderEndTag();
      writer.WriteLine();
    }

    protected virtual void RenderBody()
    {
      HtmlTextWriter writer = this.Writer;
      writer.RenderBeginTag(HtmlTextWriterTag.Body);
      this.RenderSummary();
      if (this.Error.Detail.Length != 0)
        this.RenderDetail();
      this.RenderCollections();
      this.RenderFooter();
      writer.RenderEndTag();
      writer.WriteLine();
    }

    protected virtual void RenderFooter()
    {
      HtmlTextWriter writer = this.Writer;
      writer.RenderBeginTag(HtmlTextWriterTag.P);
      new PoweredBy().RenderControl(writer);
      writer.RenderEndTag();
    }

    protected virtual void RenderStyle()
    {
      HtmlTextWriter writer = this.Writer;
      writer.RenderBeginTag(HtmlTextWriterTag.Style);
      writer.WriteLine("\r\n                body { font-family: verdana, arial, helvetic; font-size: x-small; } \r\n                td, th, pre { font-size: x-small; } \r\n                #errorDetail { padding: 1em; background-color: #FFFFCC; } \r\n                #errorMessage { font-size: medium; font-style: italic; color: maroon; }\r\n                h1 { font-size: small; }");
      writer.RenderEndTag();
      writer.WriteLine();
    }

    protected virtual void RenderDetail()
    {
      HtmlTextWriter writer = this.Writer;
      writer.AddAttribute(HtmlTextWriterAttribute.Id, "errorDetail");
      writer.RenderBeginTag(HtmlTextWriterTag.Pre);
      writer.InnerWriter.Flush();
      HttpUtility.HtmlEncode(this.Error.Detail, writer.InnerWriter);
      writer.RenderEndTag();
      writer.WriteLine();
    }

    protected virtual void RenderSummary()
    {
      HtmlTextWriter writer = this.Writer;
      Error error = this.Error;
      writer.AddAttribute(HtmlTextWriterAttribute.Id, "errorMessage");
      writer.RenderBeginTag(HtmlTextWriterTag.P);
      HttpUtility.HtmlEncode(error.Type, (TextWriter) writer);
      writer.Write(": ");
      HttpUtility.HtmlEncode(error.Message, (TextWriter) writer);
      writer.RenderEndTag();
      writer.WriteLine();
      if (!(error.Time != DateTime.MinValue))
        return;
      writer.RenderBeginTag(HtmlTextWriterTag.P);
      writer.Write("Generated: ");
      HttpUtility.HtmlEncode(error.Time.ToUniversalTime().ToString("r"), (TextWriter) writer);
      writer.RenderEndTag();
      writer.WriteLine();
    }

    protected virtual void RenderCollections()
    {
      this.RenderCollection(this.Error.ServerVariables, "Server Variables");
    }

    protected virtual void RenderCollection(NameValueCollection collection, string caption)
    {
      if (collection == null || collection.Count == 0)
        return;
      HtmlTextWriter writer = this.Writer;
      writer.RenderBeginTag(HtmlTextWriterTag.H1);
      HttpUtility.HtmlEncode(caption, (TextWriter) writer);
      writer.RenderEndTag();
      writer.WriteLine();
      writer.AddAttribute(HtmlTextWriterAttribute.Cellpadding, "5");
      writer.AddAttribute(HtmlTextWriterAttribute.Cellspacing, "0");
      writer.AddAttribute(HtmlTextWriterAttribute.Border, "1");
      writer.AddAttribute(HtmlTextWriterAttribute.Width, "100%");
      writer.RenderBeginTag(HtmlTextWriterTag.Table);
      writer.AddAttribute(HtmlTextWriterAttribute.Valign, "top");
      writer.RenderBeginTag(HtmlTextWriterTag.Tr);
      writer.AddAttribute(HtmlTextWriterAttribute.Align, "left");
      writer.RenderBeginTag(HtmlTextWriterTag.Th);
      writer.Write("Name");
      writer.RenderEndTag();
      writer.AddAttribute(HtmlTextWriterAttribute.Align, "left");
      writer.RenderBeginTag(HtmlTextWriterTag.Th);
      writer.Write("Value");
      writer.RenderEndTag();
      writer.RenderEndTag();
      foreach (string key in collection.Keys)
      {
        writer.AddAttribute(HtmlTextWriterAttribute.Valign, "top");
        writer.RenderBeginTag(HtmlTextWriterTag.Tr);
        writer.RenderBeginTag(HtmlTextWriterTag.Td);
        HttpUtility.HtmlEncode(key, (TextWriter) writer);
        writer.RenderEndTag();
        writer.RenderBeginTag(HtmlTextWriterTag.Td);
        string s = Mask.NullString(collection[key]);
        if (s.Length != 0)
          HttpUtility.HtmlEncode(s, (TextWriter) writer);
        else
          writer.Write("&nbsp;");
        writer.RenderEndTag();
        writer.RenderEndTag();
      }
      writer.RenderEndTag();
      writer.WriteLine();
    }
  }
}
