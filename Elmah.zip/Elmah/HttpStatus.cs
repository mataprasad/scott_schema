﻿// Decompiled with JetBrains decompiler
// Type: Elmah.HttpStatus
// Assembly: Elmah, Version=1.2.14706.0, Culture=neutral, PublicKeyToken=null
// MVID: 6B433430-60BC-4287-8770-D3B3555B0D2B
// Assembly location: D:\Mata\transport-corp\trans-corp\transport-corp\App\Bin\Elmah.dll

using System;
using System.Globalization;
using System.Web;

namespace Elmah
{
  [Serializable]
  internal struct HttpStatus
  {
    public static readonly HttpStatus NotFound = new HttpStatus(404);
    public static readonly HttpStatus InternalServerError = new HttpStatus(500);
    private readonly int _code;
    private readonly string _reason;

    public int Code
    {
      get
      {
        return this._code;
      }
    }

    public string Reason
    {
      get
      {
        return Mask.NullString(this._reason);
      }
    }

    public string StatusLine
    {
      get
      {
        return this.Code.ToString((IFormatProvider) CultureInfo.InvariantCulture) + " " + this.Reason;
      }
    }

    public HttpStatus(int code)
    {
      this = new HttpStatus(code, HttpWorkerRequest.GetStatusDescription(code));
    }

    public HttpStatus(int code, string reason)
    {
      this._code = code;
      this._reason = reason;
    }

    public override bool Equals(object obj)
    {
      if (obj == null || !(obj is HttpStatus))
        return false;
      return this.Equals((HttpStatus) obj);
    }

    public bool Equals(HttpStatus other)
    {
      return this.Code.Equals(other.Code);
    }

    public override int GetHashCode()
    {
      return this.Code.GetHashCode();
    }

    public override string ToString()
    {
      return this.StatusLine;
    }
  }
}
