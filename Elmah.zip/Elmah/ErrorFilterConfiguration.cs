﻿// Decompiled with JetBrains decompiler
// Type: Elmah.ErrorFilterConfiguration
// Assembly: Elmah, Version=1.2.14706.0, Culture=neutral, PublicKeyToken=null
// MVID: 6B433430-60BC-4287-8770-D3B3555B0D2B
// Assembly location: D:\Mata\transport-corp\trans-corp\transport-corp\App\Bin\Elmah.dll

using Elmah.Assertions;
using System;

namespace Elmah
{
  public class ErrorFilterConfiguration : ICloneable
  {
    private IAssertion _assertion = (IAssertion) StaticAssertion.False;

    public IAssertion Assertion
    {
      get
      {
        return this._assertion;
      }
    }

    internal void SetAssertion(IAssertion assertion)
    {
      this._assertion = assertion != null ? assertion : (IAssertion) StaticAssertion.False;
    }

    object ICloneable.Clone()
    {
      return this.Clone();
    }

    protected virtual object Clone()
    {
      return this.MemberwiseClone();
    }
  }
}
