﻿// Decompiled with JetBrains decompiler
// Type: Elmah.PoweredBy
// Assembly: Elmah, Version=1.2.14706.0, Culture=neutral, PublicKeyToken=null
// MVID: 6B433430-60BC-4287-8770-D3B3555B0D2B
// Assembly location: D:\Mata\transport-corp\trans-corp\transport-corp\App\Bin\Elmah.dll

using System;
using System.IO;
using System.Reflection;
using System.Web;
using System.Web.Caching;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Elmah
{
  public sealed class PoweredBy : WebControl
  {
    private PoweredBy.AboutSet _about;

    private PoweredBy.AboutSet About
    {
      get
      {
        string fullName = this.GetType().FullName;
        if (this.Cache != null)
          this._about = (PoweredBy.AboutSet) this.Cache[fullName];
        if (this._about == null)
        {
          PoweredBy.AboutSet aboutSet = new PoweredBy.AboutSet();
          Assembly assembly = this.GetType().Assembly;
          aboutSet.Version = assembly.GetName().Version;
          AssemblyFileVersionAttribute customAttribute1 = (AssemblyFileVersionAttribute) Attribute.GetCustomAttribute(assembly, typeof (AssemblyFileVersionAttribute));
          if (customAttribute1 != null)
            aboutSet.FileVersion = new Version(customAttribute1.Version);
          AssemblyProductAttribute customAttribute2 = (AssemblyProductAttribute) Attribute.GetCustomAttribute(assembly, typeof (AssemblyProductAttribute));
          if (customAttribute2 != null)
            aboutSet.Product = customAttribute2.Product;
          AssemblyCopyrightAttribute customAttribute3 = (AssemblyCopyrightAttribute) Attribute.GetCustomAttribute(assembly, typeof (AssemblyCopyrightAttribute));
          if (customAttribute3 != null)
            aboutSet.Copyright = customAttribute3.Copyright;
          if (this.Cache != null)
            this.Cache.Add(fullName, (object) aboutSet, (CacheDependency) null, Cache.NoAbsoluteExpiration, TimeSpan.FromMinutes(2.0), CacheItemPriority.Normal, (CacheItemRemovedCallback) null);
          this._about = aboutSet;
        }
        return this._about;
      }
    }

    private Cache Cache
    {
      get
      {
        if (this.Page == null)
          return HttpRuntime.Cache;
        return this.Page.Cache;
      }
    }

    protected override void RenderContents(HtmlTextWriter writer)
    {
      if (writer == null)
        throw new ArgumentNullException("writer");
      PoweredBy.AboutSet about = this.About;
      writer.Write("Powered by ");
      writer.AddAttribute(HtmlTextWriterAttribute.Href, "http://elmah.googlecode.com/");
      writer.RenderBeginTag(HtmlTextWriterTag.A);
      HttpUtility.HtmlEncode(Mask.EmptyString(about.Product, "(product)"), (TextWriter) writer);
      writer.RenderEndTag();
      writer.Write(", version ");
      string s = about.GetFileVersionString();
      if (s.Length == 0)
        s = about.GetVersionString();
      HttpUtility.HtmlEncode(Mask.EmptyString(s, "?.?.?.?"), (TextWriter) writer);
      writer.Write(". ");
      string copyright = about.Copyright;
      if (copyright.Length > 0)
      {
        HttpUtility.HtmlEncode(copyright, (TextWriter) writer);
        writer.Write(' ');
      }
      writer.Write("Licensed under ");
      writer.AddAttribute(HtmlTextWriterAttribute.Href, "http://www.apache.org/licenses/LICENSE-2.0");
      writer.RenderBeginTag(HtmlTextWriterTag.A);
      writer.Write("Apache License, Version 2.0");
      writer.RenderEndTag();
      writer.Write(". ");
    }

    [Serializable]
    private sealed class AboutSet
    {
      private string _product;
      private Version _version;
      private Version _fileVersion;
      private string _copyright;

      public string Product
      {
        get
        {
          return Mask.NullString(this._product);
        }
        set
        {
          this._product = value;
        }
      }

      public Version Version
      {
        get
        {
          return this._version;
        }
        set
        {
          this._version = value;
        }
      }

      public Version FileVersion
      {
        get
        {
          return this._fileVersion;
        }
        set
        {
          this._fileVersion = value;
        }
      }

      public string Copyright
      {
        get
        {
          return Mask.NullString(this._copyright);
        }
        set
        {
          this._copyright = value;
        }
      }

      public string GetVersionString()
      {
        if (!(this._version != (Version) null))
          return string.Empty;
        return this._version.ToString();
      }

      public string GetFileVersionString()
      {
        if (!(this._fileVersion != (Version) null))
          return string.Empty;
        return this._fileVersion.ToString();
      }
    }
  }
}
