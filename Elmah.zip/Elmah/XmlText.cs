﻿// Decompiled with JetBrains decompiler
// Type: Elmah.XmlText
// Assembly: Elmah, Version=1.2.14706.0, Culture=neutral, PublicKeyToken=null
// MVID: 6B433430-60BC-4287-8770-D3B3555B0D2B
// Assembly location: D:\Mata\transport-corp\trans-corp\transport-corp\App\Bin\Elmah.dll

using System.Text.RegularExpressions;

namespace Elmah
{
  internal sealed class XmlText
  {
    private XmlText()
    {
    }

    public static string StripIllegalXmlCharacters(string xml)
    {
      return XmlText.StripIllegalXmlCharacters(xml, (string) null);
    }

    public static string StripIllegalXmlCharacters(string xml, string replacement)
    {
      return Regex.Replace(xml, "&#x(0{0,3}[0-8BCEF]|0{0,2}1[0-F]|D[89A-F][0-9A-F]{2}|FFF[EF]);", replacement != null ? replacement : "?", RegexOptions.IgnoreCase | RegexOptions.CultureInvariant);
    }
  }
}
