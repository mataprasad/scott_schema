﻿// Decompiled with JetBrains decompiler
// Type: Elmah.OracleErrorLog
// Assembly: Elmah, Version=1.2.14706.0, Culture=neutral, PublicKeyToken=null
// MVID: 6B433430-60BC-4287-8770-D3B3555B0D2B
// Assembly location: D:\Mata\transport-corp\trans-corp\transport-corp\App\Bin\Elmah.dll

using System;
using System.Collections;
using System.Data;
using System.Data.OracleClient;
using System.IO;
using System.Text;

namespace Elmah
{
  public class OracleErrorLog : ErrorLog
  {
    private const int _maxAppNameLength = 60;
    private const int _maxSchemaNameLength = 30;
    private readonly string _connectionString;
    private string _schemaOwner;
    private bool _schemaOwnerInitialized;

    public string SchemaOwner
    {
      get
      {
        return Mask.NullString(this._schemaOwner);
      }
      set
      {
        if (this._schemaOwnerInitialized)
          throw new InvalidOperationException("The schema owner cannot be reset once initialized.");
        this._schemaOwner = Mask.NullString(value);
        if (this._schemaOwner.Length == 0)
          return;
        if (this._schemaOwner.Length > 30)
          throw new ApplicationException(string.Format("Oracle schema owner is too long. Maximum length allowed is {0} characters.", (object) 30.ToString("N0")));
        this._schemaOwner = this._schemaOwner + ".";
        this._schemaOwnerInitialized = true;
      }
    }

    public override string Name
    {
      get
      {
        return "Oracle Error Log";
      }
    }

    public virtual string ConnectionString
    {
      get
      {
        return this._connectionString;
      }
    }

    public OracleErrorLog(IDictionary config)
    {
      if (config == null)
        throw new ArgumentNullException("config");
      string connectionString = ConnectionStringHelper.GetConnectionString(config);
      if (connectionString.Length == 0)
        throw new ApplicationException("Connection string is missing for the Oracle error log.");
      this._connectionString = connectionString;
      string str = Mask.NullString((string) config[(object) "applicationName"]);
      if (str.Length > 60)
        throw new ApplicationException(string.Format("Application name is too long. Maximum length allowed is {0} characters.", (object) 60.ToString("N0")));
      this.ApplicationName = str;
      this.SchemaOwner = (string) config[(object) "schemaOwner"];
    }

    public OracleErrorLog(string connectionString)
    {
      if (connectionString == null)
        throw new ArgumentNullException("connectionString");
      if (connectionString.Length == 0)
        throw new ArgumentException((string) null, "connectionString");
      this._connectionString = connectionString;
    }

    public OracleErrorLog(string connectionString, string schemaOwner)
      : this(connectionString)
    {
      this.SchemaOwner = schemaOwner;
    }

    public override string Log(Error error)
    {
      if (error == null)
        throw new ArgumentNullException("error");
      string s = ErrorXml.EncodeString(error);
      Guid guid = Guid.NewGuid();
      using (OracleConnection oracleConnection = new OracleConnection(this.ConnectionString))
      {
        using (OracleCommand command = oracleConnection.CreateCommand())
        {
          oracleConnection.Open();
          using (OracleTransaction oracleTransaction = oracleConnection.BeginTransaction())
          {
            command.Transaction = oracleTransaction;
            command.CommandText = "declare xx nclob; begin dbms_lob.createtemporary(xx, false, 0); :tempblob := xx; end;";
            command.CommandType = CommandType.Text;
            OracleParameterCollection parameters = command.Parameters;
            parameters.Add("tempblob", OracleType.NClob).Direction = ParameterDirection.Output;
            command.ExecuteNonQuery();
            OracleLob oracleLob = (OracleLob) parameters[0].Value;
            byte[] bytes = Encoding.Unicode.GetBytes(s);
            oracleLob.BeginBatch(OracleLobOpenMode.ReadWrite);
            oracleLob.Write(bytes, 0, bytes.Length);
            oracleLob.EndBatch();
            command.CommandText = this.SchemaOwner + "pkg_elmah$log_error.LogError";
            command.CommandType = CommandType.StoredProcedure;
            parameters.Clear();
            parameters.Add("v_ErrorId", OracleType.NVarChar, 32).Value = (object) guid.ToString("N");
            parameters.Add("v_Application", OracleType.NVarChar, 60).Value = (object) this.ApplicationName;
            parameters.Add("v_Host", OracleType.NVarChar, 30).Value = (object) error.HostName;
            parameters.Add("v_Type", OracleType.NVarChar, 100).Value = (object) error.Type;
            parameters.Add("v_Source", OracleType.NVarChar, 60).Value = (object) error.Source;
            parameters.Add("v_Message", OracleType.NVarChar, 500).Value = (object) error.Message;
            parameters.Add("v_User", OracleType.NVarChar, 50).Value = (object) error.User;
            parameters.Add("v_AllXml", OracleType.NClob).Value = (object) oracleLob;
            parameters.Add("v_StatusCode", OracleType.Int32).Value = (object) error.StatusCode;
            parameters.Add("v_TimeUtc", OracleType.DateTime).Value = (object) error.Time.ToUniversalTime();
            command.ExecuteNonQuery();
            oracleTransaction.Commit();
          }
          return guid.ToString();
        }
      }
    }

    public override int GetErrors(int pageIndex, int pageSize, IList errorEntryList)
    {
      if (pageIndex < 0)
        throw new ArgumentOutOfRangeException("pageIndex", (object) pageIndex, (string) null);
      if (pageSize < 0)
        throw new ArgumentOutOfRangeException("pageSize", (object) pageSize, (string) null);
      using (OracleConnection oracleConnection = new OracleConnection(this.ConnectionString))
      {
        using (OracleCommand command = oracleConnection.CreateCommand())
        {
          command.CommandText = this.SchemaOwner + "pkg_elmah$get_error.GetErrorsXml";
          command.CommandType = CommandType.StoredProcedure;
          OracleParameterCollection parameters = command.Parameters;
          parameters.Add("v_Application", OracleType.NVarChar, 60).Value = (object) this.ApplicationName;
          parameters.Add("v_PageIndex", OracleType.Int32).Value = (object) pageIndex;
          parameters.Add("v_PageSize", OracleType.Int32).Value = (object) pageSize;
          parameters.Add("v_TotalCount", OracleType.Int32).Direction = ParameterDirection.Output;
          parameters.Add("v_Results", OracleType.Cursor).Direction = ParameterDirection.Output;
          oracleConnection.Open();
          using (OracleDataReader oracleDataReader = command.ExecuteReader())
          {
            if (errorEntryList != null)
            {
              while (oracleDataReader.Read())
              {
                Guid guid = new Guid(oracleDataReader["ErrorId"].ToString());
                errorEntryList.Add((object) new ErrorLogEntry((ErrorLog) this, guid.ToString(), new Error()
                {
                  ApplicationName = oracleDataReader["Application"].ToString(),
                  HostName = oracleDataReader["Host"].ToString(),
                  Type = oracleDataReader["Type"].ToString(),
                  Source = oracleDataReader["Source"].ToString(),
                  Message = oracleDataReader["Message"].ToString(),
                  User = oracleDataReader["UserName"].ToString(),
                  StatusCode = Convert.ToInt32(oracleDataReader["StatusCode"]),
                  Time = Convert.ToDateTime(oracleDataReader["TimeUtc"]).ToLocalTime()
                }));
              }
            }
            oracleDataReader.Close();
          }
          return (int) command.Parameters["v_TotalCount"].Value;
        }
      }
    }

    public override ErrorLogEntry GetError(string id)
    {
      if (id == null)
        throw new ArgumentNullException("id");
      if (id.Length == 0)
        throw new ArgumentException((string) null, "id");
      Guid guid;
      try
      {
        guid = new Guid(id);
      }
      catch (FormatException ex)
      {
        throw new ArgumentException(ex.Message, "id", (Exception) ex);
      }
      string xml;
      using (OracleConnection oracleConnection = new OracleConnection(this.ConnectionString))
      {
        using (OracleCommand command = oracleConnection.CreateCommand())
        {
          command.CommandText = this.SchemaOwner + "pkg_elmah$get_error.GetErrorXml";
          command.CommandType = CommandType.StoredProcedure;
          OracleParameterCollection parameters = command.Parameters;
          parameters.Add("v_Application", OracleType.NVarChar, 60).Value = (object) this.ApplicationName;
          parameters.Add("v_ErrorId", OracleType.NVarChar, 32).Value = (object) guid.ToString("N");
          parameters.Add("v_AllXml", OracleType.NClob).Direction = ParameterDirection.Output;
          oracleConnection.Open();
          command.ExecuteNonQuery();
          StreamReader streamReader = new StreamReader((Stream) command.Parameters["v_AllXml"].Value, Encoding.Unicode);
          char[] buffer = new char[1000];
          StringBuilder stringBuilder = new StringBuilder();
          int charCount;
          while ((charCount = streamReader.Read(buffer, 0, buffer.Length)) > 0)
            stringBuilder.Append(buffer, 0, charCount);
          xml = stringBuilder.ToString();
        }
      }
      if (xml == null)
        return (ErrorLogEntry) null;
      Error error = ErrorXml.DecodeString(xml);
      return new ErrorLogEntry((ErrorLog) this, id, error);
    }
  }
}
