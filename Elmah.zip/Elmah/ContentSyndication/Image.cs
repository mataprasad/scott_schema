﻿// Decompiled with JetBrains decompiler
// Type: Elmah.ContentSyndication.Image
// Assembly: Elmah, Version=1.2.14706.0, Culture=neutral, PublicKeyToken=null
// MVID: 6B433430-60BC-4287-8770-D3B3555B0D2B
// Assembly location: D:\Mata\transport-corp\trans-corp\transport-corp\App\Bin\Elmah.dll

using System.Xml.Serialization;

namespace Elmah.ContentSyndication
{
  public class Image
  {
    public string title;
    [XmlElement(DataType = "anyURI")]
    public string url;
    [XmlElement(DataType = "anyURI")]
    public string link;
    public int width;
    [XmlIgnore]
    public bool widthSpecified;
    public int height;
    [XmlIgnore]
    public bool heightSpecified;
    public string description;
  }
}
