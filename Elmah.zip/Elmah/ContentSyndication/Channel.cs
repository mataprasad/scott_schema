﻿// Decompiled with JetBrains decompiler
// Type: Elmah.ContentSyndication.Channel
// Assembly: Elmah, Version=1.2.14706.0, Culture=neutral, PublicKeyToken=null
// MVID: 6B433430-60BC-4287-8770-D3B3555B0D2B
// Assembly location: D:\Mata\transport-corp\trans-corp\transport-corp\App\Bin\Elmah.dll

using System.Xml.Serialization;

namespace Elmah.ContentSyndication
{
  public class Channel
  {
    public string title;
    [XmlElement(DataType = "anyURI")]
    public string link;
    public string description;
    [XmlElement(DataType = "language")]
    public string language;
    public string rating;
    public Image image;
    public TextInput textInput;
    public string copyright;
    [XmlElement(DataType = "anyURI")]
    public string docs;
    public string managingEditor;
    public string webMaster;
    public string pubDate;
    public string lastBuildDate;
    [XmlArrayItem("hour", IsNullable = false)]
    public int[] skipHours;
    [XmlArrayItem("day", IsNullable = false)]
    public Day[] skipDays;
    [XmlElement("item")]
    public Item[] item;
  }
}
