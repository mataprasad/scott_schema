﻿// Decompiled with JetBrains decompiler
// Type: Elmah.ErrorLog
// Assembly: Elmah, Version=1.2.14706.0, Culture=neutral, PublicKeyToken=null
// MVID: 6B433430-60BC-4287-8770-D3B3555B0D2B
// Assembly location: D:\Mata\transport-corp\trans-corp\transport-corp\App\Bin\Elmah.dll

using System;
using System.Collections;
using System.Web;

namespace Elmah
{
  public abstract class ErrorLog
  {
    private static readonly object _contextKey = new object();
    private string _appName;
    private bool _appNameInitialized;

    public virtual string Name
    {
      get
      {
        return this.GetType().Name;
      }
    }

    public string ApplicationName
    {
      get
      {
        return Mask.NullString(this._appName);
      }
      set
      {
        if (this._appNameInitialized)
          throw new InvalidOperationException("The application name cannot be reset once initialized.");
        this._appName = value;
        this._appNameInitialized = Mask.NullString(value).Length > 0;
      }
    }

    [Obsolete("Use ErrorLog.GetDefault(context) instead.")]
    public static ErrorLog Default
    {
      get
      {
        return ErrorLog.GetDefault(HttpContext.Current);
      }
    }

    public abstract string Log(Error error);

    public virtual IAsyncResult BeginLog(Error error, AsyncCallback asyncCallback, object asyncState)
    {
      return ErrorLog.BeginSyncImpl(asyncCallback, asyncState, (Delegate) new ErrorLog.LogHandler(this.Log), (object) error);
    }

    public virtual string EndLog(IAsyncResult asyncResult)
    {
      return (string) ErrorLog.EndSyncImpl(asyncResult);
    }

    public abstract ErrorLogEntry GetError(string id);

    public virtual IAsyncResult BeginGetError(string id, AsyncCallback asyncCallback, object asyncState)
    {
      return ErrorLog.BeginSyncImpl(asyncCallback, asyncState, (Delegate) new ErrorLog.GetErrorHandler(this.GetError), (object) id);
    }

    public virtual ErrorLogEntry EndGetError(IAsyncResult asyncResult)
    {
      return (ErrorLogEntry) ErrorLog.EndSyncImpl(asyncResult);
    }

    public abstract int GetErrors(int pageIndex, int pageSize, IList errorEntryList);

    public virtual IAsyncResult BeginGetErrors(int pageIndex, int pageSize, IList errorEntryList, AsyncCallback asyncCallback, object asyncState)
    {
      return ErrorLog.BeginSyncImpl(asyncCallback, asyncState, (Delegate) new ErrorLog.GetErrorsHandler(this.GetErrors), (object) pageIndex, (object) pageSize, (object) errorEntryList);
    }

    public virtual int EndGetErrors(IAsyncResult asyncResult)
    {
      return (int) ErrorLog.EndSyncImpl(asyncResult);
    }

    public static ErrorLog GetDefault(HttpContext context)
    {
      return (ErrorLog) ServiceCenter.GetService((object) context, typeof (ErrorLog));
    }

    internal static ErrorLog GetDefaultImpl(HttpContext context)
    {
      if (context != null)
      {
        ErrorLog errorLog = (ErrorLog) context.Items[ErrorLog._contextKey];
        if (errorLog != null)
          return errorLog;
      }
      ErrorLog errorLog1 = (ErrorLog) SimpleServiceProviderFactory.CreateFromConfigSection("elmah/errorLog") ?? (ErrorLog) new MemoryErrorLog();
      if (context != null)
      {
        if (errorLog1.ApplicationName.Length == 0)
          errorLog1.ApplicationName = ErrorLog.InferApplicationName(context);
        context.Items[ErrorLog._contextKey] = (object) errorLog1;
      }
      return errorLog1;
    }

    private static string InferApplicationName(HttpContext context)
    {
      string s = (string) null;
      if (context.Request != null)
        s = context.Request.ServerVariables["APPL_MD_PATH"];
      if (string.IsNullOrEmpty(s))
        s = HttpRuntime.AppDomainAppVirtualPath;
      return Mask.EmptyString(s, "/");
    }

    private static IAsyncResult BeginSyncImpl(AsyncCallback asyncCallback, object asyncState, Delegate syncImpl, params object[] args)
    {
      string name = syncImpl.Method.Name;
      SynchronousAsyncResult synchronousAsyncResult;
      try
      {
        synchronousAsyncResult = SynchronousAsyncResult.OnSuccess(name, asyncState, syncImpl.DynamicInvoke(args));
      }
      catch (Exception ex)
      {
        synchronousAsyncResult = SynchronousAsyncResult.OnFailure(name, asyncState, ex);
      }
      if (asyncCallback != null)
        asyncCallback((IAsyncResult) synchronousAsyncResult);
      return (IAsyncResult) synchronousAsyncResult;
    }

    private static object EndSyncImpl(IAsyncResult asyncResult)
    {
      if (asyncResult == null)
        throw new ArgumentNullException("asyncResult");
      SynchronousAsyncResult synchronousAsyncResult = asyncResult as SynchronousAsyncResult;
      if (synchronousAsyncResult == null)
        throw new ArgumentException("IAsyncResult object did not come from the corresponding async method on this type.", "asyncResult");
      return synchronousAsyncResult.End();
    }

    private delegate string LogHandler(Error error);

    private delegate ErrorLogEntry GetErrorHandler(string id);

    private delegate int GetErrorsHandler(int pageIndex, int pageSize, IList errorEntryList);
  }
}
