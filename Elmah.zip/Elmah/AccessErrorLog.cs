﻿// Decompiled with JetBrains decompiler
// Type: Elmah.AccessErrorLog
// Assembly: Elmah, Version=1.2.14706.0, Culture=neutral, PublicKeyToken=null
// MVID: 6B433430-60BC-4287-8770-D3B3555B0D2B
// Assembly location: D:\Mata\transport-corp\trans-corp\transport-corp\App\Bin\Elmah.dll

using System;
using System.Collections;
using System.Data;
using System.Data.OleDb;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Text;

namespace Elmah
{
  public class AccessErrorLog : ErrorLog
  {
    private static readonly object _mdbInitializationLock = new object();
    private const int _maxAppNameLength = 60;
    private const string _scriptResourceName = "mkmdb.vbs";
    private readonly string _connectionString;

    public override string Name
    {
      get
      {
        return "Microsoft Access Error Log";
      }
    }

    public virtual string ConnectionString
    {
      get
      {
        return this._connectionString;
      }
    }

    public AccessErrorLog(IDictionary config)
    {
      if (config == null)
        throw new ArgumentNullException("config");
      string connectionString = ConnectionStringHelper.GetConnectionString(config);
      if (connectionString.Length == 0)
        throw new ApplicationException("Connection string is missing for the Access error log.");
      this._connectionString = connectionString;
      this.InitializeDatabase();
      string str = Mask.NullString((string) config[(object) "applicationName"]);
      if (str.Length > 60)
        throw new ApplicationException(string.Format("Application name is too long. Maximum length allowed is {0} characters.", (object) 60.ToString("N0")));
      this.ApplicationName = str;
    }

    public AccessErrorLog(string connectionString)
    {
      if (connectionString == null)
        throw new ArgumentNullException("connectionString");
      if (connectionString.Length == 0)
        throw new ArgumentException((string) null, "connectionString");
      this._connectionString = connectionString;
    }

    public override string Log(Error error)
    {
      if (error == null)
        throw new ArgumentNullException("error");
      string str = ErrorXml.EncodeString(error);
      using (OleDbConnection oleDbConnection = new OleDbConnection(this.ConnectionString))
      {
        using (OleDbCommand command1 = oleDbConnection.CreateCommand())
        {
          oleDbConnection.Open();
          command1.CommandType = CommandType.Text;
          command1.CommandText = "INSERT INTO ELMAH_Error\r\n                                            (Application, Host, Type, Source, \r\n                                            Message, UserName, StatusCode, TimeUtc, AllXml)\r\n                                        VALUES\r\n                                            (@Application, @Host, @Type, @Source, \r\n                                            @Message, @UserName, @StatusCode, @TimeUtc, @AllXml)";
          command1.CommandType = CommandType.Text;
          OleDbParameterCollection parameters = command1.Parameters;
          parameters.Add("@Application", OleDbType.VarChar, 60).Value = (object) this.ApplicationName;
          parameters.Add("@Host", OleDbType.VarChar, 30).Value = (object) error.HostName;
          parameters.Add("@Type", OleDbType.VarChar, 100).Value = (object) error.Type;
          parameters.Add("@Source", OleDbType.VarChar, 60).Value = (object) error.Source;
          parameters.Add("@Message", OleDbType.LongVarChar, error.Message.Length).Value = (object) error.Message;
          parameters.Add("@User", OleDbType.VarChar, 50).Value = (object) error.User;
          parameters.Add("@StatusCode", OleDbType.Integer).Value = (object) error.StatusCode;
          parameters.Add("@TimeUtc", OleDbType.Date).Value = (object) error.Time.ToUniversalTime();
          parameters.Add("@AllXml", OleDbType.LongVarChar, str.Length).Value = (object) str;
          command1.ExecuteNonQuery();
          using (OleDbCommand command2 = oleDbConnection.CreateCommand())
          {
            command2.CommandType = CommandType.Text;
            command2.CommandText = "SELECT @@IDENTITY";
            return Convert.ToString(command2.ExecuteScalar(), (IFormatProvider) CultureInfo.InvariantCulture);
          }
        }
      }
    }

    public override int GetErrors(int pageIndex, int pageSize, IList errorEntryList)
    {
      if (pageIndex < 0)
        throw new ArgumentOutOfRangeException("pageIndex", (object) pageIndex, (string) null);
      if (pageSize < 0)
        throw new ArgumentOutOfRangeException("pageSize", (object) pageSize, (string) null);
      using (OleDbConnection oleDbConnection = new OleDbConnection(this.ConnectionString))
      {
        using (OleDbCommand command = oleDbConnection.CreateCommand())
        {
          command.CommandType = CommandType.Text;
          command.CommandText = "SELECT COUNT(*) FROM ELMAH_Error";
          oleDbConnection.Open();
          int num1 = (int) command.ExecuteScalar();
          if (errorEntryList != null && pageIndex * pageSize < num1)
          {
            int num2 = pageSize * (pageIndex + 1);
            if (num2 > num1)
            {
              num2 = num1;
              pageSize = num1 - pageSize * (num1 / pageSize);
            }
            StringBuilder stringBuilder = new StringBuilder(1000);
            stringBuilder.Append("SELECT e.* FROM (");
            stringBuilder.Append("SELECT TOP ");
            stringBuilder.Append(pageSize.ToString((IFormatProvider) CultureInfo.InvariantCulture));
            stringBuilder.Append(" TimeUtc, ErrorId FROM (");
            stringBuilder.Append("SELECT TOP ");
            stringBuilder.Append(num2.ToString((IFormatProvider) CultureInfo.InvariantCulture));
            stringBuilder.Append(" TimeUtc, ErrorId FROM ELMAH_Error ");
            stringBuilder.Append("ORDER BY TimeUtc DESC, ErrorId DESC) ");
            stringBuilder.Append("ORDER BY TimeUtc ASC, ErrorId ASC) AS i ");
            stringBuilder.Append("INNER JOIN Elmah_Error AS e ON i.ErrorId = e.ErrorId ");
            stringBuilder.Append("ORDER BY e.TimeUtc DESC, e.ErrorId DESC");
            command.CommandText = stringBuilder.ToString();
            using (OleDbDataReader oleDbDataReader = command.ExecuteReader())
            {
              while (oleDbDataReader.Read())
              {
                string id = Convert.ToString(oleDbDataReader["ErrorId"], (IFormatProvider) CultureInfo.InvariantCulture);
                errorEntryList.Add((object) new ErrorLogEntry((ErrorLog) this, id, new Error()
                {
                  ApplicationName = oleDbDataReader["Application"].ToString(),
                  HostName = oleDbDataReader["Host"].ToString(),
                  Type = oleDbDataReader["Type"].ToString(),
                  Source = oleDbDataReader["Source"].ToString(),
                  Message = oleDbDataReader["Message"].ToString(),
                  User = oleDbDataReader["UserName"].ToString(),
                  StatusCode = Convert.ToInt32(oleDbDataReader["StatusCode"]),
                  Time = Convert.ToDateTime(oleDbDataReader["TimeUtc"]).ToLocalTime()
                }));
              }
              oleDbDataReader.Close();
            }
          }
          return num1;
        }
      }
    }

    public override ErrorLogEntry GetError(string id)
    {
      if (id == null)
        throw new ArgumentNullException("id");
      if (id.Length == 0)
        throw new ArgumentException((string) null, "id");
      int num;
      try
      {
        num = int.Parse(id, (IFormatProvider) CultureInfo.InvariantCulture);
      }
      catch (FormatException ex)
      {
        throw new ArgumentException(ex.Message, "id", (Exception) ex);
      }
      catch (OverflowException ex)
      {
        throw new ArgumentException(ex.Message, "id", (Exception) ex);
      }
      string xml;
      using (OleDbConnection oleDbConnection = new OleDbConnection(this.ConnectionString))
      {
        using (OleDbCommand command = oleDbConnection.CreateCommand())
        {
          command.CommandText = "SELECT   AllXml\r\n                                        FROM     ELMAH_Error\r\n                                        WHERE    ErrorId = @ErrorId";
          command.CommandType = CommandType.Text;
          command.Parameters.Add("@ErrorId", OleDbType.Integer).Value = (object) num;
          oleDbConnection.Open();
          xml = (string) command.ExecuteScalar();
        }
      }
      if (xml == null)
        return (ErrorLogEntry) null;
      Error error = ErrorXml.DecodeString(xml);
      return new ErrorLogEntry((ErrorLog) this, id, error);
    }

    private void InitializeDatabase()
    {
      string dataSourceFilePath = ConnectionStringHelper.GetDataSourceFilePath(this.ConnectionString);
      if (File.Exists(dataSourceFilePath))
        return;
      lock (AccessErrorLog._mdbInitializationLock)
      {
        if (File.Exists(dataSourceFilePath))
          return;
        string local_2 = Path.Combine(Path.GetDirectoryName(dataSourceFilePath), "mkmdb.vbs");
        using (FileStream resource_0 = new FileStream(local_2, FileMode.Create, FileAccess.Write, FileShare.None))
          ManifestResourceHelper.WriteResourceToStream((Stream) resource_0, "mkmdb.vbs");
        ProcessStartInfo local_4 = new ProcessStartInfo("cscript", "\"" + local_2 + "\" \"" + dataSourceFilePath + "\" //B //NoLogo");
        local_4.UseShellExecute = false;
        local_4.CreateNoWindow = true;
        try
        {
          using (Process resource_1 = Process.Start(local_4))
          {
            TimeSpan local_6 = TimeSpan.FromSeconds(2.0);
            if (!resource_1.WaitForExit((int) local_6.TotalMilliseconds))
            {
              resource_1.Kill();
              throw new Exception(string.Format("The Microsoft Access database creation script took longer than the allocated time of {0} seconds to execute. The script was terminated prematurely.", (object) local_6.TotalSeconds));
            }
            if (resource_1.ExitCode != 0)
              throw new Exception(string.Format("The Microsoft Access database creation script failed with exit code {0}.", (object) resource_1.ExitCode));
          }
        }
        finally
        {
          File.Delete(local_2);
        }
      }
    }
  }
}
