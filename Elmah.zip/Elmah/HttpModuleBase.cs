﻿// Decompiled with JetBrains decompiler
// Type: Elmah.HttpModuleBase
// Assembly: Elmah, Version=1.2.14706.0, Culture=neutral, PublicKeyToken=null
// MVID: 6B433430-60BC-4287-8770-D3B3555B0D2B
// Assembly location: D:\Mata\transport-corp\trans-corp\transport-corp\App\Bin\Elmah.dll

using System;
using System.Web;

namespace Elmah
{
  public abstract class HttpModuleBase : IHttpModule
  {
    protected virtual bool SupportDiscoverability
    {
      get
      {
        return false;
      }
    }

    void IHttpModule.Init(HttpApplication context)
    {
      if (context == null)
        throw new ArgumentNullException("context");
      if (this.SupportDiscoverability)
        HttpModuleRegistry.RegisterInPartialTrust(context, (IHttpModule) this);
      this.OnInit(context);
    }

    void IHttpModule.Dispose()
    {
      this.OnDispose();
    }

    protected virtual void OnInit(HttpApplication application)
    {
    }

    protected virtual void OnDispose()
    {
    }
  }
}
