﻿// Decompiled with JetBrains decompiler
// Type: Elmah.ErrorFilterSectionHandler
// Assembly: Elmah, Version=1.2.14706.0, Culture=neutral, PublicKeyToken=null
// MVID: 6B433430-60BC-4287-8770-D3B3555B0D2B
// Assembly location: D:\Mata\transport-corp\trans-corp\transport-corp\App\Bin\Elmah.dll

using Elmah.Assertions;
using System;
using System.Configuration;
using System.Xml;

namespace Elmah
{
  internal sealed class ErrorFilterSectionHandler : IConfigurationSectionHandler
  {
    public object Create(object parent, object configContext, XmlNode section)
    {
      if (section == null)
        throw new ArgumentNullException("section");
      ErrorFilterConfiguration filterConfiguration = parent == null ? new ErrorFilterConfiguration() : (ErrorFilterConfiguration) ((ICloneable) parent).Clone();
      XmlElement config = (XmlElement) section.SelectSingleNode("test/*");
      if (config != null)
        filterConfiguration.SetAssertion(AssertionFactory.Create(config));
      return (object) filterConfiguration;
    }
  }
}
