﻿// Decompiled with JetBrains decompiler
// Type: Elmah.HtmlLinkType
// Assembly: Elmah, Version=1.2.14706.0, Culture=neutral, PublicKeyToken=null
// MVID: 6B433430-60BC-4287-8770-D3B3555B0D2B
// Assembly location: D:\Mata\transport-corp\trans-corp\transport-corp\App\Bin\Elmah.dll

namespace Elmah
{
  internal sealed class HtmlLinkType
  {
    public const string Alternate = "alternate";
    public const string Stylesheet = "stylesheet";
    public const string Start = "start";
    public const string Next = "next";
    public const string Prev = "prev";
    public const string Contents = "contents";
    public const string Index = "index";
    public const string Glossary = "glossary";
    public const string Copyright = "copyright";
    public const string Chapter = "chapter";
    public const string Section = "section";
    public const string Subsection = "subsection";
    public const string Appendix = "appendix";
    public const string Help = "help";
    public const string Bookmark = "bookmark";

    private HtmlLinkType()
    {
    }
  }
}
