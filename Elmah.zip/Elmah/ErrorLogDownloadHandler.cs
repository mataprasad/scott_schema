﻿// Decompiled with JetBrains decompiler
// Type: Elmah.ErrorLogDownloadHandler
// Assembly: Elmah, Version=1.2.14706.0, Culture=neutral, PublicKeyToken=null
// MVID: 6B433430-60BC-4287-8770-D3B3555B0D2B
// Assembly location: D:\Mata\transport-corp\trans-corp\transport-corp\App\Bin\Elmah.dll

using System;
using System.Collections;
using System.Collections.Specialized;
using System.Globalization;
using System.IO;
using System.Text.RegularExpressions;
using System.Threading;
using System.Web;

namespace Elmah
{
  internal sealed class ErrorLogDownloadHandler : IHttpAsyncHandler, IHttpHandler
  {
    private static readonly TimeSpan _beatPollInterval = TimeSpan.FromSeconds(3.0);
    private int _maxDownloadCount = -1;
    private const int _pageSize = 100;
    private ErrorLogDownloadHandler.Format _format;
    private int _pageIndex;
    private int _downloadCount;
    private ErrorLogDownloadHandler.AsyncResult _result;
    private ErrorLog _log;
    private DateTime _lastBeatTime;
    private ArrayList _errorEntryList;
    private HttpContext _context;
    private AsyncCallback _callback;

    public bool IsReusable
    {
      get
      {
        return false;
      }
    }

    public void ProcessRequest(HttpContext context)
    {
      this.EndProcessRequest(this.BeginProcessRequest(context, (AsyncCallback) null, (object) null));
    }

    public IAsyncResult BeginProcessRequest(HttpContext context, AsyncCallback cb, object extraData)
    {
      if (context == null)
        throw new ArgumentNullException("context");
      if (this._result != null)
        throw new InvalidOperationException("An asynchronous operation is already pending.");
      NameValueCollection queryString = context.Request.QueryString;
      this._maxDownloadCount = Math.Max(0, Convert.ToInt32(queryString["limit"], (IFormatProvider) CultureInfo.InvariantCulture));
      switch (Mask.EmptyString(queryString["format"], "csv").ToLower(CultureInfo.InvariantCulture))
      {
        case "csv":
          this._format = (ErrorLogDownloadHandler.Format) new ErrorLogDownloadHandler.CsvFormat(context);
          break;
        case "jsonp":
          this._format = (ErrorLogDownloadHandler.Format) new ErrorLogDownloadHandler.JsonPaddingFormat(context);
          break;
        case "html-jsonp":
          this._format = (ErrorLogDownloadHandler.Format) new ErrorLogDownloadHandler.JsonPaddingFormat(context, true);
          break;
        default:
          throw new Exception("Request log format is not supported.");
      }
      context.Response.BufferOutput = false;
      this._format.Header();
      ErrorLogDownloadHandler.AsyncResult asyncResult = this._result = new ErrorLogDownloadHandler.AsyncResult(extraData);
      this._log = ErrorLog.GetDefault(context);
      this._pageIndex = 0;
      this._lastBeatTime = DateTime.Now;
      this._context = context;
      this._callback = cb;
      this._errorEntryList = new ArrayList(100);
      this._log.BeginGetErrors(this._pageIndex, 100, (IList) this._errorEntryList, new AsyncCallback(this.GetErrorsCallback), (object) null);
      return (IAsyncResult) asyncResult;
    }

    public void EndProcessRequest(IAsyncResult result)
    {
      if (result == null)
        throw new ArgumentNullException("result");
      if (result != this._result)
        throw new ArgumentException((string) null, "result");
      this._result = (ErrorLogDownloadHandler.AsyncResult) null;
      this._log = (ErrorLog) null;
      this._context = (HttpContext) null;
      this._callback = (AsyncCallback) null;
      this._errorEntryList = (ArrayList) null;
      ((ErrorLogDownloadHandler.AsyncResult) result).End();
    }

    private void GetErrorsCallback(IAsyncResult result)
    {
      try
      {
        this.TryGetErrorsCallback(result);
      }
      catch (Exception ex)
      {
        this._result.Complete(this._callback, ex);
      }
    }

    private void TryGetErrorsCallback(IAsyncResult result)
    {
      int errors = this._log.EndGetErrors(result);
      int count = this._errorEntryList.Count;
      if (this._maxDownloadCount > 0)
      {
        int num = this._maxDownloadCount - (this._downloadCount + count);
        if (num < 0)
          count += num;
      }
      this._format.Entries((IList) this._errorEntryList, 0, count, errors);
      this._downloadCount += count;
      HttpResponse response = this._context.Response;
      response.Flush();
      if (count == 0 || this._downloadCount == this._maxDownloadCount)
      {
        if (count > 0)
          this._format.Entries((IList) new ErrorLogEntry[0], errors);
        this._result.Complete(false, this._callback);
      }
      else
      {
        if (DateTime.Now - this._lastBeatTime > ErrorLogDownloadHandler._beatPollInterval)
        {
          if (!response.IsClientConnected)
          {
            this._result.Complete(true, this._callback);
            return;
          }
          this._lastBeatTime = DateTime.Now;
        }
        this._errorEntryList.Clear();
        this._log.BeginGetErrors(++this._pageIndex, 100, (IList) this._errorEntryList, new AsyncCallback(this.GetErrorsCallback), (object) null);
      }
    }

    private abstract class Format
    {
      private readonly HttpContext _context;

      protected HttpContext Context
      {
        get
        {
          return this._context;
        }
      }

      protected Format(HttpContext context)
      {
        this._context = context;
      }

      public virtual void Header()
      {
      }

      public void Entries(IList entries, int total)
      {
        this.Entries(entries, 0, entries.Count, total);
      }

      public abstract void Entries(IList entries, int index, int count, int total);
    }

    private sealed class CsvFormat : ErrorLogDownloadHandler.Format
    {
      public CsvFormat(HttpContext context)
        : base(context)
      {
      }

      public override void Header()
      {
        HttpResponse response = this.Context.Response;
        response.AppendHeader("Content-Type", "text/csv; header=present");
        response.AppendHeader("Content-Disposition", "attachment; filename=errorlog.csv");
        response.Output.Write("Application,Host,Time,Unix Time,Type,Source,User,Status Code,Message,URL,XMLREF,JSONREF\r\n");
      }

      public override void Entries(IList entries, int index, int count, int total)
      {
        if (count == 0)
          return;
        StringWriter stringWriter = new StringWriter();
        stringWriter.NewLine = "\r\n";
        ErrorLogDownloadHandler.CsvWriter csvWriter = new ErrorLogDownloadHandler.CsvWriter((TextWriter) stringWriter);
        CultureInfo invariantCulture = CultureInfo.InvariantCulture;
        DateTime dateTime = new DateTime(1970, 1, 1);
        for (int index1 = index; index1 < count; ++index1)
        {
          ErrorLogEntry entry = (ErrorLogEntry) entries[index1];
          Error error = entry.Error;
          DateTime universalTime = error.Time.ToUniversalTime();
          string str = "?id=" + HttpUtility.UrlEncode(entry.Id);
          Uri requestUrl = ErrorLogPageFactory.GetRequestUrl(this.Context);
          csvWriter.Field(error.ApplicationName).Field(error.HostName).Field(universalTime.ToString("yyyy-MM-dd HH:mm:ss", (IFormatProvider) invariantCulture)).Field(universalTime.Subtract(dateTime).TotalSeconds.ToString("0.0000", (IFormatProvider) invariantCulture)).Field(error.Type).Field(error.Source).Field(error.User).Field(error.StatusCode.ToString((IFormatProvider) invariantCulture)).Field(error.Message).Field(new Uri(requestUrl, "detail" + str).ToString()).Field(new Uri(requestUrl, "xml" + str).ToString()).Field(new Uri(requestUrl, "json" + str).ToString()).Record();
        }
        this.Context.Response.Output.Write(stringWriter.ToString());
      }
    }

    private sealed class JsonPaddingFormat : ErrorLogDownloadHandler.Format
    {
      private static readonly Regex _callbackExpression = new Regex("^ \r\n                     [a-z_] [a-z0-9_]+ ( \\[ [0-9]+ \\] )?\r\n                ( \\. [a-z_] [a-z0-9_]+ ( \\[ [0-9]+ \\] )? )* $", RegexOptions.IgnoreCase | RegexOptions.ExplicitCapture | RegexOptions.Singleline | RegexOptions.IgnorePatternWhitespace | RegexOptions.CultureInvariant);
      private string _callback;
      private readonly bool _wrapped;

      public JsonPaddingFormat(HttpContext context)
        : this(context, false)
      {
      }

      public JsonPaddingFormat(HttpContext context, bool wrapped)
        : base(context)
      {
        this._wrapped = wrapped;
      }

      public override void Header()
      {
        string input = Mask.NullString(this.Context.Request.QueryString[Mask.EmptyString((string) null, "callback")]);
        if (input.Length == 0)
          throw new Exception("The JSONP callback parameter is missing.");
        if (!ErrorLogDownloadHandler.JsonPaddingFormat._callbackExpression.IsMatch(input))
          throw new Exception("The JSONP callback parameter is not in an acceptable format.");
        this._callback = input;
        HttpResponse response = this.Context.Response;
        if (!this._wrapped)
        {
          response.AppendHeader("Content-Type", "text/javascript");
          response.AppendHeader("Content-Disposition", "attachment; filename=errorlog.js");
        }
        else
        {
          response.AppendHeader("Content-Type", "text/html");
          TextWriter output = response.Output;
          output.WriteLine("<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\">");
          output.WriteLine("\r\n                    <html xmlns='http://www.w3.org/1999/xhtml'>\r\n                    <head>\r\n                        <title>Error Log in HTML-Wrapped JSONP Format</title>\r\n                    </head>\r\n                    <body>\r\n                        <p>This page is primarily designed to be used in an IFRAME of a parent HTML document.</p>");
        }
      }

      public override void Entries(IList entries, int index, int count, int total)
      {
        StringWriter stringWriter = new StringWriter();
        stringWriter.NewLine = "\n";
        if (this._wrapped)
        {
          stringWriter.WriteLine("<script type='text/javascript' language='javascript'>");
          stringWriter.WriteLine("//<[!CDATA[");
        }
        stringWriter.Write(this._callback);
        stringWriter.Write('(');
        JsonTextWriter writer = new JsonTextWriter((TextWriter) stringWriter);
        writer.Object().Member("total").Number(total).Member("errors").Array();
        Uri requestUrl = ErrorLogPageFactory.GetRequestUrl(this.Context);
        for (int index1 = index; index1 < count; ++index1)
        {
          ErrorLogEntry entry = (ErrorLogEntry) entries[index1];
          stringWriter.WriteLine();
          if (index1 == 0)
            stringWriter.Write(' ');
          stringWriter.Write("  ");
          string format = new Uri(requestUrl, "{0}?id=" + HttpUtility.UrlEncode(entry.Id)).ToString();
          writer.Object();
          ErrorJson.Encode(entry.Error, writer);
          writer.Member("hrefs").Array().Object().Member("type").String("text/html").Member("href").String(string.Format(format, (object) "detail")).Pop().Object().Member("type").String("aplication/json").Member("href").String(string.Format(format, (object) "json")).Pop().Object().Member("type").String("application/xml").Member("href").String(string.Format(format, (object) "xml")).Pop().Pop().Pop();
        }
        writer.Pop();
        writer.Pop();
        if (count > 0)
          stringWriter.WriteLine();
        stringWriter.WriteLine(");");
        if (this._wrapped)
        {
          stringWriter.WriteLine("//]]>");
          stringWriter.WriteLine("</script>");
          if (count == 0)
            stringWriter.WriteLine("</body></html>");
        }
        this.Context.Response.Output.Write((object) stringWriter);
      }
    }

    private sealed class AsyncResult : IAsyncResult
    {
      private readonly object _lock = new object();
      private ManualResetEvent _event;
      private readonly object _userState;
      private bool _completed;
      private Exception _exception;
      private bool _ended;
      private bool _aborted;

      public bool IsCompleted
      {
        get
        {
          return this._completed;
        }
      }

      public WaitHandle AsyncWaitHandle
      {
        get
        {
          if (this._event == null)
          {
            lock (this._lock)
            {
              if (this._event == null)
                this._event = new ManualResetEvent(this._completed);
            }
          }
          return (WaitHandle) this._event;
        }
      }

      public object AsyncState
      {
        get
        {
          return this._userState;
        }
      }

      public bool CompletedSynchronously
      {
        get
        {
          return false;
        }
      }

      internal event EventHandler Completed;

      public AsyncResult(object userState)
      {
        this._userState = userState;
      }

      internal void Complete(bool aborted, AsyncCallback callback)
      {
        if (this._completed)
          throw new InvalidOperationException();
        this._aborted = aborted;
        try
        {
          lock (this._lock)
          {
            this._completed = true;
            if (this._event != null)
              this._event.Set();
          }
          if (callback == null)
            return;
          callback((IAsyncResult) this);
        }
        finally
        {
          this.OnCompleted();
        }
      }

      internal void Complete(AsyncCallback callback, Exception e)
      {
        this._exception = e;
        this.Complete(false, callback);
      }

      internal bool End()
      {
        if (this._ended)
          throw new InvalidOperationException();
        this._ended = true;
        if (!this.IsCompleted)
          this.AsyncWaitHandle.WaitOne();
        if (this._event != null)
          this._event.Close();
        if (this._exception != null)
          throw this._exception;
        return this._aborted;
      }

      private void OnCompleted()
      {
        EventHandler completed = this.Completed;
        if (completed == null)
          return;
        completed((object) this, EventArgs.Empty);
      }
    }

    private sealed class CsvWriter
    {
      private static readonly char[] _reserved = new char[4]{ '"', ',', '\r', '\n' };
      private readonly TextWriter _writer;
      private int _column;

      public CsvWriter(TextWriter writer)
      {
        this._writer = writer;
      }

      public ErrorLogDownloadHandler.CsvWriter Record()
      {
        this._writer.WriteLine();
        this._column = 0;
        return this;
      }

      public ErrorLogDownloadHandler.CsvWriter Field(string value)
      {
        if (this._column > 0)
          this._writer.Write(',');
        if (value.IndexOfAny(ErrorLogDownloadHandler.CsvWriter._reserved) < 0)
        {
          this._writer.Write(value);
        }
        else
        {
          this._writer.Write("\"");
          this._writer.Write(value.Replace("\"", "\"\""));
          this._writer.Write("\"");
        }
        ++this._column;
        return this;
      }
    }
  }
}
