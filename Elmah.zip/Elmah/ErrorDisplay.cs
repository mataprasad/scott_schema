﻿// Decompiled with JetBrains decompiler
// Type: Elmah.ErrorDisplay
// Assembly: Elmah, Version=1.2.14706.0, Culture=neutral, PublicKeyToken=null
// MVID: 6B433430-60BC-4287-8770-D3B3555B0D2B
// Assembly location: D:\Mata\transport-corp\trans-corp\transport-corp\App\Bin\Elmah.dll

using System;
using System.Globalization;

namespace Elmah
{
  public sealed class ErrorDisplay
  {
    private ErrorDisplay()
    {
    }

    public static string HumaneExceptionErrorType(string type)
    {
      if (type == null || type.Length == 0)
        return string.Empty;
      int num1 = CultureInfo.InvariantCulture.CompareInfo.LastIndexOf(type, '.');
      if (num1 > 0)
        type = type.Substring(num1 + 1);
      if (type.Length > "Exception".Length)
      {
        int num2 = type.Length - "Exception".Length;
        if (string.Compare(type, num2, "Exception", 0, "Exception".Length, true, CultureInfo.InvariantCulture) == 0)
          type = type.Substring(0, num2);
      }
      return type;
    }

    public static string HumaneExceptionErrorType(Error error)
    {
      if (error == null)
        throw new ArgumentNullException("error");
      return ErrorDisplay.HumaneExceptionErrorType(error.Type);
    }
  }
}
