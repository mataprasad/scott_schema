﻿// Decompiled with JetBrains decompiler
// Type: Elmah.Assertions.RegexMatchAssertion
// Assembly: Elmah, Version=1.2.14706.0, Culture=neutral, PublicKeyToken=null
// MVID: 6B433430-60BC-4287-8770-D3B3555B0D2B
// Assembly location: D:\Mata\transport-corp\trans-corp\transport-corp\App\Bin\Elmah.dll

using System;
using System.Globalization;
using System.Text.RegularExpressions;

namespace Elmah.Assertions
{
  public class RegexMatchAssertion : DataBoundAssertion
  {
    private readonly Regex _regex;

    public IContextExpression Source
    {
      get
      {
        return this.Expression;
      }
    }

    public Regex RegexObject
    {
      get
      {
        return this._regex;
      }
    }

    public RegexMatchAssertion(IContextExpression source, Regex regex)
      : base(source)
    {
      if (regex == null)
        throw new ArgumentNullException("regex");
      this._regex = regex;
    }

    protected override bool TestResult(object result)
    {
      return this.TestResultMatch(Convert.ToString(result, (IFormatProvider) CultureInfo.InvariantCulture));
    }

    protected virtual bool TestResultMatch(string result)
    {
      return this.RegexObject.Match(result).Success;
    }
  }
}
