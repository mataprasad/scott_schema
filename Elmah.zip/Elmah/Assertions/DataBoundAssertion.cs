﻿// Decompiled with JetBrains decompiler
// Type: Elmah.Assertions.DataBoundAssertion
// Assembly: Elmah, Version=1.2.14706.0, Culture=neutral, PublicKeyToken=null
// MVID: 6B433430-60BC-4287-8770-D3B3555B0D2B
// Assembly location: D:\Mata\transport-corp\trans-corp\transport-corp\App\Bin\Elmah.dll

using System;

namespace Elmah.Assertions
{
  public abstract class DataBoundAssertion : IAssertion
  {
    private readonly IContextExpression _expression;

    protected IContextExpression Expression
    {
      get
      {
        return this._expression;
      }
    }

    protected DataBoundAssertion(IContextExpression expression)
    {
      if (expression == null)
        throw new ArgumentNullException("expression");
      this._expression = expression;
    }

    public virtual bool Test(object context)
    {
      if (context == null)
        throw new ArgumentNullException("context");
      return this.TestResult(this.Expression.Evaluate(context));
    }

    protected abstract bool TestResult(object result);
  }
}
