﻿// Decompiled with JetBrains decompiler
// Type: Elmah.Assertions.JScriptAssertion
// Assembly: Elmah, Version=1.2.14706.0, Culture=neutral, PublicKeyToken=null
// MVID: 6B433430-60BC-4287-8770-D3B3555B0D2B
// Assembly location: D:\Mata\transport-corp\trans-corp\transport-corp\App\Bin\Elmah.dll

using Microsoft.JScript;
using Microsoft.JScript.Vsa;
using System;
using System.Collections;
using System.Collections.Specialized;
using System.IO;
using System.Reflection;
using System.Security;
using System.Security.Permissions;
using System.Text.RegularExpressions;

namespace Elmah.Assertions
{
  public sealed class JScriptAssertion : IAssertion
  {
    private static readonly Regex _directiveExpression = new Regex("^ \\s* // \\s* @([a-zA-Z]+)", RegexOptions.IgnoreCase | RegexOptions.Singleline | RegexOptions.IgnorePatternWhitespace | RegexOptions.CultureInvariant);
    private readonly JScriptAssertion.EvaluationStrategy _evaluationStrategy;

    public JScriptAssertion(string expression)
      : this(expression, (string[]) null, (string[]) null)
    {
    }

    public JScriptAssertion(string expression, string[] assemblyNames, string[] imports)
    {
      if (expression == null || expression.Length == 0 || expression.TrimStart().Length == 0)
        return;
      JScriptAssertion.ProcessDirectives(expression, ref assemblyNames, ref imports);
      VsaEngine engine = VsaEngine.CreateEngineAndGetGlobalScope(false, assemblyNames != null ? assemblyNames : new string[0]).engine;
      if (imports != null && imports.Length > 0)
      {
        foreach (string import in imports)
          Import.JScriptImport(import, engine);
      }
      this._evaluationStrategy = JScriptAssertion.FullTrustEvaluationStrategy.IsApplicable() ? (JScriptAssertion.EvaluationStrategy) new JScriptAssertion.FullTrustEvaluationStrategy(expression, engine) : (JScriptAssertion.EvaluationStrategy) new JScriptAssertion.PartialTrustEvaluationStrategy(expression, engine);
    }

    public JScriptAssertion(NameValueCollection settings)
      : this(settings["expression"], settings.GetValues("assembly"), settings.GetValues("import"))
    {
    }

    public bool Test(object context)
    {
      if (context == null)
        throw new ArgumentNullException("context");
      if (this._evaluationStrategy != null)
        return this._evaluationStrategy.Eval(context);
      return false;
    }

    private static void ProcessDirectives(string expression, ref string[] assemblyNames, ref string[] imports)
    {
      ArrayList list1 = (ArrayList) null;
      ArrayList list2 = (ArrayList) null;
      using (StringReader stringReader = new StringReader(expression))
      {
        int num = 0;
        string input;
        while ((input = stringReader.ReadLine()) != null)
        {
          ++num;
          if (input.Trim().Length != 0)
          {
            Match match = JScriptAssertion._directiveExpression.Match(input);
            if (match.Success)
            {
              string directive = match.Groups[1].Value;
              string parameter = input.Substring(match.Index + match.Length).Trim();
              try
              {
                switch (directive)
                {
                  case "assembly":
                    list1 = JScriptAssertion.AddDirectiveParameter(directive, parameter, list1, assemblyNames);
                    continue;
                  case "import":
                    list2 = JScriptAssertion.AddDirectiveParameter(directive, parameter, list2, imports);
                    continue;
                  default:
                    throw new FormatException(string.Format("'{0}' is not a recognized directive.", (object) directive));
                }
              }
              catch (FormatException ex)
              {
                throw new ArgumentException(string.Format("Error processing directives section (lead comment) of the JScript expression (see line {0}). {1}", (object) num.ToString("N0"), (object) ex.Message), "expression");
              }
            }
            else
              break;
          }
        }
      }
      assemblyNames = JScriptAssertion.ListOrElseArray(list1, assemblyNames);
      imports = JScriptAssertion.ListOrElseArray(list2, imports);
    }

    private static ArrayList AddDirectiveParameter(string directive, string parameter, ArrayList list, string[] inits)
    {
      if (parameter.Length == 0)
        throw new FormatException(string.Format("Missing parameter for {0} directive.", (object) directive));
      if (list == null)
      {
        list = new ArrayList((inits != null ? inits.Length : 0) + 4);
        if (inits != null)
          list.AddRange((ICollection) inits);
      }
      list.Add((object) parameter);
      return list;
    }

    private static string[] ListOrElseArray(ArrayList list, string[] array)
    {
      if (list == null)
        return array;
      return (string[]) list.ToArray(typeof (string));
    }

    private abstract class EvaluationStrategy
    {
      private readonly VsaEngine _engine;

      public VsaEngine Engine
      {
        get
        {
          return this._engine;
        }
      }

      protected EvaluationStrategy(VsaEngine engine)
      {
        this._engine = engine;
      }

      public abstract bool Eval(object context);
    }

    private sealed class PartialTrustEvaluationStrategy : JScriptAssertion.EvaluationStrategy
    {
      private readonly string _expression;
      private readonly GlobalScope _scope;
      private readonly FieldInfo _oldContextField;
      private readonly FieldInfo _newContextField;

      public PartialTrustEvaluationStrategy(string expression, VsaEngine engine)
        : base(engine)
      {
        this._scope = (GlobalScope) engine.GetGlobalScope().GetObject();
        this._oldContextField = this._scope.AddField("$context");
        this._newContextField = this._scope.AddField("$");
        this._expression = expression;
      }

      public override bool Eval(object context)
      {
        VsaEngine engine = this.Engine;
        this._oldContextField.SetValue((object) this._scope, context);
        this._newContextField.SetValue((object) this._scope, context);
        try
        {
          With.JScriptWith(context, engine);
          return Microsoft.JScript.Convert.ToBoolean(Eval.JScriptEvaluate((object) this._expression, engine));
        }
        finally
        {
          engine.PopScriptObject();
        }
      }
    }

    private sealed class FullTrustEvaluationStrategy : JScriptAssertion.EvaluationStrategy
    {
      private readonly object _function;

      public FullTrustEvaluationStrategy(string expression, VsaEngine engine)
        : base(engine)
      {
        this._function = LateBinding.CallValue(JScriptAssertion.FullTrustEvaluationStrategy.DefaultThisObject(engine), engine.LenientGlobalObject.Function, new object[2]
        {
          (object) "$context,$",
          (object) ("\r\n                        with ($context) {\r\n                            return (\r\n                                " + expression + "\r\n                            );\r\n                        }")
        }, 1 != 0, 0 != 0, engine);
      }

      public override bool Eval(object context)
      {
        return Microsoft.JScript.Convert.ToBoolean(LateBinding.CallValue(JScriptAssertion.FullTrustEvaluationStrategy.DefaultThisObject(this.Engine), this._function, new object[2]{ context, context }, 0 != 0, 0 != 0, this.Engine));
      }

      private static object DefaultThisObject(VsaEngine engine)
      {
        return ((IActivationObject) engine.ScriptObjectStackTop()).GetDefaultThisObject();
      }

      public static bool IsApplicable()
      {
        try
        {
          new SecurityPermission(SecurityPermissionFlag.UnmanagedCode).Demand();
          return true;
        }
        catch (SecurityException ex)
        {
          return false;
        }
      }
    }
  }
}
