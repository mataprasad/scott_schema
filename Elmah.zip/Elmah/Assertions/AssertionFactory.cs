﻿// Decompiled with JetBrains decompiler
// Type: Elmah.Assertions.AssertionFactory
// Assembly: Elmah, Version=1.2.14706.0, Culture=neutral, PublicKeyToken=null
// MVID: 6B433430-60BC-4287-8770-D3B3555B0D2B
// Assembly location: D:\Mata\transport-corp\trans-corp\transport-corp\App\Bin\Elmah.dll

using System;
using System.Collections;
using System.ComponentModel;
using System.Configuration;
using System.Globalization;
using System.Reflection;
using System.Text.RegularExpressions;
using System.Web;
using System.Xml;

namespace Elmah.Assertions
{
  public sealed class AssertionFactory
  {
    private static readonly string[] _truths = new string[4]{ "true", "yes", "on", "1" };

    private AssertionFactory()
    {
      throw new NotSupportedException();
    }

    public static IAssertion assert_is_null(IContextExpression binding)
    {
      return (IAssertion) new IsNullAssertion(binding);
    }

    public static IAssertion assert_is_not_null(IContextExpression binding)
    {
      return (IAssertion) new UnaryNotAssertion(AssertionFactory.assert_is_null(binding));
    }

    public static IAssertion assert_equal(IContextExpression binding, TypeCode type, string value)
    {
      return (IAssertion) new ComparisonAssertion(ComparisonResults.Equal, binding, type, value);
    }

    public static IAssertion assert_not_equal(IContextExpression binding, TypeCode type, string value)
    {
      return (IAssertion) new UnaryNotAssertion(AssertionFactory.assert_equal(binding, type, value));
    }

    public static IAssertion assert_lesser(IContextExpression binding, TypeCode type, string value)
    {
      return (IAssertion) new ComparisonAssertion(ComparisonResults.Lesser, binding, type, value);
    }

    public static IAssertion assert_lesser_or_equal(IContextExpression binding, TypeCode type, string value)
    {
      return (IAssertion) new ComparisonAssertion(ComparisonResults.LesserOrEqual, binding, type, value);
    }

    public static IAssertion assert_greater(IContextExpression binding, TypeCode type, string value)
    {
      return (IAssertion) new ComparisonAssertion(ComparisonResults.Greater, binding, type, value);
    }

    public static IAssertion assert_greater_or_equal(IContextExpression binding, TypeCode type, string value)
    {
      return (IAssertion) new ComparisonAssertion(ComparisonResults.GreaterOrEqual, binding, type, value);
    }

    public static IAssertion assert_and(XmlElement config)
    {
      return (IAssertion) LogicalAssertion.LogicalAnd(AssertionFactory.Create(config.ChildNodes));
    }

    public static IAssertion assert_or(XmlElement config)
    {
      return (IAssertion) LogicalAssertion.LogicalOr(AssertionFactory.Create(config.ChildNodes));
    }

    public static IAssertion assert_not(XmlElement config)
    {
      return (IAssertion) LogicalAssertion.LogicalNot(AssertionFactory.Create(config.ChildNodes));
    }

    public static IAssertion assert_is_type(IContextExpression binding, Type type)
    {
      return (IAssertion) new TypeAssertion(binding, type, false);
    }

    public static IAssertion assert_is_type_compatible(IContextExpression binding, Type type)
    {
      return (IAssertion) new TypeAssertion(binding, type, true);
    }

    public static IAssertion assert_regex(IContextExpression binding, string pattern, bool caseSensitive, bool dontCompile)
    {
      if (Mask.NullString(pattern).Length == 0)
        return (IAssertion) StaticAssertion.False;
      RegexOptions options = RegexOptions.CultureInvariant;
      if (!caseSensitive)
        options |= RegexOptions.IgnoreCase;
      if (!dontCompile)
        options |= RegexOptions.Compiled;
      return (IAssertion) new RegexMatchAssertion(binding, new Regex(pattern, options));
    }

    public static IAssertion assert_jscript(XmlElement config)
    {
      if (config == null)
        throw new ArgumentNullException("config");
      string expression = (string) null;
      XmlElement xmlElement = config["expression"];
      if (xmlElement != null)
        expression = xmlElement.InnerText;
      if (expression == null)
        expression = config.GetAttribute("expression");
      return (IAssertion) new JScriptAssertion(expression, AssertionFactory.DeserializeStringArray(config, "assemblies", "assembly", "name"), AssertionFactory.DeserializeStringArray(config, "imports", "import", "namespace"));
    }

    public static IAssertion Create(XmlElement config)
    {
      if (config == null)
        throw new ArgumentNullException("config");
      try
      {
        return AssertionFactory.CreateImpl(config);
      }
      catch (ConfigurationException ex)
      {
        throw;
      }
      catch (Exception ex)
      {
        throw new ConfigurationException(ex.Message, ex);
      }
    }

    public static IAssertion[] Create(XmlNodeList nodes)
    {
      if (nodes == null)
        throw new ArgumentNullException("nodes");
      int length = 0;
      foreach (XmlNode node in nodes)
      {
        XmlNodeType nodeType = node.NodeType;
        switch (nodeType)
        {
          case XmlNodeType.Comment:
          case XmlNodeType.Whitespace:
            continue;
          case XmlNodeType.Element:
            ++length;
            continue;
          default:
            throw new ConfigurationException(string.Format("Unexpected type of node ({0}).", (object) nodeType.ToString()), node);
        }
      }
      IAssertion[] assertionArray = new IAssertion[length];
      int num = 0;
      foreach (XmlNode node in nodes)
      {
        if (node.NodeType == XmlNodeType.Element)
          assertionArray[num++] = AssertionFactory.Create((XmlElement) node);
      }
      return assertionArray;
    }

    private static IAssertion CreateImpl(XmlElement config)
    {
      string str = "assert_" + config.LocalName;
      if (str.IndexOf('-') > 0)
        str = str.Replace("-", "_");
      string xmlns = Mask.NullString(config.NamespaceURI);
      Type target;
      if (xmlns.Length > 0)
      {
        string typeNamespace;
        string assemblyName;
        if (!AssertionFactory.DecodeClrTypeNamespaceFromXmlNamespace(xmlns, out typeNamespace, out assemblyName) || typeNamespace.Length == 0 || assemblyName.Length == 0)
          throw new ConfigurationException(string.Format("Error decoding CLR type namespace and assembly from the XML namespace '{0}'.", (object) xmlns));
        target = Assembly.Load(assemblyName).GetType(typeNamespace + ".AssertionFactory", true);
      }
      else
        target = typeof (AssertionFactory);
      MethodInfo method = target.GetMethod(str, BindingFlags.Static | BindingFlags.Public);
      if (method == null)
        throw new MissingMemberException(string.Format("{0} does not have a method named {1}. Ensure that the method is named correctly and that it is public and static.", (object) target, (object) str));
      ParameterInfo[] parameters = method.GetParameters();
      if (parameters.Length == 1 && parameters[0].ParameterType == typeof (XmlElement) && method.ReturnType == typeof (IAssertion))
        return ((AssertionFactoryHandler) Delegate.CreateDelegate(typeof (AssertionFactoryHandler), target, str))(config);
      return (IAssertion) method.Invoke((object) null, AssertionFactory.ParseArguments(method, config));
    }

    private static object[] ParseArguments(MethodInfo method, XmlElement config)
    {
      ParameterInfo[] parameters = method.GetParameters();
      object[] objArray = new object[parameters.Length];
      foreach (ParameterInfo parameter in parameters)
        objArray[parameter.Position] = AssertionFactory.ParseArgument(parameter, config);
      return objArray;
    }

    private static object ParseArgument(ParameterInfo parameter, XmlElement config)
    {
      string name = parameter.Name;
      Type parameterType = parameter.ParameterType;
      XmlAttribute attributeNode = config.GetAttributeNode(name);
      string innerText;
      if (attributeNode != null)
      {
        innerText = attributeNode.Value;
      }
      else
      {
        XmlElement xmlElement = config[name];
        if (xmlElement == null)
          return (object) null;
        innerText = xmlElement.InnerText;
      }
      if (parameterType == typeof (IContextExpression))
        return (object) new WebDataBindingExpression(innerText);
      if (parameterType == typeof (Type))
        return (object) Type.GetType(innerText, true, false);
      if (parameterType != typeof (bool))
        return TypeDescriptor.GetConverter(parameterType).ConvertFromInvariantString(innerText);
      string lower = innerText.Trim().ToLower(CultureInfo.InvariantCulture);
      return (object) bool.TrueString.Equals(StringTranslation.Translate(bool.TrueString, lower, AssertionFactory._truths));
    }

    private static bool DecodeClrTypeNamespaceFromXmlNamespace(string xmlns, out string typeNamespace, out string assemblyName)
    {
      assemblyName = string.Empty;
      typeNamespace = string.Empty;
      if (AssertionFactory.OrdinalStringStartsWith(xmlns, "http://schemas.microsoft.com/clr/assem/"))
      {
        assemblyName = HttpUtility.UrlDecode(xmlns.Substring("http://schemas.microsoft.com/clr/assem/".Length));
        return assemblyName.Length > 0;
      }
      if (AssertionFactory.OrdinalStringStartsWith(xmlns, "http://schemas.microsoft.com/clr/ns/"))
      {
        typeNamespace = xmlns.Substring("http://schemas.microsoft.com/clr/ns/".Length);
        return typeNamespace.Length > 0;
      }
      if (!AssertionFactory.OrdinalStringStartsWith(xmlns, "http://schemas.microsoft.com/clr/nsassem/"))
        return false;
      int num = xmlns.IndexOf("/", "http://schemas.microsoft.com/clr/nsassem/".Length);
      typeNamespace = xmlns.Substring("http://schemas.microsoft.com/clr/nsassem/".Length, num - "http://schemas.microsoft.com/clr/nsassem/".Length);
      assemblyName = HttpUtility.UrlDecode(xmlns.Substring(num + 1));
      if (assemblyName.Length > 0)
        return typeNamespace.Length > 0;
      return false;
    }

    private static bool OrdinalStringStartsWith(string s, string prefix)
    {
      if (s.Length >= prefix.Length)
        return string.CompareOrdinal(s.Substring(0, prefix.Length), prefix) == 0;
      return false;
    }

    private static string[] DeserializeStringArray(XmlElement config, string containerName, string elementName, string valueName)
    {
      ArrayList arrayList = new ArrayList(4);
      string xpath = containerName + "/" + elementName + "/@" + valueName;
      foreach (XmlAttribute selectNode in config.SelectNodes(xpath))
      {
        if (Mask.NullString(selectNode.Value).Length > 0)
          arrayList.Add((object) selectNode.Value);
      }
      return (string[]) arrayList.ToArray(typeof (string));
    }
  }
}
