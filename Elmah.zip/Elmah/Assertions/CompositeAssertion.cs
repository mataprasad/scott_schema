﻿// Decompiled with JetBrains decompiler
// Type: Elmah.Assertions.CompositeAssertion
// Assembly: Elmah, Version=1.2.14706.0, Culture=neutral, PublicKeyToken=null
// MVID: 6B433430-60BC-4287-8770-D3B3555B0D2B
// Assembly location: D:\Mata\transport-corp\trans-corp\transport-corp\App\Bin\Elmah.dll

using System;
using System.Collections;

namespace Elmah.Assertions
{
  [Serializable]
  public abstract class CompositeAssertion : ReadOnlyCollectionBase, IAssertion
  {
    public virtual IAssertion this[int index]
    {
      get
      {
        return (IAssertion) this.InnerList[index];
      }
    }

    protected CompositeAssertion()
    {
    }

    protected CompositeAssertion(IAssertion[] assertions)
    {
      if (assertions == null)
        throw new ArgumentNullException("assertions");
      foreach (IAssertion assertion in assertions)
      {
        if (assertion == null)
          throw new ArgumentException((string) null, "assertions");
      }
      this.InnerList.AddRange((ICollection) assertions);
    }

    protected CompositeAssertion(ICollection assertions)
    {
      if (assertions == null)
        return;
      this.InnerList.AddRange(assertions);
    }

    public virtual bool Contains(IAssertion assertion)
    {
      return this.InnerList.Contains((object) assertion);
    }

    public virtual int IndexOf(IAssertion assertion)
    {
      return this.InnerList.IndexOf((object) assertion);
    }

    public abstract bool Test(object context);
  }
}
