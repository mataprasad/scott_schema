﻿// Decompiled with JetBrains decompiler
// Type: Elmah.Assertions.ComparisonAssertion
// Assembly: Elmah, Version=1.2.14706.0, Culture=neutral, PublicKeyToken=null
// MVID: 6B433430-60BC-4287-8770-D3B3555B0D2B
// Assembly location: D:\Mata\transport-corp\trans-corp\transport-corp\App\Bin\Elmah.dll

using System;
using System.Globalization;

namespace Elmah.Assertions
{
  public class ComparisonAssertion : DataBoundAssertion
  {
    private readonly object _expectedValue;
    private readonly ComparisonResultPredicate _predicate;

    public IContextExpression Source
    {
      get
      {
        return this.Expression;
      }
    }

    public object ExpectedValue
    {
      get
      {
        return this._expectedValue;
      }
    }

    public ComparisonAssertion(ComparisonResultPredicate predicate, IContextExpression source, TypeCode type, string value)
      : base(source)
    {
      if (predicate == null)
        throw new ArgumentNullException("predicate");
      this._predicate = predicate;
      if (type == TypeCode.DBNull || type == TypeCode.Empty || type == TypeCode.Object)
        throw new ArgumentException(string.Format("The {0} value type is invalid for a comparison.", (object) type.ToString()), "type");
      this._expectedValue = Convert.ChangeType((object) value, type);
    }

    public override bool Test(object context)
    {
      if (context == null)
        throw new ArgumentNullException("context");
      if (this.ExpectedValue == null)
        return false;
      return base.Test(context);
    }

    protected override bool TestResult(object result)
    {
      if (result == null)
        return false;
      IComparable expectedValue = this.ExpectedValue as IComparable;
      if (expectedValue == null)
        return false;
      IComparable left = Convert.ChangeType(result, expectedValue.GetType(), (IFormatProvider) CultureInfo.InvariantCulture) as IComparable;
      if (left == null)
        return false;
      return this.TestComparison(left, expectedValue);
    }

    protected bool TestComparison(IComparable left, IComparable right)
    {
      if (left == null)
        throw new ArgumentNullException("left");
      return this._predicate(left.CompareTo((object) right));
    }
  }
}
