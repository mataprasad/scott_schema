﻿// Decompiled with JetBrains decompiler
// Type: Elmah.Assertions.ComparisonResults
// Assembly: Elmah, Version=1.2.14706.0, Culture=neutral, PublicKeyToken=null
// MVID: 6B433430-60BC-4287-8770-D3B3555B0D2B
// Assembly location: D:\Mata\transport-corp\trans-corp\transport-corp\App\Bin\Elmah.dll

using System;

namespace Elmah.Assertions
{
  public sealed class ComparisonResults
  {
    public static readonly ComparisonResultPredicate Equal = new ComparisonResultPredicate(ComparisonResults.MeansEqual);
    public static readonly ComparisonResultPredicate Lesser = new ComparisonResultPredicate(ComparisonResults.MeansLesser);
    public static readonly ComparisonResultPredicate LesserOrEqual = new ComparisonResultPredicate(ComparisonResults.MeansLessOrEqual);
    public static readonly ComparisonResultPredicate Greater = new ComparisonResultPredicate(ComparisonResults.MeansGreater);
    public static readonly ComparisonResultPredicate GreaterOrEqual = new ComparisonResultPredicate(ComparisonResults.MeansGreaterOrEqual);

    private ComparisonResults()
    {
      throw new NotSupportedException();
    }

    private static bool MeansEqual(int result)
    {
      return result == 0;
    }

    private static bool MeansLesser(int result)
    {
      return result < 0;
    }

    private static bool MeansLessOrEqual(int result)
    {
      return result <= 0;
    }

    private static bool MeansGreater(int result)
    {
      return result > 0;
    }

    private static bool MeansGreaterOrEqual(int result)
    {
      return result >= 0;
    }
  }
}
