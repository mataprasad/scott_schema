﻿// Decompiled with JetBrains decompiler
// Type: Elmah.Assertions.LogicalAssertion
// Assembly: Elmah, Version=1.2.14706.0, Culture=neutral, PublicKeyToken=null
// MVID: 6B433430-60BC-4287-8770-D3B3555B0D2B
// Assembly location: D:\Mata\transport-corp\trans-corp\transport-corp\App\Bin\Elmah.dll

using System;
using System.Collections;

namespace Elmah.Assertions
{
  public sealed class LogicalAssertion : CompositeAssertion
  {
    private readonly bool _not;
    private readonly bool _all;

    private LogicalAssertion(IAssertion[] assertions, bool not, bool all)
      : base(assertions)
    {
      this._not = not;
      this._all = all;
    }

    public static LogicalAssertion LogicalAnd(IAssertion[] operands)
    {
      return new LogicalAssertion(operands, false, true);
    }

    public static LogicalAssertion LogicalOr(IAssertion[] operands)
    {
      return new LogicalAssertion(operands, false, false);
    }

    public static LogicalAssertion LogicalNot(IAssertion[] operands)
    {
      return new LogicalAssertion(operands, true, true);
    }

    public override bool Test(object context)
    {
      if (context == null)
        throw new ArgumentNullException("context");
      if (this.Count == 0)
        return false;
      bool flag1 = false;
      foreach (IAssertion assertion in (ReadOnlyCollectionBase) this)
      {
        if (assertion != null)
        {
          bool flag2 = assertion.Test(context);
          if (this._not)
            flag2 = !flag2;
          if (flag2)
          {
            if (!this._all)
              return true;
            flag1 = true;
          }
          else if (this._all)
            return false;
        }
      }
      return flag1;
    }
  }
}
