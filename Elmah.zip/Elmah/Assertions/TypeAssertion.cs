﻿// Decompiled with JetBrains decompiler
// Type: Elmah.Assertions.TypeAssertion
// Assembly: Elmah, Version=1.2.14706.0, Culture=neutral, PublicKeyToken=null
// MVID: 6B433430-60BC-4287-8770-D3B3555B0D2B
// Assembly location: D:\Mata\transport-corp\trans-corp\transport-corp\App\Bin\Elmah.dll

using System;

namespace Elmah.Assertions
{
  public sealed class TypeAssertion : DataBoundAssertion
  {
    private readonly Type _expectedType;
    private readonly bool _byCompatibility;

    public IContextExpression Source
    {
      get
      {
        return this.Expression;
      }
    }

    public Type ExpectedType
    {
      get
      {
        return this._expectedType;
      }
    }

    public bool ByCompatibility
    {
      get
      {
        return this._byCompatibility;
      }
    }

    public TypeAssertion(IContextExpression source, Type expectedType, bool byCompatibility)
      : base(TypeAssertion.MaskNullExpression(source))
    {
      if (expectedType == null)
        throw new ArgumentNullException("expectedType");
      if (expectedType.IsInterface || expectedType.IsClass && expectedType.IsAbstract)
        byCompatibility = true;
      this._expectedType = expectedType;
      this._byCompatibility = byCompatibility;
    }

    public override bool Test(object context)
    {
      if (context == null)
        throw new ArgumentNullException("context");
      if (this.ExpectedType == null)
        return false;
      return base.Test(context);
    }

    protected override bool TestResult(object result)
    {
      if (result == null)
        return false;
      Type type = result.GetType();
      Type expectedType = this.ExpectedType;
      if (!this.ByCompatibility)
        return expectedType.Equals(type);
      return expectedType.IsAssignableFrom(type);
    }

    private static IContextExpression MaskNullExpression(IContextExpression expression)
    {
      if (expression == null)
        return (IContextExpression) new DelegatedContextExpression(new ContextExpressionEvaluationHandler(TypeAssertion.EvaluateToException));
      return expression;
    }

    private static object EvaluateToException(object context)
    {
      ExceptionFilterEventArgs exceptionFilterEventArgs = context as ExceptionFilterEventArgs;
      if (exceptionFilterEventArgs == null)
        return DataBinder.Eval(context, "Exception");
      return (object) exceptionFilterEventArgs.Exception;
    }
  }
}
