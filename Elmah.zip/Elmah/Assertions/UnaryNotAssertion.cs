﻿// Decompiled with JetBrains decompiler
// Type: Elmah.Assertions.UnaryNotAssertion
// Assembly: Elmah, Version=1.2.14706.0, Culture=neutral, PublicKeyToken=null
// MVID: 6B433430-60BC-4287-8770-D3B3555B0D2B
// Assembly location: D:\Mata\transport-corp\trans-corp\transport-corp\App\Bin\Elmah.dll

using System;

namespace Elmah.Assertions
{
  public sealed class UnaryNotAssertion : IAssertion
  {
    private readonly IAssertion _operand;

    public IAssertion Operand
    {
      get
      {
        return this._operand;
      }
    }

    public UnaryNotAssertion(IAssertion operand)
    {
      if (operand == null)
        throw new ArgumentNullException("operand");
      this._operand = operand;
    }

    public bool Test(object context)
    {
      return !this._operand.Test(context);
    }
  }
}
