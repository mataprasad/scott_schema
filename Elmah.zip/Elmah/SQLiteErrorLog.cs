﻿// Decompiled with JetBrains decompiler
// Type: Elmah.SQLiteErrorLog
// Assembly: Elmah, Version=1.2.14706.0, Culture=neutral, PublicKeyToken=null
// MVID: 6B433430-60BC-4287-8770-D3B3555B0D2B
// Assembly location: D:\Mata\transport-corp\trans-corp\transport-corp\App\Bin\Elmah.dll

using System;
using System.Collections;
using System.Data;
using System.Data.SQLite;
using System.Globalization;
using System.IO;

namespace Elmah
{
  public class SQLiteErrorLog : ErrorLog
  {
    private static readonly object _lock = new object();
    private readonly string _connectionString;

    public override string Name
    {
      get
      {
        return "SQLite Error Log";
      }
    }

    public virtual string ConnectionString
    {
      get
      {
        return this._connectionString;
      }
    }

    public SQLiteErrorLog(IDictionary config)
    {
      if (config == null)
        throw new ArgumentNullException("config");
      string connectionString = ConnectionStringHelper.GetConnectionString(config, true);
      if (connectionString.Length == 0)
        throw new ApplicationException("Connection string is missing for the SQLite error log.");
      this._connectionString = connectionString;
      this.InitializeDatabase();
      this.ApplicationName = Mask.NullString((string) config[(object) "applicationName"]);
    }

    public SQLiteErrorLog(string connectionString)
    {
      if (connectionString == null)
        throw new ArgumentNullException("connectionString");
      if (connectionString.Length == 0)
        throw new ArgumentException((string) null, "connectionString");
      this._connectionString = ConnectionStringHelper.GetResolvedConnectionString(connectionString);
      this.InitializeDatabase();
    }

    private void InitializeDatabase()
    {
      string connectionString = this.ConnectionString;
      string dataSourceFilePath = ConnectionStringHelper.GetDataSourceFilePath(connectionString);
      if (File.Exists(dataSourceFilePath))
        return;
      lock (SQLiteErrorLog._lock)
      {
        if (File.Exists(dataSourceFilePath))
          return;
        SQLiteConnection.CreateFile(dataSourceFilePath);
        using (SQLiteConnection resource_1 = new SQLiteConnection(connectionString))
        {
          using (SQLiteCommand resource_0 = new SQLiteCommand("\r\n                CREATE TABLE Error (\r\n                    ErrorId INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,\r\n                    Application TEXT NOT NULL,\r\n                    Host TEXT NOT NULL,\r\n                    Type TEXT NOT NULL,\r\n                    Source TEXT NOT NULL,\r\n                    Message TEXT NOT NULL,\r\n                    User TEXT NOT NULL,\r\n                    StatusCode INTEGER NOT NULL,\r\n                    TimeUtc TEXT NOT NULL,\r\n                    AllXml TEXT NOT NULL\r\n                )", resource_1))
          {
            resource_1.Open();
            resource_0.ExecuteNonQuery();
          }
        }
      }
    }

    public override string Log(Error error)
    {
      if (error == null)
        throw new ArgumentNullException("error");
      string str = ErrorXml.EncodeString(error);
      using (SQLiteConnection connection = new SQLiteConnection(this.ConnectionString))
      {
        using (SQLiteCommand sqLiteCommand = new SQLiteCommand("\r\n                INSERT INTO Error (\r\n                    Application, Host, \r\n                    Type, Source, Message, User, StatusCode, \r\n                    TimeUtc, AllXml)\r\n                VALUES (\r\n                    @Application, @Host, \r\n                    @Type, @Source, @Message, @User, @StatusCode, \r\n                    @TimeUtc, @AllXml);\r\n\r\n                SELECT last_insert_rowid();", connection))
        {
          SQLiteParameterCollection parameters = sqLiteCommand.Parameters;
          parameters.Add("@Application", DbType.String, 60).Value = (object) this.ApplicationName;
          parameters.Add("@Host", DbType.String, 30).Value = (object) error.HostName;
          parameters.Add("@Type", DbType.String, 100).Value = (object) error.Type;
          parameters.Add("@Source", DbType.String, 60).Value = (object) error.Source;
          parameters.Add("@Message", DbType.String, 500).Value = (object) error.Message;
          parameters.Add("@User", DbType.String, 50).Value = (object) error.User;
          parameters.Add("@StatusCode", DbType.Int64).Value = (object) error.StatusCode;
          parameters.Add("@TimeUtc", DbType.DateTime).Value = (object) error.Time.ToUniversalTime();
          parameters.Add("@AllXml", DbType.String).Value = (object) str;
          connection.Open();
          return Convert.ToInt64(sqLiteCommand.ExecuteScalar()).ToString((IFormatProvider) CultureInfo.InvariantCulture);
        }
      }
    }

    public override int GetErrors(int pageIndex, int pageSize, IList errorEntryList)
    {
      if (pageIndex < 0)
        throw new ArgumentOutOfRangeException("pageIndex", (object) pageIndex, (string) null);
      if (pageSize < 0)
        throw new ArgumentOutOfRangeException("pageSize", (object) pageSize, (string) null);
      using (SQLiteConnection connection = new SQLiteConnection(this.ConnectionString))
      {
        using (SQLiteCommand sqLiteCommand = new SQLiteCommand("\r\n                SELECT\r\n                    ErrorId,\r\n                    Application,\r\n                    Host,\r\n                    Type,\r\n                    Source,\r\n                    Message,\r\n                    User,\r\n                    StatusCode,\r\n                    TimeUtc\r\n                FROM\r\n                    Error\r\n                ORDER BY\r\n                    ErrorId DESC\r\n                LIMIT \r\n                    @PageIndex * @PageSize,\r\n                    @PageSize;\r\n\r\n                SELECT COUNT(*) FROM Error", connection))
        {
          SQLiteParameterCollection parameters = sqLiteCommand.Parameters;
          parameters.Add("@PageIndex", DbType.Int16).Value = (object) pageIndex;
          parameters.Add("@PageSize", DbType.Int16).Value = (object) pageSize;
          connection.Open();
          using (SQLiteDataReader sqLiteDataReader = sqLiteCommand.ExecuteReader())
          {
            if (errorEntryList != null)
            {
              while (sqLiteDataReader.Read())
              {
                string id = Convert.ToString(sqLiteDataReader["ErrorId"], (IFormatProvider) CultureInfo.InvariantCulture);
                errorEntryList.Add((object) new ErrorLogEntry((ErrorLog) this, id, new Error()
                {
                  ApplicationName = sqLiteDataReader["Application"].ToString(),
                  HostName = sqLiteDataReader["Host"].ToString(),
                  Type = sqLiteDataReader["Type"].ToString(),
                  Source = sqLiteDataReader["Source"].ToString(),
                  Message = sqLiteDataReader["Message"].ToString(),
                  User = sqLiteDataReader["User"].ToString(),
                  StatusCode = Convert.ToInt32(sqLiteDataReader["StatusCode"]),
                  Time = Convert.ToDateTime(sqLiteDataReader["TimeUtc"]).ToLocalTime()
                }));
              }
            }
            sqLiteDataReader.NextResult();
            sqLiteDataReader.Read();
            return sqLiteDataReader.GetInt32(0);
          }
        }
      }
    }

    public override ErrorLogEntry GetError(string id)
    {
      if (id == null)
        throw new ArgumentNullException("id");
      if (id.Length == 0)
        throw new ArgumentException((string) null, "id");
      long num;
      try
      {
        num = long.Parse(id, (IFormatProvider) CultureInfo.InvariantCulture);
      }
      catch (FormatException ex)
      {
        throw new ArgumentException(ex.Message, "id", (Exception) ex);
      }
      using (SQLiteConnection connection = new SQLiteConnection(this.ConnectionString))
      {
        using (SQLiteCommand sqLiteCommand = new SQLiteCommand("\r\n                SELECT \r\n                    AllXml\r\n                FROM \r\n                    Error\r\n                WHERE\r\n                    ErrorId = @ErrorId", connection))
        {
          sqLiteCommand.Parameters.Add("@ErrorId", DbType.Int64).Value = (object) num;
          connection.Open();
          string xml = (string) sqLiteCommand.ExecuteScalar();
          if (xml == null)
            return (ErrorLogEntry) null;
          Error error = ErrorXml.DecodeString(xml);
          return new ErrorLogEntry((ErrorLog) this, id, error);
        }
      }
    }
  }
}
