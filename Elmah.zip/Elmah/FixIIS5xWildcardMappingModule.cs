﻿// Decompiled with JetBrains decompiler
// Type: Elmah.FixIIS5xWildcardMappingModule
// Assembly: Elmah, Version=1.2.14706.0, Culture=neutral, PublicKeyToken=null
// MVID: 6B433430-60BC-4287-8770-D3B3555B0D2B
// Assembly location: D:\Mata\transport-corp\trans-corp\transport-corp\App\Bin\Elmah.dll

using System;
using System.Configuration;
using System.Web;
using System.Web.Configuration;

namespace Elmah
{
  public sealed class FixIIS5xWildcardMappingModule : IHttpModule
  {
    private string _handlerPathWithForwardSlash;
    private int _handlerPathLength;

    private static string GetHandlerPath()
    {
      HttpHandlersSection section = ConfigurationManager.GetSection("system.web/httpHandlers") as HttpHandlersSection;
      string assemblyQualifiedName = typeof (ErrorLogPageFactory).AssemblyQualifiedName;
      foreach (HttpHandlerAction handler in (ConfigurationElementCollection) section.Handlers)
      {
        if (assemblyQualifiedName.IndexOf(handler.Type) == 0)
          return handler.Path;
      }
      return (string) null;
    }

    public void Init(HttpApplication context)
    {
      string handlerPath = FixIIS5xWildcardMappingModule.GetHandlerPath();
      if (handlerPath == null || handlerPath.Length <= 0)
        return;
      this._handlerPathWithForwardSlash = handlerPath;
      if ((int) this._handlerPathWithForwardSlash[this._handlerPathWithForwardSlash.Length - 1] != 47)
        this._handlerPathWithForwardSlash += "/";
      this._handlerPathLength = this._handlerPathWithForwardSlash.Length - 1;
      context.BeginRequest += new EventHandler(this.OnBeginRequest);
    }

    private void OnBeginRequest(object sender, EventArgs e)
    {
      HttpContext context = (sender as HttpApplication).Context;
      string path = context.Request.Path;
      int num = path.IndexOf(this._handlerPathWithForwardSlash, StringComparison.OrdinalIgnoreCase);
      if (num < 0)
        return;
      context.RewritePath(path.Substring(0, num + this._handlerPathLength), path.Substring(num + this._handlerPathLength), context.Request.QueryString.ToString());
    }

    public void Dispose()
    {
    }
  }
}
