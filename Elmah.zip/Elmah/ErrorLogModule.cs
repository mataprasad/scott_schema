﻿// Decompiled with JetBrains decompiler
// Type: Elmah.ErrorLogModule
// Assembly: Elmah, Version=1.2.14706.0, Culture=neutral, PublicKeyToken=null
// MVID: 6B433430-60BC-4287-8770-D3B3555B0D2B
// Assembly location: D:\Mata\transport-corp\trans-corp\transport-corp\App\Bin\Elmah.dll

using System;
using System.Diagnostics;
using System.Web;

namespace Elmah
{
  public class ErrorLogModule : HttpModuleBase, IExceptionFiltering
  {
    protected override bool SupportDiscoverability
    {
      get
      {
        return true;
      }
    }

    public event ExceptionFilterEventHandler Filtering;

    public event ErrorLoggedEventHandler Logged;

    protected override void OnInit(HttpApplication application)
    {
      if (application == null)
        throw new ArgumentNullException("application");
      application.Error += new EventHandler(this.OnError);
      ErrorSignal.Get(application).Raised += new ErrorSignalEventHandler(this.OnErrorSignaled);
    }

    protected virtual ErrorLog GetErrorLog(HttpContext context)
    {
      return ErrorLog.GetDefault(context);
    }

    protected virtual void OnError(object sender, EventArgs args)
    {
      HttpApplication httpApplication = (HttpApplication) sender;
      this.LogException(httpApplication.Server.GetLastError(), httpApplication.Context);
    }

    protected virtual void OnErrorSignaled(object sender, ErrorSignalEventArgs args)
    {
      this.LogException(args.Exception, args.Context);
    }

    protected virtual void LogException(Exception e, HttpContext context)
    {
      if (e == null)
        throw new ArgumentNullException("e");
      ExceptionFilterEventArgs args = new ExceptionFilterEventArgs(e, (object) context);
      this.OnFiltering(args);
      if (args.Dismissed)
        return;
      ErrorLogEntry entry = (ErrorLogEntry) null;
      try
      {
        Error error = new Error(e, context);
        ErrorLog errorLog = this.GetErrorLog(context);
        error.ApplicationName = errorLog.ApplicationName;
        string id = errorLog.Log(error);
        entry = new ErrorLogEntry(errorLog, id, error);
      }
      catch (Exception ex)
      {
        Trace.WriteLine((object) ex);
      }
      if (entry == null)
        return;
      this.OnLogged(new ErrorLoggedEventArgs(entry));
    }

    protected virtual void OnLogged(ErrorLoggedEventArgs args)
    {
      ErrorLoggedEventHandler logged = this.Logged;
      if (logged == null)
        return;
      logged((object) this, args);
    }

    protected virtual void OnFiltering(ExceptionFilterEventArgs args)
    {
      ExceptionFilterEventHandler filtering = this.Filtering;
      if (filtering == null)
        return;
      filtering((object) this, args);
    }
  }
}
