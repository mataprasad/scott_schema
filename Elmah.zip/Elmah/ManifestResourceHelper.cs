﻿// Decompiled with JetBrains decompiler
// Type: Elmah.ManifestResourceHelper
// Assembly: Elmah, Version=1.2.14706.0, Culture=neutral, PublicKeyToken=null
// MVID: 6B433430-60BC-4287-8770-D3B3555B0D2B
// Assembly location: D:\Mata\transport-corp\trans-corp\transport-corp\App\Bin\Elmah.dll

using System;
using System.IO;

namespace Elmah
{
  public class ManifestResourceHelper
  {
    public static void WriteResourceToStream(Stream outputStream, string resourceName)
    {
      Type type = typeof (ManifestResourceHelper);
      using (Stream manifestResourceStream = type.Assembly.GetManifestResourceStream(type, resourceName))
      {
        byte[] buffer = new byte[Math.Min(manifestResourceStream.Length, 4096L)];
        for (int count = manifestResourceStream.Read(buffer, 0, buffer.Length); count > 0; count = manifestResourceStream.Read(buffer, 0, buffer.Length))
          outputStream.Write(buffer, 0, count);
      }
    }
  }
}
