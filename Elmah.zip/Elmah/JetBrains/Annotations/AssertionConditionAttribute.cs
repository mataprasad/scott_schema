﻿// Decompiled with JetBrains decompiler
// Type: JetBrains.Annotations.AssertionConditionAttribute
// Assembly: Elmah, Version=1.2.14706.0, Culture=neutral, PublicKeyToken=null
// MVID: 6B433430-60BC-4287-8770-D3B3555B0D2B
// Assembly location: D:\Mata\transport-corp\trans-corp\transport-corp\App\Bin\Elmah.dll

using System;

namespace JetBrains.Annotations
{
  [AttributeUsage(AttributeTargets.Parameter, AllowMultiple = false, Inherited = true)]
  internal sealed class AssertionConditionAttribute : Attribute
  {
    private readonly AssertionConditionType myConditionType;

    public AssertionConditionType ConditionType
    {
      get
      {
        return this.myConditionType;
      }
    }

    public AssertionConditionAttribute(AssertionConditionType conditionType)
    {
      this.myConditionType = conditionType;
    }
  }
}
