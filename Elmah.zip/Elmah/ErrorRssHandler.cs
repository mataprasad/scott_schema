﻿// Decompiled with JetBrains decompiler
// Type: Elmah.ErrorRssHandler
// Assembly: Elmah, Version=1.2.14706.0, Culture=neutral, PublicKeyToken=null
// MVID: 6B433430-60BC-4287-8770-D3B3555B0D2B
// Assembly location: D:\Mata\transport-corp\trans-corp\transport-corp\App\Bin\Elmah.dll

using Elmah.ContentSyndication;
using System;
using System.Collections;
using System.Web;

namespace Elmah
{
  internal sealed class ErrorRssHandler : IHttpHandler
  {
    public bool IsReusable
    {
      get
      {
        return false;
      }
    }

    public void ProcessRequest(HttpContext context)
    {
      context.Response.ContentType = "application/xml";
      ArrayList arrayList = new ArrayList(15);
      ErrorLog errorLog = ErrorLog.GetDefault(context);
      errorLog.GetErrors(0, 15, (IList) arrayList);
      RichSiteSummary richSiteSummary = new RichSiteSummary();
      richSiteSummary.version = "0.91";
      Channel channel = new Channel();
      string machineName = Environment.TryGetMachineName(context);
      channel.title = "Error log of " + errorLog.ApplicationName + (machineName.Length > 0 ? " on " + machineName : (string) null);
      channel.description = "Log of recent errors";
      channel.language = "en";
      channel.link = ErrorLogPageFactory.GetRequestUrl(context).GetLeftPart(UriPartial.Authority) + context.Request.ServerVariables["URL"];
      richSiteSummary.channel = channel;
      channel.item = new Elmah.ContentSyndication.Item[arrayList.Count];
      for (int index = 0; index < arrayList.Count; ++index)
      {
        ErrorLogEntry errorLogEntry = (ErrorLogEntry) arrayList[index];
        Error error = errorLogEntry.Error;
        channel.item[index] = new Elmah.ContentSyndication.Item()
        {
          title = error.Message,
          description = "An error of type " + error.Type + " occurred. " + error.Message,
          link = channel.link + "/detail?id=" + HttpUtility.UrlEncode(errorLogEntry.Id),
          pubDate = error.Time.ToUniversalTime().ToString("r")
        };
      }
      context.Response.Write(XmlText.StripIllegalXmlCharacters(XmlSerializer.Serialize((object) richSiteSummary)));
    }
  }
}
