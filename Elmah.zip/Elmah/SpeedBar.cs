﻿// Decompiled with JetBrains decompiler
// Type: Elmah.SpeedBar
// Assembly: Elmah, Version=1.2.14706.0, Culture=neutral, PublicKeyToken=null
// MVID: 6B433430-60BC-4287-8770-D3B3555B0D2B
// Assembly location: D:\Mata\transport-corp\trans-corp\transport-corp\App\Bin\Elmah.dll

using System;
using System.IO;
using System.Web;
using System.Web.UI;

namespace Elmah
{
  internal sealed class SpeedBar
  {
    public static readonly SpeedBar.ItemTemplate Home = new SpeedBar.ItemTemplate("Errors", "List of logged errors", "{0}");
    public static readonly SpeedBar.ItemTemplate RssFeed = new SpeedBar.ItemTemplate("RSS Feed", "RSS feed of recent errors", "{0}/rss");
    public static readonly SpeedBar.ItemTemplate RssDigestFeed = new SpeedBar.ItemTemplate("RSS Digest", "RSS feed of errors within recent days", "{0}/digestrss");
    public static readonly SpeedBar.ItemTemplate DownloadLog = new SpeedBar.ItemTemplate("Download Log", "Download the entire log as CSV", "{0}/download");
    public static readonly SpeedBar.FormattedItem Help = new SpeedBar.FormattedItem("Help", "Documentation, discussions, issues and more", "http://elmah.googlecode.com/");
    public static readonly SpeedBar.ItemTemplate About = new SpeedBar.ItemTemplate("About", "Information about this version and build", "{0}/about");

    private SpeedBar()
    {
    }

    public static void Render(HtmlTextWriter writer, params SpeedBar.FormattedItem[] items)
    {
      if (items == null || items.Length == 0)
        return;
      writer.AddAttribute(HtmlTextWriterAttribute.Id, "SpeedList");
      writer.RenderBeginTag(HtmlTextWriterTag.Ul);
      foreach (SpeedBar.FormattedItem formattedItem in items)
      {
        writer.RenderBeginTag(HtmlTextWriterTag.Li);
        formattedItem.Render(writer);
        writer.RenderEndTag();
      }
      writer.RenderEndTag();
    }

    [Serializable]
    public abstract class Item
    {
      private readonly string _text;
      private readonly string _title;
      private readonly string _href;

      public string Text
      {
        get
        {
          return this._text;
        }
      }

      public string Title
      {
        get
        {
          return this._title;
        }
      }

      public string Href
      {
        get
        {
          return this._href;
        }
      }

      public Item(string text, string title, string href)
      {
        this._text = Mask.NullString(text);
        this._title = Mask.NullString(title);
        this._href = Mask.NullString(href);
      }

      public override string ToString()
      {
        return this.Text;
      }
    }

    [Serializable]
    public sealed class ItemTemplate : SpeedBar.Item
    {
      public ItemTemplate(string text, string title, string href)
        : base(text, title, href)
      {
      }

      public SpeedBar.FormattedItem Format(string url)
      {
        return new SpeedBar.FormattedItem(this.Text, this.Title, string.Format(this.Href, (object) url));
      }
    }

    [Serializable]
    public sealed class FormattedItem : SpeedBar.Item
    {
      public FormattedItem(string text, string title, string href)
        : base(text, title, href)
      {
      }

      public void Render(HtmlTextWriter writer)
      {
        writer.AddAttribute(HtmlTextWriterAttribute.Href, this.Href);
        writer.AddAttribute(HtmlTextWriterAttribute.Title, this.Title);
        writer.RenderBeginTag(HtmlTextWriterTag.A);
        HttpUtility.HtmlEncode(this.Text, (TextWriter) writer);
        writer.RenderEndTag();
      }
    }
  }
}
