﻿// Decompiled with JetBrains decompiler
// Type: Elmah.MySqlErrorLog
// Assembly: Elmah, Version=1.2.14706.0, Culture=neutral, PublicKeyToken=null
// MVID: 6B433430-60BC-4287-8770-D3B3555B0D2B
// Assembly location: D:\Mata\transport-corp\trans-corp\transport-corp\App\Bin\Elmah.dll

using MySql.Data.MySqlClient;
using System;
using System.Collections;
using System.Data;
using System.Data.Common;

namespace Elmah
{
  public class MySqlErrorLog : ErrorLog
  {
    private const int _maxAppNameLength = 60;
    private readonly string _connectionString;

    public override string Name
    {
      get
      {
        return "MySQL Server Error Log";
      }
    }

    public virtual string ConnectionString
    {
      get
      {
        return this._connectionString;
      }
    }

    public MySqlErrorLog(IDictionary config)
    {
      if (config == null)
        throw new ArgumentNullException("config");
      string connectionString = ConnectionStringHelper.GetConnectionString(config);
      if (connectionString.Length == 0)
        throw new ApplicationException("Connection string is missing for the SQL error log.");
      this._connectionString = connectionString;
      string str = Mask.NullString((string) config[(object) "applicationName"]);
      if (str.Length > 60)
        throw new ApplicationException(string.Format("Application name is too long. Maximum length allowed is {0} characters.", (object) 60.ToString("N0")));
      this.ApplicationName = str;
    }

    public MySqlErrorLog(string connectionString)
    {
      if (connectionString == null)
        throw new ArgumentNullException("connectionString");
      if (connectionString.Length == 0)
        throw new ArgumentException((string) null, "connectionString");
      this._connectionString = connectionString;
    }

    public override string Log(Error error)
    {
      if (error == null)
        throw new ArgumentNullException("error");
      string xml = ErrorXml.EncodeString(error);
      Guid id = Guid.NewGuid();
      using (MySqlConnection mySqlConnection = new MySqlConnection(this.ConnectionString))
      {
        using (MySqlCommand mySqlCommand = MySqlErrorLog.Commands.LogError(id, this.ApplicationName, error.HostName, error.Type, error.Source, error.Message, error.User, error.StatusCode, error.Time.ToUniversalTime(), xml))
        {
          mySqlCommand.set_Connection(mySqlConnection);
          ((DbConnection) mySqlConnection).Open();
          ((DbCommand) mySqlCommand).ExecuteNonQuery();
          return id.ToString();
        }
      }
    }

    public override int GetErrors(int pageIndex, int pageSize, IList errorEntryList)
    {
      if (pageIndex < 0)
        throw new ArgumentOutOfRangeException("pageIndex", (object) pageIndex, (string) null);
      if (pageSize < 0)
        throw new ArgumentOutOfRangeException("pageSize", (object) pageSize, (string) null);
      using (MySqlConnection mySqlConnection = new MySqlConnection(this.ConnectionString))
      {
        using (MySqlCommand errorsXml = MySqlErrorLog.Commands.GetErrorsXml(this.ApplicationName, pageIndex, pageSize))
        {
          errorsXml.set_Connection(mySqlConnection);
          ((DbConnection) mySqlConnection).Open();
          using (MySqlDataReader mySqlDataReader = errorsXml.ExecuteReader())
          {
            if (errorEntryList != null)
            {
              while (((DbDataReader) mySqlDataReader).Read())
                errorEntryList.Add((object) new ErrorLogEntry((ErrorLog) this, ((DbDataReader) mySqlDataReader)["ErrorId"].ToString(), new Error()
                {
                  ApplicationName = ((DbDataReader) mySqlDataReader)["Application"].ToString(),
                  HostName = ((DbDataReader) mySqlDataReader)["Host"].ToString(),
                  Type = ((DbDataReader) mySqlDataReader)["Type"].ToString(),
                  Source = ((DbDataReader) mySqlDataReader)["Source"].ToString(),
                  Message = ((DbDataReader) mySqlDataReader)["Message"].ToString(),
                  User = ((DbDataReader) mySqlDataReader)["User"].ToString(),
                  StatusCode = Convert.ToInt32(((DbDataReader) mySqlDataReader)["StatusCode"]),
                  Time = Convert.ToDateTime(mySqlDataReader.GetString("TimeUtc")).ToLocalTime()
                }));
            }
            ((DbDataReader) mySqlDataReader).Close();
          }
          return (int) ((DbParameter) errorsXml.get_Parameters().get_Item("TotalCount")).Value;
        }
      }
    }

    public override ErrorLogEntry GetError(string id)
    {
      if (id == null)
        throw new ArgumentNullException("id");
      if (id.Length == 0)
        throw new ArgumentException((string) null, "id");
      Guid id1;
      try
      {
        id1 = new Guid(id);
      }
      catch (FormatException ex)
      {
        throw new ArgumentException(ex.Message, "id", (Exception) ex);
      }
      string xml = (string) null;
      using (MySqlConnection mySqlConnection = new MySqlConnection(this.ConnectionString))
      {
        using (MySqlCommand errorXml = MySqlErrorLog.Commands.GetErrorXml(this.ApplicationName, id1))
        {
          errorXml.set_Connection(mySqlConnection);
          ((DbConnection) mySqlConnection).Open();
          using (MySqlDataReader mySqlDataReader = errorXml.ExecuteReader())
          {
            while (((DbDataReader) mySqlDataReader).Read())
              xml = mySqlDataReader.GetString("AllXml");
            ((DbDataReader) mySqlDataReader).Close();
          }
        }
      }
      if (xml == null)
        return (ErrorLogEntry) null;
      Error error = ErrorXml.DecodeString(xml);
      return new ErrorLogEntry((ErrorLog) this, id, error);
    }

    private static class Commands
    {
      public static MySqlCommand LogError(Guid id, string appName, string hostName, string typeName, string source, string message, string user, int statusCode, DateTime time, string xml)
      {
        MySqlCommand mySqlCommand = new MySqlCommand("elmah_LogError");
        ((DbCommand) mySqlCommand).CommandType = CommandType.StoredProcedure;
        MySqlParameterCollection parameters = mySqlCommand.get_Parameters();
        ((DbParameter) parameters.Add("ErrorId", (MySqlDbType) 254, 36)).Value = (object) id.ToString();
        ((DbParameter) parameters.Add("Application", (MySqlDbType) 253, 60)).Value = (object) appName.Substring(0, Math.Min(60, appName.Length));
        ((DbParameter) parameters.Add("Host", (MySqlDbType) 253, 30)).Value = (object) hostName.Substring(0, Math.Min(30, hostName.Length));
        ((DbParameter) parameters.Add("Type", (MySqlDbType) 253, 100)).Value = (object) typeName.Substring(0, Math.Min(100, typeName.Length));
        ((DbParameter) parameters.Add("Source", (MySqlDbType) 253, 60)).Value = (object) source.Substring(0, Math.Min(60, source.Length));
        ((DbParameter) parameters.Add("Message", (MySqlDbType) 253, 500)).Value = (object) message.Substring(0, Math.Min(500, message.Length));
        ((DbParameter) parameters.Add("User", (MySqlDbType) 253, 50)).Value = (object) user.Substring(0, Math.Min(50, user.Length));
        ((DbParameter) parameters.Add("AllXml", (MySqlDbType) 752)).Value = (object) xml;
        ((DbParameter) parameters.Add("StatusCode", (MySqlDbType) 3)).Value = (object) statusCode;
        ((DbParameter) parameters.Add("TimeUtc", (MySqlDbType) 12)).Value = (object) time;
        return mySqlCommand;
      }

      public static MySqlCommand GetErrorXml(string appName, Guid id)
      {
        MySqlCommand mySqlCommand = new MySqlCommand("elmah_GetErrorXml");
        ((DbCommand) mySqlCommand).CommandType = CommandType.StoredProcedure;
        MySqlParameterCollection parameters = mySqlCommand.get_Parameters();
        ((DbParameter) parameters.Add("Id", (MySqlDbType) 254, 36)).Value = (object) id.ToString();
        ((DbParameter) parameters.Add("App", (MySqlDbType) 253, 60)).Value = (object) appName.Substring(0, Math.Min(60, appName.Length));
        return mySqlCommand;
      }

      public static MySqlCommand GetErrorsXml(string appName, int pageIndex, int pageSize)
      {
        MySqlCommand mySqlCommand = new MySqlCommand("elmah_GetErrorsXml");
        ((DbCommand) mySqlCommand).CommandType = CommandType.StoredProcedure;
        MySqlParameterCollection parameters = mySqlCommand.get_Parameters();
        ((DbParameter) parameters.Add("App", (MySqlDbType) 253, 60)).Value = (object) appName.Substring(0, Math.Min(60, appName.Length));
        ((DbParameter) parameters.Add("PageIndex", (MySqlDbType) 3)).Value = (object) pageIndex;
        ((DbParameter) parameters.Add("PageSize", (MySqlDbType) 3)).Value = (object) pageSize;
        ((DbParameter) parameters.Add("TotalCount", (MySqlDbType) 3)).Direction = ParameterDirection.Output;
        return mySqlCommand;
      }

      public static void GetErrorsXmlOutputs(MySqlCommand command, out int totalCount)
      {
        totalCount = (int) ((DbParameter) command.get_Parameters().get_Item("TotalCount")).Value;
      }
    }
  }
}
