﻿// Decompiled with JetBrains decompiler
// Type: Elmah.XmlSerializer
// Assembly: Elmah, Version=1.2.14706.0, Culture=neutral, PublicKeyToken=null
// MVID: 6B433430-60BC-4287-8770-D3B3555B0D2B
// Assembly location: D:\Mata\transport-corp\trans-corp\transport-corp\App\Bin\Elmah.dll

using System.IO;
using System.Xml;

namespace Elmah
{
  internal sealed class XmlSerializer
  {
    private XmlSerializer()
    {
    }

    public static string Serialize(object obj)
    {
      StringWriter stringWriter = new StringWriter();
      XmlSerializer.Serialize(obj, (TextWriter) stringWriter);
      return stringWriter.GetStringBuilder().ToString();
    }

    public static void Serialize(object obj, TextWriter output)
    {
      XmlWriter xmlWriter = XmlWriter.Create(output, new XmlWriterSettings() { Indent = true, NewLineOnAttributes = true, CheckCharacters = false, OmitXmlDeclaration = true });
      try
      {
        new System.Xml.Serialization.XmlSerializer(obj.GetType()).Serialize(xmlWriter, obj);
        xmlWriter.Flush();
      }
      finally
      {
        xmlWriter.Close();
      }
    }
  }
}
