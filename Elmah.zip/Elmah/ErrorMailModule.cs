﻿// Decompiled with JetBrains decompiler
// Type: Elmah.ErrorMailModule
// Assembly: Elmah, Version=1.2.14706.0, Culture=neutral, PublicKeyToken=null
// MVID: 6B433430-60BC-4287-8770-D3B3555B0D2B
// Assembly location: D:\Mata\transport-corp\trans-corp\transport-corp\App\Bin\Elmah.dll

using System;
using System.Collections;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Net;
using System.Net.Mail;
using System.Text;
using System.Threading;
using System.Web;

namespace Elmah
{
  public class ErrorMailModule : HttpModuleBase, IExceptionFiltering
  {
    private string _mailSender;
    private string _mailRecipient;
    private string _mailCopyRecipient;
    private string _mailSubjectFormat;
    private MailPriority _mailPriority;
    private bool _reportAsynchronously;
    private string _smtpServer;
    private int _smtpPort;
    private string _authUserName;
    private string _authPassword;
    private bool _noYsod;
    private bool _useSsl;

    protected override bool SupportDiscoverability
    {
      get
      {
        return true;
      }
    }

    protected virtual string MailSender
    {
      get
      {
        return this._mailSender;
      }
    }

    protected virtual string MailRecipient
    {
      get
      {
        return this._mailRecipient;
      }
    }

    protected virtual string MailCopyRecipient
    {
      get
      {
        return this._mailCopyRecipient;
      }
    }

    protected virtual string MailSubjectFormat
    {
      get
      {
        return this._mailSubjectFormat;
      }
    }

    protected virtual MailPriority MailPriority
    {
      get
      {
        return this._mailPriority;
      }
    }

    protected string SmtpServer
    {
      get
      {
        return this._smtpServer;
      }
    }

    protected int SmtpPort
    {
      get
      {
        return this._smtpPort;
      }
    }

    protected string AuthUserName
    {
      get
      {
        return this._authUserName;
      }
    }

    protected string AuthPassword
    {
      get
      {
        return this._authPassword;
      }
    }

    protected bool NoYsod
    {
      get
      {
        return this._noYsod;
      }
    }

    protected bool UseSsl
    {
      get
      {
        return this._useSsl;
      }
    }

    public event ExceptionFilterEventHandler Filtering;

    public event ErrorMailEventHandler Mailing;

    public event ErrorMailEventHandler Mailed;

    public event ErrorMailEventHandler DisposingMail;

    protected override void OnInit(HttpApplication application)
    {
      if (application == null)
        throw new ArgumentNullException("application");
      IDictionary config = (IDictionary) this.GetConfig();
      if (config == null)
        return;
      string setting1 = ErrorMailModule.GetSetting(config, "to");
      string setting2 = ErrorMailModule.GetSetting(config, "from", setting1);
      string setting3 = ErrorMailModule.GetSetting(config, "cc", string.Empty);
      string setting4 = ErrorMailModule.GetSetting(config, "subject", string.Empty);
      MailPriority mailPriority = (MailPriority) System.Enum.Parse(typeof (MailPriority), ErrorMailModule.GetSetting(config, "priority", MailPriority.Normal.ToString()), true);
      bool boolean1 = Convert.ToBoolean(ErrorMailModule.GetSetting(config, "async", bool.TrueString));
      string setting5 = ErrorMailModule.GetSetting(config, "smtpServer", string.Empty);
      int uint16 = (int) Convert.ToUInt16(ErrorMailModule.GetSetting(config, "smtpPort", "0"), (IFormatProvider) CultureInfo.InvariantCulture);
      string setting6 = ErrorMailModule.GetSetting(config, "userName", string.Empty);
      string setting7 = ErrorMailModule.GetSetting(config, "password", string.Empty);
      bool boolean2 = Convert.ToBoolean(ErrorMailModule.GetSetting(config, "noYsod", bool.FalseString));
      bool boolean3 = Convert.ToBoolean(ErrorMailModule.GetSetting(config, "useSsl", bool.FalseString));
      application.Error += new EventHandler(this.OnError);
      ErrorSignal.Get(application).Raised += new ErrorSignalEventHandler(this.OnErrorSignaled);
      this._mailRecipient = setting1;
      this._mailSender = setting2;
      this._mailCopyRecipient = setting3;
      this._mailSubjectFormat = setting4;
      this._mailPriority = mailPriority;
      this._reportAsynchronously = boolean1;
      this._smtpServer = setting5;
      this._smtpPort = uint16;
      this._authUserName = setting6;
      this._authPassword = setting7;
      this._noYsod = boolean2;
      this._useSsl = boolean3;
    }

    protected virtual void OnError(object sender, EventArgs e)
    {
      HttpContext context = ((HttpApplication) sender).Context;
      this.OnError(context.Server.GetLastError(), context);
    }

    protected virtual void OnErrorSignaled(object sender, ErrorSignalEventArgs args)
    {
      this.OnError(args.Exception, args.Context);
    }

    protected virtual void OnError(Exception e, HttpContext context)
    {
      if (e == null)
        throw new ArgumentNullException("e");
      ExceptionFilterEventArgs args = new ExceptionFilterEventArgs(e, (object) context);
      this.OnFiltering(args);
      if (args.Dismissed)
        return;
      Error error = new Error(e, context);
      if (this._reportAsynchronously)
        this.ReportErrorAsync(error);
      else
        this.ReportError(error);
    }

    protected virtual void OnFiltering(ExceptionFilterEventArgs args)
    {
      ExceptionFilterEventHandler filtering = this.Filtering;
      if (filtering == null)
        return;
      filtering((object) this, args);
    }

    protected virtual void ReportErrorAsync(Error error)
    {
      if (error == null)
        throw new ArgumentNullException("error");
      ThreadPool.QueueUserWorkItem(new WaitCallback(this.ReportError), (object) error);
    }

    private void ReportError(object state)
    {
      try
      {
        this.ReportError((Error) state);
      }
      catch (SmtpException ex)
      {
        Trace.TraceError(ex.ToString());
      }
    }

    protected virtual void ReportError(Error error)
    {
      if (error == null)
        throw new ArgumentNullException("error");
      string address = Mask.NullString(this.MailSender);
      string addresses1 = Mask.NullString(this.MailRecipient);
      string addresses2 = Mask.NullString(this.MailCopyRecipient);
      if (addresses1.Length == 0)
        return;
      MailMessage mail = new MailMessage();
      mail.Priority = this.MailPriority;
      mail.From = new MailAddress(address);
      mail.To.Add(addresses1);
      if (addresses2.Length > 0)
        mail.CC.Add(addresses2);
      string format = Mask.EmptyString(this.MailSubjectFormat, "Error ({1}): {0}");
      mail.Subject = string.Format(format, (object) error.Message, (object) error.Type).Replace('\r', ' ').Replace('\n', ' ');
      ErrorTextFormatter errorFormatter = this.CreateErrorFormatter();
      StringWriter stringWriter = new StringWriter();
      errorFormatter.Format((TextWriter) stringWriter, error);
      mail.Body = stringWriter.ToString();
      switch (errorFormatter.MimeType)
      {
        case "text/html":
          mail.IsBodyHtml = true;
          break;
        case "text/plain":
          mail.IsBodyHtml = false;
          break;
        default:
          throw new ApplicationException(string.Format("The error mail module does not know how to handle the {1} media type that is created by the {0} formatter.", (object) errorFormatter.GetType().FullName, (object) errorFormatter.MimeType));
      }
      ErrorMailEventArgs args = new ErrorMailEventArgs(error, mail);
      try
      {
        if (!this.NoYsod && error.WebHostHtmlMessage.Length > 0)
        {
          Attachment htmlAttachment = ErrorMailModule.CreateHtmlAttachment("YSOD", error.WebHostHtmlMessage);
          if (htmlAttachment != null)
            mail.Attachments.Add(htmlAttachment);
        }
        this.OnMailing(args);
        this.SendMail(mail);
        this.OnMailed(args);
      }
      finally
      {
        this.OnDisposingMail(args);
        mail.Dispose();
      }
    }

    private static Attachment CreateHtmlAttachment(string name, string html)
    {
      return Attachment.CreateAttachmentFromString(html, name + ".html", Encoding.UTF8, "text/html");
    }

    protected virtual ErrorTextFormatter CreateErrorFormatter()
    {
      return (ErrorTextFormatter) new ErrorMailHtmlFormatter();
    }

    protected virtual void SendMail(MailMessage mail)
    {
      if (mail == null)
        throw new ArgumentNullException("mail");
      SmtpClient smtpClient = new SmtpClient();
      string str = this.SmtpServer ?? string.Empty;
      if (str.Length > 0)
      {
        smtpClient.Host = str;
        smtpClient.DeliveryMethod = SmtpDeliveryMethod.Network;
      }
      int smtpPort = this.SmtpPort;
      if (smtpPort > 0)
        smtpClient.Port = smtpPort;
      string userName = this.AuthUserName ?? string.Empty;
      string password = this.AuthPassword ?? string.Empty;
      if (userName.Length > 0 && password.Length > 0)
        smtpClient.Credentials = (ICredentialsByHost) new NetworkCredential(userName, password);
      smtpClient.EnableSsl = this.UseSsl;
      smtpClient.Send(mail);
    }

    protected virtual void OnMailing(ErrorMailEventArgs args)
    {
      if (args == null)
        throw new ArgumentNullException("args");
      ErrorMailEventHandler mailing = this.Mailing;
      if (mailing == null)
        return;
      mailing((object) this, args);
    }

    protected virtual void OnMailed(ErrorMailEventArgs args)
    {
      if (args == null)
        throw new ArgumentNullException("args");
      ErrorMailEventHandler mailed = this.Mailed;
      if (mailed == null)
        return;
      mailed((object) this, args);
    }

    protected virtual void OnDisposingMail(ErrorMailEventArgs args)
    {
      if (args == null)
        throw new ArgumentNullException("args");
      ErrorMailEventHandler disposingMail = this.DisposingMail;
      if (disposingMail == null)
        return;
      disposingMail((object) this, args);
    }

    protected virtual object GetConfig()
    {
      return Configuration.GetSubsection("errorMail");
    }

    [Obsolete]
    protected virtual Error GetLastError(HttpContext context)
    {
      throw new NotSupportedException();
    }

    private static string GetSetting(IDictionary config, string name)
    {
      return ErrorMailModule.GetSetting(config, name, (string) null);
    }

    private static string GetSetting(IDictionary config, string name, string defaultValue)
    {
      string str = Mask.NullString((string) config[(object) name]);
      if (str.Length == 0)
      {
        if (defaultValue == null)
          throw new ApplicationException(string.Format("The required configuration setting '{0}' is missing for the error mailing module.", (object) name));
        str = defaultValue;
      }
      return str;
    }
  }
}
