﻿// Decompiled with JetBrains decompiler
// Type: Elmah.ErrorLogDataSourceAdapter
// Assembly: Elmah, Version=1.2.14706.0, Culture=neutral, PublicKeyToken=null
// MVID: 6B433430-60BC-4287-8770-D3B3555B0D2B
// Assembly location: D:\Mata\transport-corp\trans-corp\transport-corp\App\Bin\Elmah.dll

using System.Collections;
using System.Collections.Generic;
using System.Web;

namespace Elmah
{
  public sealed class ErrorLogDataSourceAdapter
  {
    private readonly ErrorLog _log;

    public ErrorLogDataSourceAdapter()
    {
      this._log = ErrorLog.GetDefault(HttpContext.Current);
    }

    public int GetErrorCount()
    {
      return this._log.GetErrors(0, 0, (IList) null);
    }

    public ErrorLogEntry[] GetErrors(int startRowIndex, int maximumRows)
    {
      return this.GetErrorsPage(startRowIndex / maximumRows, maximumRows);
    }

    private ErrorLogEntry[] GetErrorsPage(int index, int size)
    {
      List<ErrorLogEntry> errorLogEntryList = new List<ErrorLogEntry>(size);
      this._log.GetErrors(index, size, (IList) errorLogEntryList);
      return errorLogEntryList.ToArray();
    }
  }
}
