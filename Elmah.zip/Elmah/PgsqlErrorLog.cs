﻿// Decompiled with JetBrains decompiler
// Type: Elmah.PgsqlErrorLog
// Assembly: Elmah, Version=1.2.14706.0, Culture=neutral, PublicKeyToken=null
// MVID: 6B433430-60BC-4287-8770-D3B3555B0D2B
// Assembly location: D:\Mata\transport-corp\trans-corp\transport-corp\App\Bin\Elmah.dll

using Npgsql;
using NpgsqlTypes;
using System;
using System.Collections;
using System.Data.Common;

namespace Elmah
{
  public class PgsqlErrorLog : ErrorLog
  {
    private const int _maxAppNameLength = 60;
    private readonly string _connectionString;

    public override string Name
    {
      get
      {
        return "PostgreSQL Error Log";
      }
    }

    public virtual string ConnectionString
    {
      get
      {
        return this._connectionString;
      }
    }

    public PgsqlErrorLog(IDictionary config)
    {
      if (config == null)
        throw new ArgumentNullException("config");
      string connectionString = ConnectionStringHelper.GetConnectionString(config);
      if (connectionString.Length == 0)
        throw new ApplicationException("Connection string is missing for the Postgres SQL error log.");
      this._connectionString = connectionString;
      string str = Mask.NullString((string) config[(object) "applicationName"]);
      if (str.Length > 60)
        throw new ApplicationException(string.Format("Application name is too long. Maximum length allowed is {0} characters.", (object) 60.ToString("N0")));
      this.ApplicationName = str;
    }

    public PgsqlErrorLog(string connectionString)
    {
      if (connectionString == null)
        throw new ArgumentNullException("connectionString");
      if (connectionString.Length == 0)
        throw new ArgumentException((string) null, "connectionString");
      this._connectionString = connectionString;
    }

    public override string Log(Error error)
    {
      if (error == null)
        throw new ArgumentNullException("error");
      string xml = ErrorXml.EncodeString(error);
      Guid id = Guid.NewGuid();
      using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(this.ConnectionString))
      {
        using (NpgsqlCommand npgsqlCommand = PgsqlErrorLog.Commands.LogError(id, this.ApplicationName, error.HostName, error.Type, error.Source, error.Message, error.User, error.StatusCode, error.Time, xml))
        {
          npgsqlCommand.set_Connection(npgsqlConnection);
          ((DbConnection) npgsqlConnection).Open();
          ((DbCommand) npgsqlCommand).ExecuteNonQuery();
          return id.ToString();
        }
      }
    }

    public override ErrorLogEntry GetError(string id)
    {
      if (id == null)
        throw new ArgumentNullException("id");
      if (id.Length == 0)
        throw new ArgumentException((string) null, "id");
      Guid id1;
      try
      {
        id1 = new Guid(id);
      }
      catch (FormatException ex)
      {
        throw new ArgumentException(ex.Message, "id", (Exception) ex);
      }
      string xml;
      using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(this.ConnectionString))
      {
        using (NpgsqlCommand errorXml = PgsqlErrorLog.Commands.GetErrorXml(this.ApplicationName, id1))
        {
          errorXml.set_Connection(npgsqlConnection);
          ((DbConnection) npgsqlConnection).Open();
          xml = (string) ((DbCommand) errorXml).ExecuteScalar();
        }
      }
      if (xml == null)
        return (ErrorLogEntry) null;
      Error error = ErrorXml.DecodeString(xml);
      return new ErrorLogEntry((ErrorLog) this, id, error);
    }

    public override int GetErrors(int pageIndex, int pageSize, IList errorEntryList)
    {
      if (pageIndex < 0)
        throw new ArgumentOutOfRangeException("pageIndex", (object) pageIndex, (string) null);
      if (pageSize < 0)
        throw new ArgumentOutOfRangeException("pageSize", (object) pageSize, (string) null);
      using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(this.ConnectionString))
      {
        ((DbConnection) npgsqlConnection).Open();
        using (NpgsqlCommand errorsXml = PgsqlErrorLog.Commands.GetErrorsXml(this.ApplicationName, pageIndex, pageSize))
        {
          errorsXml.set_Connection(npgsqlConnection);
          using (NpgsqlDataReader npgsqlDataReader = errorsXml.ExecuteReader())
          {
            while (((DbDataReader) npgsqlDataReader).Read())
            {
              string id = ((DbDataReader) npgsqlDataReader).GetString(0);
              Error error = ErrorXml.DecodeString(((DbDataReader) npgsqlDataReader).GetString(1));
              errorEntryList.Add((object) new ErrorLogEntry((ErrorLog) this, id, error));
            }
          }
        }
        using (NpgsqlCommand errorsXmlTotal = PgsqlErrorLog.Commands.GetErrorsXmlTotal(this.ApplicationName))
        {
          errorsXmlTotal.set_Connection(npgsqlConnection);
          return Convert.ToInt32(((DbCommand) errorsXmlTotal).ExecuteScalar());
        }
      }
    }

    private static class Commands
    {
      public static NpgsqlCommand LogError(Guid id, string appName, string hostName, string typeName, string source, string message, string user, int statusCode, DateTime time, string xml)
      {
        NpgsqlCommand npgsqlCommand = new NpgsqlCommand();
        ((DbCommand) npgsqlCommand).CommandText = "\r\nINSERT INTO Elmah_Error (ErrorId, Application, Host, Type, Source, Message, \"User\", StatusCode, TimeUtc, AllXml)\r\nVALUES (@ErrorId, @Application, @Host, @Type, @Source, @Message, @User, @StatusCode, @TimeUtc, @AllXml)\r\n";
        npgsqlCommand.get_Parameters().Add(new NpgsqlParameter("ErrorId", (object) id));
        npgsqlCommand.get_Parameters().Add(new NpgsqlParameter("Application", (object) appName));
        npgsqlCommand.get_Parameters().Add(new NpgsqlParameter("Host", (object) hostName));
        npgsqlCommand.get_Parameters().Add(new NpgsqlParameter("Type", (object) typeName));
        npgsqlCommand.get_Parameters().Add(new NpgsqlParameter("Source", (object) source));
        npgsqlCommand.get_Parameters().Add(new NpgsqlParameter("Message", (object) message));
        npgsqlCommand.get_Parameters().Add(new NpgsqlParameter("User", (object) user));
        npgsqlCommand.get_Parameters().Add(new NpgsqlParameter("StatusCode", (object) statusCode));
        npgsqlCommand.get_Parameters().Add(new NpgsqlParameter("TimeUtc", (object) time.ToUniversalTime()));
        npgsqlCommand.get_Parameters().Add(new NpgsqlParameter("AllXml", (object) xml));
        return npgsqlCommand;
      }

      public static NpgsqlCommand GetErrorXml(string appName, Guid id)
      {
        NpgsqlCommand npgsqlCommand = new NpgsqlCommand();
        ((DbCommand) npgsqlCommand).CommandText = "\r\nSELECT AllXml FROM Elmah_Error \r\nWHERE \r\n    Application = @Application \r\n    AND ErrorId = @ErrorId\r\n";
        npgsqlCommand.get_Parameters().Add(new NpgsqlParameter("Application", (object) appName));
        npgsqlCommand.get_Parameters().Add(new NpgsqlParameter("ErrorId", (object) id));
        return npgsqlCommand;
      }

      public static NpgsqlCommand GetErrorsXml(string appName, int pageIndex, int pageSize)
      {
        NpgsqlCommand npgsqlCommand = new NpgsqlCommand();
        ((DbCommand) npgsqlCommand).CommandText = "\r\nSELECT ErrorId, AllXml FROM Elmah_Error\r\nWHERE\r\n    Application = @Application\r\nORDER BY Sequence DESC\r\nOFFSET @offset\r\nLIMIT @limit\r\n";
        ((DbParameter) npgsqlCommand.get_Parameters().Add("@Application", (NpgsqlDbType) 19, 60)).Value = (object) appName;
        ((DbParameter) npgsqlCommand.get_Parameters().Add("@offset", (NpgsqlDbType) 9)).Value = (object) (pageIndex * pageSize);
        ((DbParameter) npgsqlCommand.get_Parameters().Add("@limit", (NpgsqlDbType) 9)).Value = (object) pageSize;
        return npgsqlCommand;
      }

      public static NpgsqlCommand GetErrorsXmlTotal(string appName)
      {
        NpgsqlCommand npgsqlCommand = new NpgsqlCommand();
        ((DbCommand) npgsqlCommand).CommandText = "SELECT COUNT(*) FROM Elmah_Error WHERE Application = @Application";
        ((DbParameter) npgsqlCommand.get_Parameters().Add("@Application", (NpgsqlDbType) 19, 60)).Value = (object) appName;
        return npgsqlCommand;
      }
    }
  }
}
