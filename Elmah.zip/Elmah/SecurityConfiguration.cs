﻿// Decompiled with JetBrains decompiler
// Type: Elmah.SecurityConfiguration
// Assembly: Elmah, Version=1.2.14706.0, Culture=neutral, PublicKeyToken=null
// MVID: 6B433430-60BC-4287-8770-D3B3555B0D2B
// Assembly location: D:\Mata\transport-corp\trans-corp\transport-corp\App\Bin\Elmah.dll

using System;
using System.Collections;
using System.Globalization;

namespace Elmah
{
  [Serializable]
  internal sealed class SecurityConfiguration
  {
    private static readonly string[] _trues = new string[4]{ "true", "yes", "on", "1" };
    public static readonly SecurityConfiguration Default = new SecurityConfiguration((IDictionary) Configuration.GetSubsection("security"));
    private readonly bool _allowRemoteAccess;

    public bool AllowRemoteAccess
    {
      get
      {
        return this._allowRemoteAccess;
      }
    }

    public SecurityConfiguration(IDictionary options)
    {
      this._allowRemoteAccess = SecurityConfiguration.GetBoolean(options, "allowRemoteAccess");
    }

    private static bool GetBoolean(IDictionary options, string name)
    {
      string lower = SecurityConfiguration.GetString(options, name).Trim().ToLower(CultureInfo.InvariantCulture);
      return bool.TrueString.Equals(StringTranslation.Translate(bool.TrueString, lower, SecurityConfiguration._trues));
    }

    private static string GetString(IDictionary options, string name)
    {
      if (options == null)
        return string.Empty;
      object option = options[(object) name];
      if (option == null)
        return string.Empty;
      return Mask.NullString(option.ToString());
    }
  }
}
