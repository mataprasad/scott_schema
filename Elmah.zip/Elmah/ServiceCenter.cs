﻿// Decompiled with JetBrains decompiler
// Type: Elmah.ServiceCenter
// Assembly: Elmah, Version=1.2.14706.0, Culture=neutral, PublicKeyToken=null
// MVID: 6B433430-60BC-4287-8770-D3B3555B0D2B
// Assembly location: D:\Mata\transport-corp\trans-corp\transport-corp\App\Bin\Elmah.dll

using System;

namespace Elmah
{
  public sealed class ServiceCenter
  {
    private static ServiceProviderQueryHandler _current = ServiceCenter.Default = new ServiceProviderQueryHandler(ServiceCenter.CreateServiceContainer);
    public static readonly ServiceProviderQueryHandler Default;

    public static ServiceProviderQueryHandler Current
    {
      get
      {
        return ServiceCenter._current;
      }
      set
      {
        if (value == null)
          throw new ArgumentNullException("value");
        ServiceCenter._current = value;
      }
    }

    private ServiceCenter()
    {
    }

    private static IServiceProvider CreateServiceContainer(object context)
    {
      return (IServiceProvider) new ServiceContainer(context);
    }

    public static object FindService(object context, Type serviceType)
    {
      if (serviceType == null)
        throw new ArgumentNullException("serviceType");
      return ServiceCenter.GetServiceProvider(context).GetService(serviceType);
    }

    public static object GetService(object context, Type serviceType)
    {
      object service = ServiceCenter.FindService(context, serviceType);
      if (service == null)
        throw new Exception(string.Format("Service of the type {0} is not available.", (object) serviceType));
      return service;
    }

    public static IServiceProvider GetServiceProvider(object context)
    {
      IServiceProvider serviceProvider = ServiceCenter.Current(context);
      if (serviceProvider == null)
        throw new Exception("Service provider not available.");
      return serviceProvider;
    }
  }
}
