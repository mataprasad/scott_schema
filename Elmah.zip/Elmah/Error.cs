﻿// Decompiled with JetBrains decompiler
// Type: Elmah.Error
// Assembly: Elmah, Version=1.2.14706.0, Culture=neutral, PublicKeyToken=null
// MVID: 6B433430-60BC-4287-8770-D3B3555B0D2B
// Assembly location: D:\Mata\transport-corp\trans-corp\transport-corp\App\Bin\Elmah.dll

using System;
using System.Collections.Specialized;
using System.Diagnostics;
using System.Security;
using System.Security.Principal;
using System.Threading;
using System.Web;

namespace Elmah
{
  [Serializable]
  public sealed class Error : ICloneable
  {
    private readonly Exception _exception;
    private string _applicationName;
    private string _hostName;
    private string _typeName;
    private string _source;
    private string _message;
    private string _detail;
    private string _user;
    private DateTime _time;
    private int _statusCode;
    private string _webHostHtmlMessage;
    private NameValueCollection _serverVariables;
    private NameValueCollection _queryString;
    private NameValueCollection _form;
    private NameValueCollection _cookies;

    public Exception Exception
    {
      get
      {
        return this._exception;
      }
    }

    public string ApplicationName
    {
      get
      {
        return Mask.NullString(this._applicationName);
      }
      set
      {
        this._applicationName = value;
      }
    }

    public string HostName
    {
      get
      {
        return Mask.NullString(this._hostName);
      }
      set
      {
        this._hostName = value;
      }
    }

    public string Type
    {
      get
      {
        return Mask.NullString(this._typeName);
      }
      set
      {
        this._typeName = value;
      }
    }

    public string Source
    {
      get
      {
        return Mask.NullString(this._source);
      }
      set
      {
        this._source = value;
      }
    }

    public string Message
    {
      get
      {
        return Mask.NullString(this._message);
      }
      set
      {
        this._message = value;
      }
    }

    public string Detail
    {
      get
      {
        return Mask.NullString(this._detail);
      }
      set
      {
        this._detail = value;
      }
    }

    public string User
    {
      get
      {
        return Mask.NullString(this._user);
      }
      set
      {
        this._user = value;
      }
    }

    public DateTime Time
    {
      get
      {
        return this._time;
      }
      set
      {
        this._time = value;
      }
    }

    public int StatusCode
    {
      get
      {
        return this._statusCode;
      }
      set
      {
        this._statusCode = value;
      }
    }

    public string WebHostHtmlMessage
    {
      get
      {
        return Mask.NullString(this._webHostHtmlMessage);
      }
      set
      {
        this._webHostHtmlMessage = value;
      }
    }

    public NameValueCollection ServerVariables
    {
      get
      {
        return Error.FaultIn(ref this._serverVariables);
      }
    }

    public NameValueCollection QueryString
    {
      get
      {
        return Error.FaultIn(ref this._queryString);
      }
    }

    public NameValueCollection Form
    {
      get
      {
        return Error.FaultIn(ref this._form);
      }
    }

    public NameValueCollection Cookies
    {
      get
      {
        return Error.FaultIn(ref this._cookies);
      }
    }

    public Error()
    {
    }

    public Error(Exception e)
      : this(e, (HttpContext) null)
    {
    }

    public Error(Exception e, HttpContext context)
    {
      if (e == null)
        throw new ArgumentNullException("e");
      this._exception = e;
      Exception baseException = e.GetBaseException();
      this._hostName = Environment.TryGetMachineName(context);
      this._typeName = baseException.GetType().FullName;
      this._message = baseException.Message;
      this._source = baseException.Source;
      this._detail = e.ToString();
      this._user = Mask.NullString(Thread.CurrentPrincipal.Identity.Name);
      this._time = DateTime.Now;
      HttpException e1 = e as HttpException;
      if (e1 != null)
      {
        this._statusCode = e1.GetHttpCode();
        this._webHostHtmlMessage = Error.TryGetHtmlErrorMessage(e1);
      }
      if (context == null)
        return;
      IPrincipal user = context.User;
      if (user != null && Mask.NullString(user.Identity.Name).Length > 0)
        this._user = user.Identity.Name;
      HttpRequest request = context.Request;
      this._serverVariables = Error.CopyCollection(request.ServerVariables);
      if (this._serverVariables != null && this._serverVariables["AUTH_PASSWORD"] != null)
        this._serverVariables["AUTH_PASSWORD"] = "*****";
      this._queryString = Error.CopyCollection(request.QueryString);
      this._form = Error.CopyCollection(request.Form);
      this._cookies = Error.CopyCollection(request.Cookies);
    }

    private static string TryGetHtmlErrorMessage(HttpException e)
    {
      try
      {
        return e.GetHtmlErrorMessage();
      }
      catch (SecurityException ex)
      {
        Trace.WriteLine((object) ex);
        return (string) null;
      }
    }

    public override string ToString()
    {
      return this.Message;
    }

    object ICloneable.Clone()
    {
      Error error = (Error) this.MemberwiseClone();
      error._serverVariables = Error.CopyCollection(this._serverVariables);
      error._queryString = Error.CopyCollection(this._queryString);
      error._form = Error.CopyCollection(this._form);
      error._cookies = Error.CopyCollection(this._cookies);
      return (object) error;
    }

    private static NameValueCollection CopyCollection(NameValueCollection collection)
    {
      if (collection == null || collection.Count == 0)
        return (NameValueCollection) null;
      return new NameValueCollection(collection);
    }

    private static NameValueCollection CopyCollection(HttpCookieCollection cookies)
    {
      if (cookies == null || cookies.Count == 0)
        return (NameValueCollection) null;
      NameValueCollection nameValueCollection = new NameValueCollection(cookies.Count);
      for (int index = 0; index < cookies.Count; ++index)
      {
        HttpCookie cookie = cookies[index];
        nameValueCollection.Add(cookie.Name, cookie.Value);
      }
      return nameValueCollection;
    }

    private static NameValueCollection FaultIn(ref NameValueCollection collection)
    {
      if (collection == null)
        collection = new NameValueCollection();
      return collection;
    }
  }
}
