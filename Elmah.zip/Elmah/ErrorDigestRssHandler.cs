﻿// Decompiled with JetBrains decompiler
// Type: Elmah.ErrorDigestRssHandler
// Assembly: Elmah, Version=1.2.14706.0, Culture=neutral, PublicKeyToken=null
// MVID: 6B433430-60BC-4287-8770-D3B3555B0D2B
// Assembly location: D:\Mata\transport-corp\trans-corp\transport-corp\App\Bin\Elmah.dll

using Elmah.ContentSyndication;
using System;
using System.Collections;
using System.IO;
using System.Text;
using System.Web;
using System.Web.UI;

namespace Elmah
{
  internal sealed class ErrorDigestRssHandler : IHttpHandler
  {
    private HttpContext _context;

    public bool IsReusable
    {
      get
      {
        return false;
      }
    }

    private HttpRequest Request
    {
      get
      {
        return this._context.Request;
      }
    }

    private HttpResponse Response
    {
      get
      {
        return this._context.Response;
      }
    }

    private HttpServerUtility Server
    {
      get
      {
        return this._context.Server;
      }
    }

    public void ProcessRequest(HttpContext context)
    {
      this._context = context;
      this.Render();
    }

    private void Render()
    {
      this.Response.ContentType = "application/xml";
      ErrorLog errorLog = ErrorLog.GetDefault(this._context);
      RichSiteSummary richSiteSummary = new RichSiteSummary();
      richSiteSummary.version = "0.91";
      Channel channel = new Channel();
      string machineName = Environment.TryGetMachineName(this._context);
      channel.title = "Daily digest of errors in " + errorLog.ApplicationName + (machineName.Length > 0 ? " on " + machineName : (string) null);
      channel.description = "Daily digest of application errors";
      channel.language = "en";
      Uri baseUrl = new Uri(ErrorLogPageFactory.GetRequestUrl(this._context).GetLeftPart(UriPartial.Authority) + this.Request.ServerVariables["URL"]);
      channel.link = baseUrl.ToString();
      richSiteSummary.channel = channel;
      ArrayList arrayList1 = new ArrayList(30);
      ArrayList arrayList2 = new ArrayList(30);
      int num1 = 0;
      DateTime dateTime1 = DateTime.MaxValue;
      int num2 = 0;
      Elmah.ContentSyndication.Item obj = (Elmah.ContentSyndication.Item) null;
      StringBuilder sb = new StringBuilder();
      HtmlTextWriter writer = new HtmlTextWriter((TextWriter) new StringWriter(sb));
      do
      {
        arrayList2.Clear();
        errorLog.GetErrors(num1++, 30, (IList) arrayList2);
        foreach (ErrorLogEntry entry in arrayList2)
        {
          DateTime universalTime = entry.Error.Time.ToUniversalTime();
          DateTime dateTime2 = new DateTime(universalTime.Year, universalTime.Month, universalTime.Day);
          if (dateTime2 < dateTime1)
          {
            if (num2 > 0)
            {
              ErrorDigestRssHandler.RenderEnd(writer);
              obj.description = sb.ToString();
              arrayList1.Add((object) obj);
            }
            dateTime1 = dateTime2;
            num2 = 0;
            if (arrayList1.Count != 30)
            {
              obj = new Elmah.ContentSyndication.Item();
              obj.pubDate = universalTime.ToString("r");
              obj.title = string.Format("Digest for {0} ({1})", (object) dateTime1.ToString("yyyy-MM-dd"), (object) dateTime1.ToLongDateString());
              sb.Length = 0;
              ErrorDigestRssHandler.RenderStart(writer);
            }
            else
              break;
          }
          this.RenderError(writer, entry, baseUrl);
          ++num2;
        }
      }
      while (num1 < 30 && arrayList1.Count < 30 && arrayList2.Count > 0);
      if (num2 > 0)
      {
        ErrorDigestRssHandler.RenderEnd(writer);
        obj.description = sb.ToString();
        arrayList1.Add((object) obj);
      }
      channel.item = (Elmah.ContentSyndication.Item[]) arrayList1.ToArray(typeof (Elmah.ContentSyndication.Item));
      this.Response.Write(XmlText.StripIllegalXmlCharacters(XmlSerializer.Serialize((object) richSiteSummary)));
    }

    private static void RenderStart(HtmlTextWriter writer)
    {
      writer.RenderBeginTag(HtmlTextWriterTag.Ul);
    }

    private void RenderError(HtmlTextWriter writer, ErrorLogEntry entry, Uri baseUrl)
    {
      Error error = entry.Error;
      writer.RenderBeginTag(HtmlTextWriterTag.Li);
      string s = ErrorDisplay.HumaneExceptionErrorType(error);
      if (s.Length > 0)
      {
        bool flag = s.Length < error.Type.Length;
        if (flag)
        {
          writer.AddAttribute(HtmlTextWriterAttribute.Title, error.Type);
          writer.RenderBeginTag(HtmlTextWriterTag.Span);
        }
        this.Server.HtmlEncode(s, (TextWriter) writer);
        if (flag)
          writer.RenderEndTag();
        writer.Write(": ");
      }
      writer.AddAttribute(HtmlTextWriterAttribute.Href, baseUrl.ToString() + "/detail?id=" + HttpUtility.UrlEncode(entry.Id));
      writer.RenderBeginTag(HtmlTextWriterTag.A);
      this.Server.HtmlEncode(error.Message, (TextWriter) writer);
      writer.RenderEndTag();
      writer.RenderEndTag();
    }

    private static void RenderEnd(HtmlTextWriter writer)
    {
      writer.RenderEndTag();
      writer.Flush();
    }
  }
}
