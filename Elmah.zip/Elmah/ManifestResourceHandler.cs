﻿// Decompiled with JetBrains decompiler
// Type: Elmah.ManifestResourceHandler
// Assembly: Elmah, Version=1.2.14706.0, Culture=neutral, PublicKeyToken=null
// MVID: 6B433430-60BC-4287-8770-D3B3555B0D2B
// Assembly location: D:\Mata\transport-corp\trans-corp\transport-corp\App\Bin\Elmah.dll

using System.Text;
using System.Web;

namespace Elmah
{
  internal sealed class ManifestResourceHandler : IHttpHandler
  {
    private readonly string _resourceName;
    private readonly string _contentType;
    private readonly Encoding _responseEncoding;

    public bool IsReusable
    {
      get
      {
        return false;
      }
    }

    public ManifestResourceHandler(string resourceName, string contentType)
      : this(resourceName, contentType, (Encoding) null)
    {
    }

    public ManifestResourceHandler(string resourceName, string contentType, Encoding responseEncoding)
    {
      this._resourceName = resourceName;
      this._contentType = contentType;
      this._responseEncoding = responseEncoding;
    }

    public void ProcessRequest(HttpContext context)
    {
      HttpResponse response = context.Response;
      response.ContentType = this._contentType;
      if (this._responseEncoding != null)
        response.ContentEncoding = this._responseEncoding;
      ManifestResourceHelper.WriteResourceToStream(response.OutputStream, this._resourceName);
    }
  }
}
