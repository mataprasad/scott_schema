﻿// Decompiled with JetBrains decompiler
// Type: Elmah.Configuration
// Assembly: Elmah, Version=1.2.14706.0, Culture=neutral, PublicKeyToken=null
// MVID: 6B433430-60BC-4287-8770-D3B3555B0D2B
// Assembly location: D:\Mata\transport-corp\trans-corp\transport-corp\App\Bin\Elmah.dll

using System.Collections.Specialized;
using System.Configuration;

namespace Elmah
{
  internal sealed class Configuration
  {
    internal const string GroupName = "elmah";
    internal const string GroupSlash = "elmah/";

    public static NameValueCollection AppSettings
    {
      get
      {
        return ConfigurationManager.AppSettings;
      }
    }

    private Configuration()
    {
    }

    public static object GetSubsection(string name)
    {
      return Elmah.Configuration.GetSection("elmah/" + name);
    }

    public static object GetSection(string name)
    {
      return ConfigurationManager.GetSection(name);
    }
  }
}
