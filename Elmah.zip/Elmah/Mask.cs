﻿// Decompiled with JetBrains decompiler
// Type: Elmah.Mask
// Assembly: Elmah, Version=1.2.14706.0, Culture=neutral, PublicKeyToken=null
// MVID: 6B433430-60BC-4287-8770-D3B3555B0D2B
// Assembly location: D:\Mata\transport-corp\trans-corp\transport-corp\App\Bin\Elmah.dll

namespace Elmah
{
  internal sealed class Mask
  {
    private Mask()
    {
    }

    public static string NullString(string s)
    {
      if (s != null)
        return s;
      return string.Empty;
    }

    public static string EmptyString(string s, string filler)
    {
      if (Mask.NullString(s).Length != 0)
        return s;
      return filler;
    }
  }
}
