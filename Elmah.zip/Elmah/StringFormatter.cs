﻿// Decompiled with JetBrains decompiler
// Type: Elmah.StringFormatter
// Assembly: Elmah, Version=1.2.14706.0, Culture=neutral, PublicKeyToken=null
// MVID: 6B433430-60BC-4287-8770-D3B3555B0D2B
// Assembly location: D:\Mata\transport-corp\trans-corp\transport-corp\App\Bin\Elmah.dll

using System;
using System.Globalization;
using System.Text;
using System.Web;

namespace Elmah
{
  public sealed class StringFormatter
  {
    public static readonly StringFormatTokenBindingHandler DefaultTokenBinder = new StringFormatTokenBindingHandler(StringFormatter.BindFormatToken);

    private StringFormatter()
    {
    }

    public static string Format(string format, params object[] args)
    {
      return StringFormatter.Format(format, (IFormatProvider) null, (StringFormatTokenBindingHandler) null, args);
    }

    public static string Format(string format, IFormatProvider provider, params object[] args)
    {
      return StringFormatter.Format(format, provider, (StringFormatTokenBindingHandler) null, args);
    }

    public static string Format(string format, StringFormatTokenBindingHandler binder, params object[] args)
    {
      return StringFormatter.Format(format, (IFormatProvider) null, binder, args);
    }

    public static string Format(string format, IFormatProvider provider, StringFormatTokenBindingHandler binder, params object[] args)
    {
      return StringFormatter.FormatImpl(format, provider, binder != null ? binder : StringFormatter.DefaultTokenBinder, args);
    }

    private static string FormatImpl(string format, IFormatProvider provider, StringFormatTokenBindingHandler binder, params object[] args)
    {
      if (format == null)
        throw new ArgumentNullException("format");
      StringBuilder stringBuilder1 = new StringBuilder(format.Length * 2);
      StringBuilder stringBuilder2 = new StringBuilder();
      CharEnumerator enumerator = format.GetEnumerator();
label_16:
      while (enumerator.MoveNext())
      {
        char current1 = enumerator.Current;
        switch (current1)
        {
          case '{':
            while (enumerator.MoveNext())
            {
              char current2 = enumerator.Current;
              switch (current2)
              {
                case '}':
                  if (stringBuilder2.Length == 0)
                    throw new FormatException();
                  stringBuilder1.Append(binder(stringBuilder2.ToString(), args, provider));
                  stringBuilder2.Length = 0;
                  goto label_16;
                case '{':
                  stringBuilder1.Append(current2);
                  goto label_16;
                default:
                  stringBuilder2.Append(current2);
                  continue;
              }
            }
            throw new FormatException();
          case '}':
            if (!enumerator.MoveNext() || (int) enumerator.Current != 125)
              throw new FormatException();
            stringBuilder1.Append('}');
            continue;
          default:
            stringBuilder1.Append(current1);
            continue;
        }
      }
      return stringBuilder1.ToString();
    }

    public static string BindFormatToken(string token, object[] args, IFormatProvider provider)
    {
      if (token == null)
        throw new ArgumentNullException("token");
      if (token.Length == 0)
        throw new ArgumentException("Format token cannot be an empty string.", "token");
      if (args == null)
        throw new ArgumentNullException("args");
      if (args.Length == 0)
        throw new ArgumentException("Missing replacement arguments.", "args");
      object container = args[0];
      int length1 = token.IndexOf('.');
      int unsignedInteger1;
      if (length1 > 0 && 0 <= (unsignedInteger1 = StringFormatter.TryParseUnsignedInteger(token.Substring(0, length1))))
      {
        container = args[unsignedInteger1];
        token = token.Substring(length1 + 1);
      }
      string str = string.Empty;
      int length2 = token.IndexOf(':');
      if (length2 > 0)
      {
        str = "{0:" + token.Substring(length2 + 1) + "}";
        token = token.Substring(0, length2);
      }
      int unsignedInteger2;
      if ((unsignedInteger2 = StringFormatter.TryParseUnsignedInteger(token)) >= 0)
      {
        container = args[unsignedInteger2];
        token = (string) null;
      }
      object obj;
      try
      {
        obj = DataBinder.Eval(container, token) ?? (object) string.Empty;
      }
      catch (HttpException ex)
      {
        throw new FormatException(ex.Message, (Exception) ex);
      }
      if (Mask.NullString(str).Length <= 0)
        return obj.ToString();
      return string.Format(provider, str, new object[1]{ obj });
    }

    public static int TryParseUnsignedInteger(string str)
    {
      int result;
      if (!int.TryParse(str, NumberStyles.None, (IFormatProvider) CultureInfo.InvariantCulture, out result))
        return -1;
      return result;
    }
  }
}
