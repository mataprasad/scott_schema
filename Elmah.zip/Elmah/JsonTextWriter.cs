﻿// Decompiled with JetBrains decompiler
// Type: Elmah.JsonTextWriter
// Assembly: Elmah, Version=1.2.14706.0, Culture=neutral, PublicKeyToken=null
// MVID: 6B433430-60BC-4287-8770-D3B3555B0D2B
// Assembly location: D:\Mata\transport-corp\trans-corp\transport-corp\App\Bin\Elmah.dll

using System;
using System.Globalization;
using System.IO;
using System.Xml;

namespace Elmah
{
  public sealed class JsonTextWriter
  {
    private static readonly DateTime _epoch = new DateTime(1970, 1, 1, 0, 0, 0, DateTimeKind.Utc);
    private readonly TextWriter _writer;
    private readonly int[] _counters;
    private readonly char[] _terminators;
    private int _depth;
    private string _memberName;

    public int Depth
    {
      get
      {
        return this._depth;
      }
    }

    private int ItemCount
    {
      get
      {
        return this._counters[this.Depth];
      }
      set
      {
        this._counters[this.Depth] = value;
      }
    }

    private char Terminator
    {
      get
      {
        return this._terminators[this.Depth];
      }
      set
      {
        this._terminators[this.Depth] = value;
      }
    }

    public JsonTextWriter(TextWriter writer)
    {
      this._writer = writer;
      this._counters = new int[11];
      this._terminators = new char[11];
    }

    public JsonTextWriter Object()
    {
      return this.StartStructured("{", "}");
    }

    public JsonTextWriter EndObject()
    {
      return this.Pop();
    }

    public JsonTextWriter Array()
    {
      return this.StartStructured("[", "]");
    }

    public JsonTextWriter EndArray()
    {
      return this.Pop();
    }

    public JsonTextWriter Pop()
    {
      return this.EndStructured();
    }

    public JsonTextWriter Member(string name)
    {
      if (name == null)
        throw new ArgumentNullException("name");
      if (name.Length == 0)
        throw new ArgumentException((string) null, "name");
      if (this._memberName != null)
        throw new InvalidOperationException("Missing member value.");
      this._memberName = name;
      return this;
    }

    private JsonTextWriter Write(string text)
    {
      return this.WriteImpl(text, false);
    }

    private JsonTextWriter WriteEnquoted(string text)
    {
      return this.WriteImpl(text, true);
    }

    private JsonTextWriter WriteImpl(string text, bool raw)
    {
      if (this.Depth == 0 && (text.Length > 1 || (int) text[0] != 123 && (int) text[0] != 91))
        throw new InvalidOperationException();
      TextWriter writer = this._writer;
      if (this.ItemCount > 0)
        writer.Write(',');
      string memberName = this._memberName;
      this._memberName = (string) null;
      if (memberName != null)
      {
        writer.Write(' ');
        JsonTextWriter.Enquote(memberName, writer);
        writer.Write(':');
      }
      if (this.Depth > 0)
        writer.Write(' ');
      if (raw)
        JsonTextWriter.Enquote(text, writer);
      else
        writer.Write(text);
      this.ItemCount = this.ItemCount + 1;
      return this;
    }

    public JsonTextWriter Number(int value)
    {
      return this.Write(value.ToString((IFormatProvider) CultureInfo.InvariantCulture));
    }

    public JsonTextWriter String(string str)
    {
      if (str != null)
        return this.WriteEnquoted(str);
      return this.Null();
    }

    public JsonTextWriter Null()
    {
      return this.Write("null");
    }

    public JsonTextWriter Boolean(bool value)
    {
      return this.Write(value ? "true" : "false");
    }

    public JsonTextWriter Number(DateTime time)
    {
      return this.Write(time.ToUniversalTime().Subtract(JsonTextWriter._epoch).TotalSeconds.ToString((IFormatProvider) CultureInfo.InvariantCulture));
    }

    public JsonTextWriter String(DateTime time)
    {
      return this.String(XmlConvert.ToString(time, XmlDateTimeSerializationMode.Utc));
    }

    private JsonTextWriter StartStructured(string start, string end)
    {
      if (this.Depth + 1 == this._counters.Length)
        throw new Exception();
      this.Write(start);
      ++this._depth;
      this.Terminator = end[0];
      return this;
    }

    private JsonTextWriter EndStructured()
    {
      if (this.Depth - 1 < 0)
        throw new Exception();
      this._writer.Write(' ');
      this._writer.Write(this.Terminator);
      this.ItemCount = 0;
      --this._depth;
      return this;
    }

    private static void Enquote(string s, TextWriter writer)
    {
      int length = Mask.NullString(s).Length;
      writer.Write('"');
      char minValue = char.MinValue;
      for (int index = 0; index < length; ++index)
      {
        char ch = minValue;
        minValue = s[index];
        switch (minValue)
        {
          case '/':
            if ((int) ch == 60)
              writer.Write('\\');
            writer.Write(minValue);
            break;
          case '\\':
          case '"':
            writer.Write('\\');
            writer.Write(minValue);
            break;
          case '\b':
            writer.Write("\\b");
            break;
          case '\t':
            writer.Write("\\t");
            break;
          case '\n':
            writer.Write("\\n");
            break;
          case '\f':
            writer.Write("\\f");
            break;
          case '\r':
            writer.Write("\\r");
            break;
          default:
            if ((int) minValue < 32)
            {
              writer.Write("\\u");
              writer.Write(((int) minValue).ToString("x4", (IFormatProvider) CultureInfo.InvariantCulture));
              break;
            }
            writer.Write(minValue);
            break;
        }
      }
      writer.Write('"');
    }
  }
}
