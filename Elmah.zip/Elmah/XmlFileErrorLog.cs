﻿// Decompiled with JetBrains decompiler
// Type: Elmah.XmlFileErrorLog
// Assembly: Elmah, Version=1.2.14706.0, Culture=neutral, PublicKeyToken=null
// MVID: 6B433430-60BC-4287-8770-D3B3555B0D2B
// Assembly location: D:\Mata\transport-corp\trans-corp\transport-corp\App\Bin\Elmah.dll

using System;
using System.Collections;
using System.Globalization;
using System.IO;
using System.Runtime.CompilerServices;
using System.Text;
using System.Web.Hosting;
using System.Xml;

namespace Elmah
{
  public class XmlFileErrorLog : ErrorLog
  {
    private readonly string _logPath;

    public virtual string LogPath
    {
      get
      {
        return Mask.NullString(this._logPath);
      }
    }

    public override string Name
    {
      get
      {
        return "XML File-Based Error Log";
      }
    }

    public XmlFileErrorLog(IDictionary config)
    {
      string path = Mask.NullString(config[(object) "logPath"] as string);
      if (path.Length == 0)
      {
        path = Mask.NullString(config[(object) "LogPath"] as string);
        if (path.Length == 0)
          throw new ApplicationException("Log path is missing for the XML file-based error log.");
      }
      if (path.StartsWith("~/"))
        path = XmlFileErrorLog.MapPath(path);
      this._logPath = path;
    }

    public XmlFileErrorLog(string logPath)
    {
      this._logPath = logPath;
    }

    [MethodImpl(MethodImplOptions.NoInlining)]
    private static string MapPath(string path)
    {
      return HostingEnvironment.MapPath(path);
    }

    public override string Log(Error error)
    {
      string logPath = this.LogPath;
      if (!Directory.Exists(logPath))
        Directory.CreateDirectory(logPath);
      string str = Guid.NewGuid().ToString();
      string path2 = string.Format((IFormatProvider) CultureInfo.InvariantCulture, "error-{0:yyyy-MM-ddHHmmssZ}-{1}.xml", new object[2]{ (object) (error.Time > DateTime.MinValue ? error.Time : DateTime.Now).ToUniversalTime(), (object) str });
      XmlTextWriter xmlTextWriter = new XmlTextWriter(Path.Combine(logPath, path2), Encoding.UTF8);
      try
      {
        xmlTextWriter.Formatting = Formatting.Indented;
        xmlTextWriter.WriteStartElement("error");
        xmlTextWriter.WriteAttributeString("errorId", str);
        ErrorXml.Encode(error, (XmlWriter) xmlTextWriter);
        xmlTextWriter.WriteEndElement();
        xmlTextWriter.Flush();
      }
      finally
      {
        xmlTextWriter.Close();
      }
      return str;
    }

    public override int GetErrors(int pageIndex, int pageSize, IList errorEntryList)
    {
      if (pageIndex < 0)
        throw new ArgumentOutOfRangeException("pageIndex", (object) pageIndex, (string) null);
      if (pageSize < 0)
        throw new ArgumentOutOfRangeException("pageSize", (object) pageSize, (string) null);
      string logPath = this.LogPath;
      DirectoryInfo directoryInfo = new DirectoryInfo(logPath);
      if (!directoryInfo.Exists)
        return 0;
      FileSystemInfo[] files = (FileSystemInfo[]) directoryInfo.GetFiles("error-*.xml");
      if (files.Length < 1)
        return 0;
      string[] keys = new string[files.Length];
      int length = 0;
      foreach (FileSystemInfo fileSystemInfo in files)
      {
        if (XmlFileErrorLog.IsUserFile(fileSystemInfo.Attributes))
          keys[length++] = Path.Combine(logPath, fileSystemInfo.Name);
      }
      InvariantStringArray.Sort(keys, 0, length);
      Array.Reverse((Array) keys, 0, length);
      if (errorEntryList != null)
      {
        int num1 = pageIndex * pageSize;
        int num2 = num1 + pageSize < length ? num1 + pageSize : length;
        for (int index = num1; index < num2; ++index)
        {
          XmlTextReader xmlTextReader = new XmlTextReader(keys[index]);
          try
          {
            while (xmlTextReader.IsStartElement("error"))
            {
              string attribute = xmlTextReader.GetAttribute("errorId");
              Error error = ErrorXml.Decode((XmlReader) xmlTextReader);
              errorEntryList.Add((object) new ErrorLogEntry((ErrorLog) this, attribute, error));
            }
          }
          finally
          {
            xmlTextReader.Close();
          }
        }
      }
      return length;
    }

    public override ErrorLogEntry GetError(string id)
    {
      try
      {
        id = new Guid(id).ToString();
      }
      catch (FormatException ex)
      {
        throw new ArgumentException(ex.Message, id, (Exception) ex);
      }
      FileInfo[] files = new DirectoryInfo(this.LogPath).GetFiles(string.Format("error-*-{0}.xml", (object) id));
      if (files.Length < 1)
        return (ErrorLogEntry) null;
      FileInfo fileInfo = files[0];
      if (!XmlFileErrorLog.IsUserFile(fileInfo.Attributes))
        return (ErrorLogEntry) null;
      XmlTextReader xmlTextReader = new XmlTextReader(fileInfo.FullName);
      try
      {
        Error error = ErrorXml.Decode((XmlReader) xmlTextReader);
        return new ErrorLogEntry((ErrorLog) this, id, error);
      }
      finally
      {
        xmlTextReader.Close();
      }
    }

    private static bool IsUserFile(FileAttributes attributes)
    {
      return (FileAttributes) 0 == (attributes & (FileAttributes.Hidden | FileAttributes.System | FileAttributes.Directory));
    }
  }
}
