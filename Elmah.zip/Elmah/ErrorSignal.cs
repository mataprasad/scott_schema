﻿// Decompiled with JetBrains decompiler
// Type: Elmah.ErrorSignal
// Assembly: Elmah, Version=1.2.14706.0, Culture=neutral, PublicKeyToken=null
// MVID: 6B433430-60BC-4287-8770-D3B3555B0D2B
// Assembly location: D:\Mata\transport-corp\trans-corp\transport-corp\App\Bin\Elmah.dll

using System;
using System.Collections;
using System.Web;

namespace Elmah
{
  public sealed class ErrorSignal
  {
    private static readonly object _lock = new object();
    private static Hashtable _signalByApp;

    public event ErrorSignalEventHandler Raised;

    public void Raise(Exception e)
    {
      this.Raise(e, (HttpContext) null);
    }

    public void Raise(Exception e, HttpContext context)
    {
      if (context == null)
        context = HttpContext.Current;
      ErrorSignalEventHandler raised = this.Raised;
      if (raised == null)
        return;
      raised((object) this, new ErrorSignalEventArgs(e, context));
    }

    public static ErrorSignal FromCurrentContext()
    {
      return ErrorSignal.FromContext(HttpContext.Current);
    }

    public static ErrorSignal FromContext(HttpContext context)
    {
      if (context == null)
        throw new ArgumentNullException("context");
      return ErrorSignal.Get(context.ApplicationInstance);
    }

    public static ErrorSignal Get(HttpApplication application)
    {
      if (application == null)
        throw new ArgumentNullException("application");
      lock (ErrorSignal._lock)
      {
        if (ErrorSignal._signalByApp == null)
          ErrorSignal._signalByApp = new Hashtable();
        ErrorSignal local_0 = (ErrorSignal) ErrorSignal._signalByApp[(object) application];
        if (local_0 == null)
        {
          local_0 = new ErrorSignal();
          ErrorSignal._signalByApp.Add((object) application, (object) local_0);
          application.Disposed += new EventHandler(ErrorSignal.OnApplicationDisposed);
        }
        return local_0;
      }
    }

    private static void OnApplicationDisposed(object sender, EventArgs e)
    {
      HttpApplication httpApplication = (HttpApplication) sender;
      lock (ErrorSignal._lock)
      {
        if (ErrorSignal._signalByApp == null)
          return;
        ErrorSignal._signalByApp.Remove((object) httpApplication);
        if (ErrorSignal._signalByApp.Count != 0)
          return;
        ErrorSignal._signalByApp = (Hashtable) null;
      }
    }
  }
}
