﻿// Decompiled with JetBrains decompiler
// Type: Elmah.CdoConfigurationFields
// Assembly: Elmah, Version=1.2.14706.0, Culture=neutral, PublicKeyToken=null
// MVID: 6B433430-60BC-4287-8770-D3B3555B0D2B
// Assembly location: D:\Mata\transport-corp\trans-corp\transport-corp\App\Bin\Elmah.dll

namespace Elmah
{
  internal sealed class CdoConfigurationFields
  {
    public const string SendUsing = "http://schemas.microsoft.com/cdo/configuration/sendusing";
    public const string SmtpServer = "http://schemas.microsoft.com/cdo/configuration/smtpserver";
    public const string SmtpServerPort = "http://schemas.microsoft.com/cdo/configuration/smtpserverport";
    public const string SmtpAuthenticate = "http://schemas.microsoft.com/cdo/configuration/smtpauthenticate";
    public const string SendUserName = "http://schemas.microsoft.com/cdo/configuration/sendusername";
    public const string SendPassword = "http://schemas.microsoft.com/cdo/configuration/sendpassword";

    private CdoConfigurationFields()
    {
    }
  }
}
