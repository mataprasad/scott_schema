﻿// Decompiled with JetBrains decompiler
// Type: Elmah.ErrorFilterModule
// Assembly: Elmah, Version=1.2.14706.0, Culture=neutral, PublicKeyToken=null
// MVID: 6B433430-60BC-4287-8770-D3B3555B0D2B
// Assembly location: D:\Mata\transport-corp\trans-corp\transport-corp\App\Bin\Elmah.dll

using Elmah.Assertions;
using System;
using System.Collections;
using System.Diagnostics;
using System.Reflection;
using System.Web;

namespace Elmah
{
  public class ErrorFilterModule : IHttpModule
  {
    private IAssertion _assertion = (IAssertion) StaticAssertion.False;

    public virtual IAssertion Assertion
    {
      get
      {
        return this._assertion;
      }
    }

    public virtual void Init(HttpApplication application)
    {
      if (application == null)
        throw new ArgumentNullException("application");
      ErrorFilterConfiguration subsection = (ErrorFilterConfiguration) Configuration.GetSubsection("errorFilter");
      if (subsection == null)
        return;
      this._assertion = subsection.Assertion;
      foreach (IHttpModule module in (IEnumerable) HttpModuleRegistry.GetModules(application))
      {
        IExceptionFiltering exceptionFiltering = module as IExceptionFiltering;
        if (exceptionFiltering != null)
          exceptionFiltering.Filtering += new ExceptionFilterEventHandler(this.OnErrorModuleFiltering);
      }
    }

    public virtual void Dispose()
    {
    }

    protected virtual void OnErrorModuleFiltering(object sender, ExceptionFilterEventArgs args)
    {
      if (args == null)
        throw new ArgumentNullException("args");
      if (args.Exception == null)
        throw new ArgumentException((string) null, "args");
      try
      {
        if (!this.Assertion.Test((object) new ErrorFilterModule.AssertionHelperContext(sender, args.Exception, args.Context)))
          return;
        args.Dismiss();
      }
      catch (Exception ex)
      {
        Trace.WriteLine((object) ex);
        throw;
      }
    }

    public sealed class AssertionHelperContext
    {
      private readonly object _source;
      private readonly Exception _exception;
      private readonly object _context;
      private Exception _baseException;
      private int _httpStatusCode;
      private bool _statusCodeInitialized;

      public object FilterSource
      {
        get
        {
          return this._source;
        }
      }

      public Type FilterSourceType
      {
        get
        {
          return this._source.GetType();
        }
      }

      public AssemblyName FilterSourceAssemblyName
      {
        get
        {
          return this.FilterSourceType.Assembly.GetName();
        }
      }

      public Exception Exception
      {
        get
        {
          return this._exception;
        }
      }

      public Exception BaseException
      {
        get
        {
          if (this._baseException == null)
            this._baseException = this.Exception.GetBaseException();
          return this._baseException;
        }
      }

      public bool HasHttpStatusCode
      {
        get
        {
          return this.HttpStatusCode != 0;
        }
      }

      public int HttpStatusCode
      {
        get
        {
          if (!this._statusCodeInitialized)
          {
            this._statusCodeInitialized = true;
            HttpException exception = this.Exception as HttpException;
            if (exception != null)
              this._httpStatusCode = exception.GetHttpCode();
          }
          return this._httpStatusCode;
        }
      }

      public object Context
      {
        get
        {
          return this._context;
        }
      }

      public AssertionHelperContext(Exception e, object context)
        : this((object) null, e, context)
      {
      }

      public AssertionHelperContext(object source, Exception e, object context)
      {
        this._source = source == null ? (object) this : source;
        this._exception = e;
        this._context = context;
      }
    }
  }
}
