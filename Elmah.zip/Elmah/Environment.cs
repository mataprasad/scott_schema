﻿// Decompiled with JetBrains decompiler
// Type: Elmah.Environment
// Assembly: Elmah, Version=1.2.14706.0, Culture=neutral, PublicKeyToken=null
// MVID: 6B433430-60BC-4287-8770-D3B3555B0D2B
// Assembly location: D:\Mata\transport-corp\trans-corp\transport-corp\App\Bin\Elmah.dll

using System.Security;
using System.Web;

namespace Elmah
{
  internal sealed class Environment
  {
    private Environment()
    {
    }

    public static string TryGetMachineName()
    {
      return Environment.TryGetMachineName((HttpContext) null);
    }

    public static string TryGetMachineName(HttpContext context)
    {
      return Environment.TryGetMachineName(context, (string) null);
    }

    public static string TryGetMachineName(HttpContext context, string unknownName)
    {
      if (context != null)
      {
        try
        {
          return context.Server.MachineName;
        }
        catch (HttpException ex)
        {
        }
        catch (SecurityException ex)
        {
        }
      }
      try
      {
        return System.Environment.MachineName;
      }
      catch (SecurityException ex)
      {
      }
      return Mask.NullString(unknownName);
    }
  }
}
