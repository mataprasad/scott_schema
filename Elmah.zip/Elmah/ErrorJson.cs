﻿// Decompiled with JetBrains decompiler
// Type: Elmah.ErrorJson
// Assembly: Elmah, Version=1.2.14706.0, Culture=neutral, PublicKeyToken=null
// MVID: 6B433430-60BC-4287-8770-D3B3555B0D2B
// Assembly location: D:\Mata\transport-corp\trans-corp\transport-corp\App\Bin\Elmah.dll

using System;
using System.Collections.Specialized;
using System.IO;

namespace Elmah
{
  [Serializable]
  public sealed class ErrorJson
  {
    private ErrorJson()
    {
      throw new NotSupportedException();
    }

    public static string EncodeString(Error error)
    {
      if (error == null)
        throw new ArgumentNullException("error");
      StringWriter stringWriter = new StringWriter();
      ErrorJson.Encode(error, (TextWriter) stringWriter);
      return stringWriter.ToString();
    }

    public static void Encode(Error error, TextWriter writer)
    {
      if (error == null)
        throw new ArgumentNullException("error");
      if (writer == null)
        throw new ArgumentNullException("writer");
      ErrorJson.EncodeEnclosed(error, new JsonTextWriter(writer));
    }

    private static void EncodeEnclosed(Error error, JsonTextWriter writer)
    {
      writer.Object();
      ErrorJson.Encode(error, writer);
      writer.Pop();
    }

    internal static void Encode(Error error, JsonTextWriter writer)
    {
      ErrorJson.Member(writer, "application", error.ApplicationName);
      ErrorJson.Member(writer, "host", error.HostName);
      ErrorJson.Member(writer, "type", error.Type);
      ErrorJson.Member(writer, "message", error.Message);
      ErrorJson.Member(writer, "source", error.Source);
      ErrorJson.Member(writer, "detail", error.Detail);
      ErrorJson.Member(writer, "user", error.User);
      ErrorJson.Member(writer, "time", error.Time, DateTime.MinValue);
      ErrorJson.Member(writer, "statusCode", error.StatusCode, 0);
      ErrorJson.Member(writer, "webHostHtmlMessage", error.WebHostHtmlMessage);
      ErrorJson.Member(writer, "serverVariables", error.ServerVariables);
      ErrorJson.Member(writer, "queryString", error.QueryString);
      ErrorJson.Member(writer, "form", error.Form);
      ErrorJson.Member(writer, "cookies", error.Cookies);
    }

    private static void Member(JsonTextWriter writer, string name, int value, int defaultValue)
    {
      if (value == defaultValue)
        return;
      writer.Member(name).Number(value);
    }

    private static void Member(JsonTextWriter writer, string name, DateTime value, DateTime defaultValue)
    {
      if (value == defaultValue)
        return;
      writer.Member(name).String(value);
    }

    private static void Member(JsonTextWriter writer, string name, string value)
    {
      if (value == null || value.Length == 0)
        return;
      writer.Member(name).String(value);
    }

    private static void Member(JsonTextWriter writer, string name, NameValueCollection collection)
    {
      if (collection == null || collection.Count == 0)
        return;
      int depth = writer.Depth;
      foreach (string key in collection.Keys)
      {
        string[] values = collection.GetValues(key);
        if (values != null && values.Length != 0)
        {
          int num = 0;
          for (int index = 0; index < values.Length; ++index)
          {
            string str = values[index];
            if (str != null && str.Length > 0)
              ++num;
          }
          if (num != 0)
          {
            if (depth == writer.Depth)
            {
              writer.Member(name);
              writer.Object();
            }
            writer.Member(key);
            if (num > 1)
              writer.Array();
            for (int index = 0; index < values.Length; ++index)
            {
              string str = values[index];
              if (str != null && str.Length > 0)
                writer.String(str);
            }
            if (num > 1)
              writer.Pop();
          }
        }
      }
      if (writer.Depth <= depth)
        return;
      writer.Pop();
    }
  }
}
