﻿// Decompiled with JetBrains decompiler
// Type: Elmah.AboutPage
// Assembly: Elmah, Version=1.2.14706.0, Culture=neutral, PublicKeyToken=null
// MVID: 6B433430-60BC-4287-8770-D3B3555B0D2B
// Assembly location: D:\Mata\transport-corp\trans-corp\transport-corp\App\Bin\Elmah.dll

using System;
using System.IO;
using System.Reflection;
using System.Web.UI;

namespace Elmah
{
  internal sealed class AboutPage : ErrorPageBase
  {
    public AboutPage()
    {
      this.PageTitle = "About ELMAH";
    }

    protected override void RenderContents(HtmlTextWriter writer)
    {
      if (writer == null)
        throw new ArgumentNullException("writer");
      writer.WriteLine("\r\n                <script type='text/javascript' language='JavaScript'>\r\n                    function onCheckForUpdate(sender) {\r\n                        var script = document.createElement('script');\r\n                        script.type = 'text/javascript';\r\n                        script.language = 'JavaScript';\r\n                        script.src = 'http://www.elmah.googlecode.com/hg/update.js?__=' + (new Date()).getTime();\r\n                        document.getElementsByTagName('head')[0].appendChild(script);\r\n                        return false;\r\n                    }\r\n                    var ELMAH = {\r\n                        info : {\r\n                            version     : '" + (object) this.GetVersion() + "',\r\n                            fileVersion : '" + (object) this.GetFileVersion() + "',\r\n                            type        : 'release',\r\n                            status      : 'RTM',\r\n                            framework   : 'net-2.0',\r\n                            imageRuntime: '" + Build.ImageRuntimeVersion + "'\r\n                        }\r\n                    };\r\n                </script>");
      writer.AddAttribute(HtmlTextWriterAttribute.Id, "PageTitle");
      writer.RenderBeginTag(HtmlTextWriterTag.H1);
      writer.Write(this.PageTitle);
      writer.RenderEndTag();
      writer.WriteLine();
      SpeedBar.Render(writer, SpeedBar.Home.Format(this.BasePageName), SpeedBar.Help, SpeedBar.About.Format(this.BasePageName));
      writer.RenderBeginTag(HtmlTextWriterTag.P);
      writer.AddAttribute(HtmlTextWriterAttribute.Onclick, "return onCheckForUpdate(this)");
      writer.AddAttribute(HtmlTextWriterAttribute.Title, "Checks if your ELMAH version is up to date (requires Internet connection)");
      writer.RenderBeginTag(HtmlTextWriterTag.Button);
      writer.Write("Check for Update");
      writer.RenderEndTag();
      writer.RenderEndTag();
      SccStamp[] all = SccStamp.FindAll(typeof (ErrorLog).Assembly);
      SccStamp.SortByLastChanged(all, true);
      writer.RenderBeginTag(HtmlTextWriterTag.P);
      writer.Write("This <strong>{0}</strong> ", (object) "release");
      if (all.Length > 0)
        writer.Write("(SCC {0}) ", all[0].Revision);
      writer.Write("build was compiled from the following sources for CLR {0}:", (object) Build.ImageRuntimeVersion);
      writer.RenderEndTag();
      writer.RenderBeginTag(HtmlTextWriterTag.Ul);
      foreach (SccStamp sccStamp in all)
      {
        writer.RenderBeginTag(HtmlTextWriterTag.Li);
        writer.RenderBeginTag(HtmlTextWriterTag.Code);
        this.Server.HtmlEncode(sccStamp.Id, (TextWriter) writer);
        writer.RenderEndTag();
        writer.RenderEndTag();
      }
      writer.RenderEndTag();
    }

    private Version GetVersion()
    {
      return this.GetType().Assembly.GetName().Version;
    }

    private Version GetFileVersion()
    {
      AssemblyFileVersionAttribute customAttribute = (AssemblyFileVersionAttribute) Attribute.GetCustomAttribute(this.GetType().Assembly, typeof (AssemblyFileVersionAttribute));
      if (customAttribute == null)
        return new Version();
      return new Version(customAttribute.Version);
    }
  }
}
