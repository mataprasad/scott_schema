﻿// Decompiled with JetBrains decompiler
// Type: Elmah.ErrorJsonHandler
// Assembly: Elmah, Version=1.2.14706.0, Culture=neutral, PublicKeyToken=null
// MVID: 6B433430-60BC-4287-8770-D3B3555B0D2B
// Assembly location: D:\Mata\transport-corp\trans-corp\transport-corp\App\Bin\Elmah.dll

using System.Web;

namespace Elmah
{
  internal sealed class ErrorJsonHandler : IHttpHandler
  {
    public bool IsReusable
    {
      get
      {
        return false;
      }
    }

    public void ProcessRequest(HttpContext context)
    {
      HttpResponse response = context.Response;
      response.ContentType = "application/json";
      string id = Mask.NullString(context.Request.QueryString["id"]);
      if (id.Length == 0)
        throw new ApplicationException("Missing error identifier specification.");
      ErrorLogEntry error = ErrorLog.GetDefault(context).GetError(id);
      if (error == null)
        throw new HttpException(404, string.Format("Error with ID '{0}' not found.", (object) id));
      ErrorJson.Encode(error.Error, response.Output);
    }
  }
}
