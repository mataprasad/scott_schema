﻿// Decompiled with JetBrains decompiler
// Type: Elmah.ApplicationException
// Assembly: Elmah, Version=1.2.14706.0, Culture=neutral, PublicKeyToken=null
// MVID: 6B433430-60BC-4287-8770-D3B3555B0D2B
// Assembly location: D:\Mata\transport-corp\trans-corp\transport-corp\App\Bin\Elmah.dll

using System;
using System.Runtime.Serialization;

namespace Elmah
{
  [Serializable]
  public class ApplicationException : Exception
  {
    public ApplicationException()
    {
    }

    public ApplicationException(string message)
      : base(message)
    {
    }

    public ApplicationException(string message, Exception innerException)
      : base(message, innerException)
    {
    }

    protected ApplicationException(SerializationInfo info, StreamingContext context)
      : base(info, context)
    {
    }
  }
}
