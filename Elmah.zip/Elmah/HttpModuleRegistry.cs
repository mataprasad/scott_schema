﻿// Decompiled with JetBrains decompiler
// Type: Elmah.HttpModuleRegistry
// Assembly: Elmah, Version=1.2.14706.0, Culture=neutral, PublicKeyToken=null
// MVID: 6B433430-60BC-4287-8770-D3B3555B0D2B
// Assembly location: D:\Mata\transport-corp\trans-corp\transport-corp\App\Bin\Elmah.dll

using System;
using System.Collections;
using System.Security;
using System.Web;

namespace Elmah
{
  internal sealed class HttpModuleRegistry
  {
    private static readonly object _lock = new object();
    private static Hashtable _moduleListByApp;

    private HttpModuleRegistry()
    {
      throw new NotSupportedException();
    }

    public static bool RegisterInPartialTrust(HttpApplication application, IHttpModule module)
    {
      if (application == null)
        throw new ArgumentNullException("application");
      if (module == null)
        throw new ArgumentNullException("module");
      if (HttpModuleRegistry.IsHighlyTrusted())
        return false;
      lock (HttpModuleRegistry._lock)
      {
        if (HttpModuleRegistry._moduleListByApp == null)
          HttpModuleRegistry._moduleListByApp = new Hashtable();
        IList local_0 = (IList) HttpModuleRegistry._moduleListByApp[(object) application];
        if (local_0 == null)
        {
          local_0 = (IList) new ArrayList(4);
          HttpModuleRegistry._moduleListByApp.Add((object) application, (object) local_0);
        }
        else if (local_0.Contains((object) module))
          throw new ApplicationException("Duplicate module registration.");
        local_0.Add((object) module);
      }
      HttpModuleRegistry.Housekeeper housekeeper = new HttpModuleRegistry.Housekeeper(module);
      application.Disposed += new EventHandler(housekeeper.OnApplicationDisposed);
      return true;
    }

    private static bool UnregisterInPartialTrust(HttpApplication application, IHttpModule module)
    {
      if (module == null)
        throw new ArgumentNullException("module");
      if (HttpModuleRegistry.IsHighlyTrusted())
        return false;
      lock (HttpModuleRegistry._lock)
      {
        if (HttpModuleRegistry._moduleListByApp == null)
          return false;
        IList local_0 = (IList) HttpModuleRegistry._moduleListByApp[(object) application];
        if (local_0 == null)
          return false;
        int local_1 = local_0.IndexOf((object) module);
        if (local_1 < 0)
          return false;
        local_0.RemoveAt(local_1);
        if (local_0.Count == 0)
        {
          HttpModuleRegistry._moduleListByApp.Remove((object) application);
          if (HttpModuleRegistry._moduleListByApp.Count == 0)
            HttpModuleRegistry._moduleListByApp = (Hashtable) null;
        }
      }
      return true;
    }

    public static ICollection GetModules(HttpApplication application)
    {
      if (application == null)
        throw new ArgumentNullException("application");
      try
      {
        IHttpModule[] httpModuleArray = new IHttpModule[application.Modules.Count];
        application.Modules.CopyTo((Array) httpModuleArray, 0);
        return (ICollection) httpModuleArray;
      }
      catch (SecurityException ex)
      {
      }
      lock (HttpModuleRegistry._lock)
      {
        if (HttpModuleRegistry._moduleListByApp == null)
          return (ICollection) new IHttpModule[0];
        IList local_1 = (IList) HttpModuleRegistry._moduleListByApp[(object) application];
        if (local_1 == null)
          return (ICollection) new IHttpModule[0];
        IHttpModule[] local_2 = new IHttpModule[local_1.Count];
        local_1.CopyTo((Array) local_2, 0);
        return (ICollection) local_2;
      }
    }

    private static bool IsHighlyTrusted()
    {
      try
      {
        new AspNetHostingPermission(AspNetHostingPermissionLevel.High).Demand();
        return true;
      }
      catch (SecurityException ex)
      {
        return false;
      }
    }

    internal sealed class Housekeeper
    {
      private readonly IHttpModule _module;

      public Housekeeper(IHttpModule module)
      {
        this._module = module;
      }

      public void OnApplicationDisposed(object sender, EventArgs e)
      {
        HttpModuleRegistry.UnregisterInPartialTrust((HttpApplication) sender, this._module);
      }
    }
  }
}
