﻿// Decompiled with JetBrains decompiler
// Type: Elmah.MsAjaxDeltaErrorLogModule
// Assembly: Elmah, Version=1.2.14706.0, Culture=neutral, PublicKeyToken=null
// MVID: 6B433430-60BC-4287-8770-D3B3555B0D2B
// Assembly location: D:\Mata\transport-corp\trans-corp\transport-corp\App\Bin\Elmah.dll

using System;
using System.Web;
using System.Web.UI;

namespace Elmah
{
  public class MsAjaxDeltaErrorLogModule : IHttpModule
  {
    public virtual void Init(HttpApplication context)
    {
      context.PostMapRequestHandler += new EventHandler(this.OnPostMapRequestHandler);
    }

    public virtual void Dispose()
    {
    }

    private void OnPostMapRequestHandler(object sender, EventArgs args)
    {
      HttpContext context = ((HttpApplication) sender).Context;
      if (!this.IsAsyncPostBackRequest(context.Request))
        return;
      Page handler = context.Handler as Page;
      if (handler == null)
        return;
      handler.Error += new EventHandler(this.OnPageError);
    }

    protected virtual void OnPageError(object sender, EventArgs args)
    {
      Exception lastError = ((Page) sender).Server.GetLastError();
      if (lastError == null)
        return;
      HttpContext current = HttpContext.Current;
      this.LogException(lastError, current);
    }

    protected virtual void LogException(Exception e, HttpContext context)
    {
      ErrorSignal.FromContext(context).Raise(e, context);
    }

    protected virtual bool IsAsyncPostBackRequest(HttpRequest request)
    {
      if (request == null)
        throw new ArgumentNullException("request");
      string[] values = request.Headers.GetValues("X-MicrosoftAjax");
      if (values == null || values.Length == 0)
        return false;
      foreach (string strA in values)
      {
        if (string.Compare(strA, "Delta=true", StringComparison.OrdinalIgnoreCase) == 0)
          return true;
      }
      return false;
    }
  }
}
