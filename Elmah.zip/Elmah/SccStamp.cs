﻿// Decompiled with JetBrains decompiler
// Type: Elmah.SccStamp
// Assembly: Elmah, Version=1.2.14706.0, Culture=neutral, PublicKeyToken=null
// MVID: 6B433430-60BC-4287-8770-D3B3555B0D2B
// Assembly location: D:\Mata\transport-corp\trans-corp\transport-corp\App\Bin\Elmah.dll

using System;
using System.Collections;
using System.Globalization;
using System.IO;
using System.Reflection;
using System.Text.RegularExpressions;

namespace Elmah
{
  [Serializable]
  public sealed class SccStamp
  {
    private static readonly Regex _regex = new Regex("\\$ id: \\s* \r\n                     (?<f>[^" + Regex.Escape(new string(Path.GetInvalidFileNameChars())) + "]+) \\s+         # FILENAME\r\n                     (?<r>[0-9a-f]+) \\s+                                    # REVISION\r\n                     ((?<y>[0-9]{4})-(?<mo>[0-9]{2})-(?<d>[0-9]{2})) \\s+    # DATE\r\n                     ((?<h>[0-9]{2})\\:(?<mi>[0-9]{2})\\:(?<s>[0-9]{2})Z) \\s+ # TIME (UTC)\r\n                     (?<a>\\w+)                                              # AUTHOR", RegexOptions.IgnoreCase | RegexOptions.ExplicitCapture | RegexOptions.Compiled | RegexOptions.Singleline | RegexOptions.IgnorePatternWhitespace | RegexOptions.CultureInvariant);
    private readonly string _id;
    private readonly string _author;
    private readonly string _fileName;
    private readonly string _revision;
    private readonly DateTime _lastChanged;

    public string Id
    {
      get
      {
        return this._id;
      }
    }

    public string Author
    {
      get
      {
        return this._author;
      }
    }

    public string FileName
    {
      get
      {
        return this._fileName;
      }
    }

    public object Revision
    {
      get
      {
        return (object) this._revision;
      }
    }

    public DateTime LastChanged
    {
      get
      {
        return this._lastChanged;
      }
    }

    public DateTime LastChangedUtc
    {
      get
      {
        return this._lastChanged.ToUniversalTime();
      }
    }

    public SccStamp(string id)
    {
      if (id == null)
        throw new ArgumentNullException("id");
      if (id.Length == 0)
        throw new ArgumentException((string) null, "id");
      Match match = SccStamp._regex.Match(id);
      if (!match.Success)
        throw new ArgumentException((string) null, "id");
      this._id = id;
      GroupCollection groups = match.Groups;
      this._fileName = groups["f"].Value;
      this._revision = groups["r"].Value;
      this._author = groups["a"].Value;
      this._lastChanged = new DateTime(int.Parse(groups["y"].Value), int.Parse(groups["mo"].Value), int.Parse(groups["d"].Value), int.Parse(groups["h"].Value), int.Parse(groups["mi"].Value), int.Parse(groups["s"].Value)).ToLocalTime();
    }

    public override string ToString()
    {
      return this.Id;
    }

    public static SccStamp[] FindAll(Assembly assembly)
    {
      if (assembly == null)
        throw new ArgumentNullException("assembly");
      SccAttribute[] customAttributes = (SccAttribute[]) Attribute.GetCustomAttributes(assembly, typeof (SccAttribute), false);
      if (customAttributes.Length == 0)
        return new SccStamp[0];
      ArrayList arrayList = new ArrayList(customAttributes.Length);
      foreach (SccAttribute sccAttribute in customAttributes)
      {
        string str = sccAttribute.Id.Trim();
        if (str.Length > 0 && string.Compare("$Id$", str, true, CultureInfo.InvariantCulture) != 0)
          arrayList.Add((object) new SccStamp(str));
      }
      return (SccStamp[]) arrayList.ToArray(typeof (SccStamp));
    }

    public static SccStamp FindLatest(Assembly assembly)
    {
      return SccStamp.FindLatest(SccStamp.FindAll(assembly));
    }

    public static SccStamp FindLatest(SccStamp[] stamps)
    {
      if (stamps == null)
        throw new ArgumentNullException("stamps");
      if (stamps.Length == 0)
        return (SccStamp) null;
      stamps = (SccStamp[]) stamps.Clone();
      SccStamp.SortByLastChanged(stamps, true);
      return stamps[0];
    }

    public static void SortByLastChanged(SccStamp[] stamps)
    {
      SccStamp.SortByLastChanged(stamps, false);
    }

    public static void SortByLastChanged(SccStamp[] stamps, bool descending)
    {
      IComparer comparer = (IComparer) new SccStamp.LastChangedComparer();
      if (descending)
        comparer = (IComparer) new ReverseComparer(comparer);
      Array.Sort((Array) stamps, comparer);
    }

    private sealed class LastChangedComparer : IComparer
    {
      public int Compare(object x, object y)
      {
        if (x == null && y == null)
          return 0;
        if (x == null)
          return -1;
        if (y == null)
          return 1;
        if (x.GetType() != y.GetType())
          throw new ArgumentException("Objects cannot be compared because their types do not match.");
        return SccStamp.LastChangedComparer.Compare((SccStamp) x, (SccStamp) y);
      }

      private static int Compare(SccStamp lhs, SccStamp rhs)
      {
        return lhs.LastChanged.CompareTo(rhs.LastChanged);
      }
    }
  }
}
