﻿// Decompiled with JetBrains decompiler
// Type: Elmah.ErrorLogPageFactory
// Assembly: Elmah, Version=1.2.14706.0, Culture=neutral, PublicKeyToken=null
// MVID: 6B433430-60BC-4287-8770-D3B3555B0D2B
// Assembly location: D:\Mata\transport-corp\trans-corp\transport-corp\App\Bin\Elmah.dll

using System;
using System.Collections;
using System.Globalization;
using System.Text;
using System.Web;

namespace Elmah
{
  public class ErrorLogPageFactory : IHttpHandlerFactory
  {
    private static readonly object _authorizationHandlersKey = new object();
    private static readonly IRequestAuthorizationHandler[] _zeroAuthorizationHandlers = new IRequestAuthorizationHandler[0];

    public virtual IHttpHandler GetHandler(HttpContext context, string requestType, string url, string pathTranslated)
    {
      IHttpHandler handler = ErrorLogPageFactory.FindHandler(context.Request.PathInfo.Length == 0 ? string.Empty : context.Request.PathInfo.Substring(1).ToLower(CultureInfo.InvariantCulture));
      if (handler == null)
        throw new HttpException(404, "Resource not found.");
      int num = ErrorLogPageFactory.IsAuthorized(context);
      if (num != 0 && (num >= 0 || HttpRequestSecurity.IsLocal(context.Request) || SecurityConfiguration.Default.AllowRemoteAccess))
        return handler;
      new ManifestResourceHandler("RemoteAccessError.htm", "text/html").ProcessRequest(context);
      HttpResponse response = context.Response;
      response.Status = "403 Forbidden";
      response.End();
      return (IHttpHandler) null;
    }

    private static IHttpHandler FindHandler(string name)
    {
      switch (name)
      {
        case "detail":
          return (IHttpHandler) new ErrorDetailPage();
        case "html":
          return (IHttpHandler) new ErrorHtmlPage();
        case "xml":
          return (IHttpHandler) new ErrorXmlHandler();
        case "json":
          return (IHttpHandler) new ErrorJsonHandler();
        case "rss":
          return (IHttpHandler) new ErrorRssHandler();
        case "digestrss":
          return (IHttpHandler) new ErrorDigestRssHandler();
        case "download":
          return (IHttpHandler) new ErrorLogDownloadHandler();
        case "stylesheet":
          return (IHttpHandler) new ManifestResourceHandler("ErrorLog.css", "text/css", Encoding.GetEncoding("Windows-1252"));
        case "test":
          throw new TestException();
        case "about":
          return (IHttpHandler) new AboutPage();
        default:
          if (name.Length != 0)
            return (IHttpHandler) null;
          return (IHttpHandler) new ErrorLogPage();
      }
    }

    public virtual void ReleaseHandler(IHttpHandler handler)
    {
    }

    private static int IsAuthorized(HttpContext context)
    {
      int num = -1;
      IEnumerator enumerator = ErrorLogPageFactory.GetAuthorizationHandlers(context).GetEnumerator();
      while (num != 0 && enumerator.MoveNext())
        num = ((IRequestAuthorizationHandler) enumerator.Current).Authorize(context) ? 1 : 0;
      return num;
    }

    private static IList GetAuthorizationHandlers(HttpContext context)
    {
      object authorizationHandlersKey = ErrorLogPageFactory._authorizationHandlersKey;
      IList list1 = (IList) context.Items[authorizationHandlersKey];
      if (list1 == null)
      {
        ArrayList arrayList = (ArrayList) null;
        HttpApplication applicationInstance = context.ApplicationInstance;
        if (applicationInstance is IRequestAuthorizationHandler)
        {
          arrayList = new ArrayList(4);
          arrayList.Add((object) applicationInstance);
        }
        foreach (IHttpModule module in (IEnumerable) HttpModuleRegistry.GetModules(applicationInstance))
        {
          if (module is IRequestAuthorizationHandler)
          {
            if (arrayList == null)
              arrayList = new ArrayList(4);
            arrayList.Add((object) module);
          }
        }
        IDictionary items = context.Items;
        object index = authorizationHandlersKey;
        Array array = arrayList != null ? arrayList.ToArray(typeof (IRequestAuthorizationHandler)) : (Array) ErrorLogPageFactory._zeroAuthorizationHandlers;
        IList list2;
        list1 = list2 = ArrayList.ReadOnly((IList) array);
        items[index] = (object) list2;
      }
      return list1;
    }

    internal static Uri GetRequestUrl(HttpContext context)
    {
      if (context == null)
        throw new ArgumentNullException("context");
      Uri uri = context.Items[(object) "ELMAH_REQUEST_URL"] as Uri;
      if (!(uri != (Uri) null))
        return context.Request.Url;
      return uri;
    }
  }
}
