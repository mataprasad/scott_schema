﻿// Decompiled with JetBrains decompiler
// Type: Elmah.ErrorLogEntry
// Assembly: Elmah, Version=1.2.14706.0, Culture=neutral, PublicKeyToken=null
// MVID: 6B433430-60BC-4287-8770-D3B3555B0D2B
// Assembly location: D:\Mata\transport-corp\trans-corp\transport-corp\App\Bin\Elmah.dll

using System;

namespace Elmah
{
  [Serializable]
  public class ErrorLogEntry
  {
    private readonly string _id;
    private readonly ErrorLog _log;
    private readonly Error _error;

    public ErrorLog Log
    {
      get
      {
        return this._log;
      }
    }

    public string Id
    {
      get
      {
        return this._id;
      }
    }

    public Error Error
    {
      get
      {
        return this._error;
      }
    }

    public ErrorLogEntry(ErrorLog log, string id, Error error)
    {
      if (log == null)
        throw new ArgumentNullException("log");
      if (id == null)
        throw new ArgumentNullException("id");
      if (id.Length == 0)
        throw new ArgumentException((string) null, "id");
      if (error == null)
        throw new ArgumentNullException("error");
      this._log = log;
      this._id = id;
      this._error = error;
    }
  }
}
