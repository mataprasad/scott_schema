﻿// Decompiled with JetBrains decompiler
// Type: Elmah.SynchronousAsyncResult
// Assembly: Elmah, Version=1.2.14706.0, Culture=neutral, PublicKeyToken=null
// MVID: 6B433430-60BC-4287-8770-D3B3555B0D2B
// Assembly location: D:\Mata\transport-corp\trans-corp\transport-corp\App\Bin\Elmah.dll

using System;
using System.Threading;

namespace Elmah
{
  internal sealed class SynchronousAsyncResult : IAsyncResult
  {
    private ManualResetEvent _waitHandle;
    private readonly string _syncMethodName;
    private readonly object _asyncState;
    private readonly object _result;
    private readonly Exception _exception;
    private bool _ended;

    public bool IsCompleted
    {
      get
      {
        return true;
      }
    }

    public WaitHandle AsyncWaitHandle
    {
      get
      {
        if (this._waitHandle == null)
          this._waitHandle = new ManualResetEvent(true);
        return (WaitHandle) this._waitHandle;
      }
    }

    public object AsyncState
    {
      get
      {
        return this._asyncState;
      }
    }

    public bool CompletedSynchronously
    {
      get
      {
        return true;
      }
    }

    private SynchronousAsyncResult(string syncMethodName, object asyncState, object result, Exception e)
    {
      this._syncMethodName = syncMethodName;
      this._asyncState = asyncState;
      this._result = result;
      this._exception = e;
    }

    public static SynchronousAsyncResult OnSuccess(string syncMethodName, object asyncState, object result)
    {
      return new SynchronousAsyncResult(syncMethodName, asyncState, result, (Exception) null);
    }

    public static SynchronousAsyncResult OnFailure(string syncMethodName, object asyncState, Exception e)
    {
      return new SynchronousAsyncResult(syncMethodName, asyncState, (object) null, e);
    }

    public object End()
    {
      if (this._ended)
        throw new InvalidOperationException(string.Format("End{0} can only be called once for each asynchronous operation.", (object) this._syncMethodName));
      this._ended = true;
      if (this._exception != null)
        throw this._exception;
      return this._result;
    }
  }
}
