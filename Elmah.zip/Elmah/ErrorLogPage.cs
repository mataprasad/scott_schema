﻿// Decompiled with JetBrains decompiler
// Type: Elmah.ErrorLogPage
// Assembly: Elmah, Version=1.2.14706.0, Culture=neutral, PublicKeyToken=null
// MVID: 6B433430-60BC-4287-8770-D3B3555B0D2B
// Assembly location: D:\Mata\transport-corp\trans-corp\transport-corp\App\Bin\Elmah.dll

using System;
using System.Collections;
using System.Globalization;
using System.IO;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Elmah
{
  internal sealed class ErrorLogPage : ErrorPageBase
  {
    private const int _defaultPageSize = 15;
    private const int _maximumPageSize = 100;
    private int _pageIndex;
    private int _pageSize;
    private int _totalCount;
    private ArrayList _errorEntryList;

    protected override void OnLoad(EventArgs e)
    {
      this._pageSize = Convert.ToInt32(this.Request.QueryString["size"], (IFormatProvider) CultureInfo.InvariantCulture);
      this._pageSize = Math.Min(100, Math.Max(0, this._pageSize));
      if (this._pageSize == 0)
        this._pageSize = 15;
      this._pageIndex = Convert.ToInt32(this.Request.QueryString["page"], (IFormatProvider) CultureInfo.InvariantCulture);
      this._pageIndex = Math.Max(1, this._pageIndex) - 1;
      this._errorEntryList = new ArrayList(this._pageSize);
      this._totalCount = this.ErrorLog.GetErrors(this._pageIndex, this._pageSize, (IList) this._errorEntryList);
      string machineName = Environment.TryGetMachineName(this.Context);
      this.PageTitle = string.Format(machineName.Length > 0 ? "Error log for {0} on {2} (Page #{1})" : "Error log for {0} (Page #{1})", (object) this.ApplicationName, (object) (this._pageIndex + 1).ToString("N0"), (object) machineName);
      base.OnLoad(e);
    }

    protected override void RenderHead(HtmlTextWriter writer)
    {
      if (writer == null)
        throw new ArgumentNullException("writer");
      base.RenderHead(writer);
      writer.AddAttribute(HtmlTextWriterAttribute.Rel, "alternate");
      writer.AddAttribute(HtmlTextWriterAttribute.Type, "application/rss+xml");
      writer.AddAttribute(HtmlTextWriterAttribute.Title, "RSS");
      writer.AddAttribute(HtmlTextWriterAttribute.Href, this.BasePageName + "/rss");
      writer.RenderBeginTag(HtmlTextWriterTag.Link);
      writer.RenderEndTag();
      writer.WriteLine();
      if (this._pageIndex != 0)
        return;
      writer.AddAttribute("http-equiv", "refresh");
      writer.AddAttribute("content", "60");
      writer.RenderBeginTag(HtmlTextWriterTag.Meta);
      writer.RenderEndTag();
      writer.WriteLine();
    }

    protected override void RenderContents(HtmlTextWriter writer)
    {
      if (writer == null)
        throw new ArgumentNullException("writer");
      this.RenderTitle(writer);
      SpeedBar.Render(writer, SpeedBar.RssFeed.Format(this.BasePageName), SpeedBar.RssDigestFeed.Format(this.BasePageName), SpeedBar.DownloadLog.Format(this.BasePageName), SpeedBar.Help, SpeedBar.About.Format(this.BasePageName));
      if (this._errorEntryList.Count != 0)
      {
        writer.RenderBeginTag(HtmlTextWriterTag.P);
        this.RenderStats(writer);
        this.RenderStockPageSizes(writer);
        writer.RenderEndTag();
        writer.WriteLine();
        this.RenderErrors(writer);
        this.RenderPageNavigators(writer);
      }
      else
        this.RenderNoErrors(writer);
      base.RenderContents(writer);
    }

    private void RenderPageNavigators(HtmlTextWriter writer)
    {
      writer.RenderBeginTag(HtmlTextWriterTag.P);
      int pageIndex = this._pageIndex + 1;
      bool flag = pageIndex * this._pageSize < this._totalCount;
      if (flag)
        this.RenderLinkToPage(writer, "next", "Next errors", pageIndex);
      if (this._pageIndex > 0 && this._totalCount > 0)
      {
        if (flag)
          writer.Write("; ");
        this.RenderLinkToPage(writer, "start", "Back to first page", 0);
      }
      writer.RenderEndTag();
      writer.WriteLine();
    }

    private void RenderStockPageSizes(HtmlTextWriter writer)
    {
      writer.Write("Start with ");
      int[] numArray = new int[7]{ 10, 15, 20, 25, 30, 50, 100 };
      for (int index = 0; index < numArray.Length; ++index)
      {
        int pageSize = numArray[index];
        if (index > 0)
          writer.Write(index + 1 < numArray.Length ? ", " : " or ");
        this.RenderLinkToPage(writer, "start", pageSize.ToString(), 0, pageSize);
      }
      writer.Write(" errors per page.");
    }

    private void RenderStats(HtmlTextWriter writer)
    {
      int num1 = this._pageIndex * this._pageSize + 1;
      int num2 = num1 + this._errorEntryList.Count - 1;
      int num3 = (int) Math.Ceiling((double) this._totalCount / (double) this._pageSize);
      writer.Write("Errors {0} to {1} of total {2} (page {3} of {4}). ", (object) num1.ToString("N0"), (object) num2.ToString("N0"), (object) this._totalCount.ToString("N0"), (object) (this._pageIndex + 1).ToString("N0"), (object) num3.ToString("N0"));
    }

    private void RenderTitle(HtmlTextWriter writer)
    {
      string str = this.ApplicationName;
      if (string.Compare(str, this.Request.ServerVariables["APPL_MD_PATH"], true, CultureInfo.InvariantCulture) == 0)
      {
        int num = str.LastIndexOf('/');
        if (num > 0)
          str = str.Substring(num + 1);
      }
      writer.AddAttribute(HtmlTextWriterAttribute.Id, "PageTitle");
      writer.RenderBeginTag(HtmlTextWriterTag.H1);
      writer.Write("Error Log for ");
      writer.AddAttribute(HtmlTextWriterAttribute.Id, "ApplicationName");
      writer.AddAttribute(HtmlTextWriterAttribute.Title, this.Server.HtmlEncode(this.ApplicationName));
      writer.RenderBeginTag(HtmlTextWriterTag.Span);
      this.Server.HtmlEncode(str, (TextWriter) writer);
      string machineName = Environment.TryGetMachineName(this.Context);
      if (machineName.Length > 0)
      {
        writer.Write(" on ");
        this.Server.HtmlEncode(machineName, (TextWriter) writer);
      }
      writer.RenderEndTag();
      writer.RenderEndTag();
      writer.WriteLine();
    }

    private void RenderNoErrors(HtmlTextWriter writer)
    {
      writer.RenderBeginTag(HtmlTextWriterTag.P);
      writer.Write("No errors found. ");
      if (this._pageIndex > 0 && this._totalCount > 0)
      {
        this.RenderLinkToPage(writer, "start", "Go to first page", 0);
        writer.Write(". ");
      }
      writer.RenderEndTag();
      writer.WriteLine();
    }

    private void RenderErrors(HtmlTextWriter writer)
    {
      Table table = new Table();
      table.ID = "ErrorLog";
      table.CellSpacing = 0;
      table.Rows.Add(new TableRow()
      {
        Cells = {
          this.FormatCell((TableCell) new TableHeaderCell(), "Host", "host-col"),
          this.FormatCell((TableCell) new TableHeaderCell(), "Code", "code-col"),
          this.FormatCell((TableCell) new TableHeaderCell(), "Type", "type-col"),
          this.FormatCell((TableCell) new TableHeaderCell(), "Error", "error-col"),
          this.FormatCell((TableCell) new TableHeaderCell(), "User", "user-col"),
          this.FormatCell((TableCell) new TableHeaderCell(), "Date", "date-col"),
          this.FormatCell((TableCell) new TableHeaderCell(), "Time", "time-col")
        }
      });
      for (int index = 0; index < this._errorEntryList.Count; ++index)
      {
        ErrorLogEntry errorEntry = (ErrorLogEntry) this._errorEntryList[index];
        Error error = errorEntry.Error;
        TableRow row = new TableRow();
        row.CssClass = index % 2 == 0 ? "even-row" : "odd-row";
        row.Cells.Add(this.FormatCell(new TableCell(), error.HostName, "host-col"));
        row.Cells.Add(this.FormatCell(new TableCell(), error.StatusCode.ToString(), "code-col", Mask.NullString(HttpWorkerRequest.GetStatusDescription(error.StatusCode))));
        row.Cells.Add(this.FormatCell(new TableCell(), ErrorDisplay.HumaneExceptionErrorType(error), "type-col", error.Type));
        TableCell cell = new TableCell();
        cell.CssClass = "error-col";
        Label label = new Label();
        label.Text = this.Server.HtmlEncode(error.Message);
        HyperLink hyperLink = new HyperLink();
        hyperLink.NavigateUrl = this.BasePageName + "/detail?id=" + HttpUtility.UrlEncode(errorEntry.Id);
        hyperLink.Text = "Details&hellip;";
        cell.Controls.Add((Control) label);
        cell.Controls.Add((Control) new LiteralControl(" "));
        cell.Controls.Add((Control) hyperLink);
        row.Cells.Add(cell);
        row.Cells.Add(this.FormatCell(new TableCell(), error.User, "user-col"));
        row.Cells.Add(this.FormatCell(new TableCell(), error.Time.ToShortDateString(), "date-col", error.Time.ToLongDateString()));
        row.Cells.Add(this.FormatCell(new TableCell(), error.Time.ToShortTimeString(), "time-col", error.Time.ToLongTimeString()));
        table.Rows.Add(row);
      }
      table.RenderControl(writer);
    }

    private TableCell FormatCell(TableCell cell, string contents, string cssClassName)
    {
      return this.FormatCell(cell, contents, cssClassName, string.Empty);
    }

    private TableCell FormatCell(TableCell cell, string contents, string cssClassName, string toolTip)
    {
      cell.Wrap = false;
      cell.CssClass = cssClassName;
      if (contents.Length == 0)
      {
        cell.Text = "&nbsp;";
      }
      else
      {
        string str = this.Server.HtmlEncode(contents);
        if (toolTip.Length == 0)
        {
          cell.Text = str;
        }
        else
        {
          Label label = new Label();
          label.ToolTip = toolTip;
          label.Text = str;
          cell.Controls.Add((Control) label);
        }
      }
      return cell;
    }

    private void RenderLinkToPage(HtmlTextWriter writer, string type, string text, int pageIndex)
    {
      this.RenderLinkToPage(writer, type, text, pageIndex, this._pageSize);
    }

    private void RenderLinkToPage(HtmlTextWriter writer, string type, string text, int pageIndex, int pageSize)
    {
      string str = string.Format("{0}?page={1}&size={2}", (object) this.BasePageName, (object) (pageIndex + 1).ToString((IFormatProvider) CultureInfo.InvariantCulture), (object) pageSize.ToString((IFormatProvider) CultureInfo.InvariantCulture));
      writer.AddAttribute(HtmlTextWriterAttribute.Href, str);
      if (type != null && type.Length > 0)
        writer.AddAttribute(HtmlTextWriterAttribute.Rel, type);
      writer.RenderBeginTag(HtmlTextWriterTag.A);
      this.Server.HtmlEncode(text, (TextWriter) writer);
      writer.RenderEndTag();
    }
  }
}
