﻿// Decompiled with JetBrains decompiler
// Type: Elmah.ErrorDetailPage
// Assembly: Elmah, Version=1.2.14706.0, Culture=neutral, PublicKeyToken=null
// MVID: 6B433430-60BC-4287-8770-D3B3555B0D2B
// Assembly location: D:\Mata\transport-corp\trans-corp\transport-corp\App\Bin\Elmah.dll

using System;
using System.Collections.Specialized;
using System.IO;
using System.Text.RegularExpressions;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Elmah
{
  internal sealed class ErrorDetailPage : ErrorPageBase
  {
    private static readonly Regex _reStackTrace = new Regex("\r\n                ^\r\n                \\s*\r\n                \\w+ \\s+ \r\n                (?<type> .+ ) \\.\r\n                (?<method> .+? ) \r\n                (?<params> \\( (?<params> .*? ) \\) )\r\n                ( \\s+ \r\n                \\w+ \\s+ \r\n                  (?<file> [a-z] \\: .+? ) \r\n                  \\: \\w+ \\s+ \r\n                  (?<line> [0-9]+ ) \\p{P}? )?\r\n                \\s*\r\n                $", RegexOptions.IgnoreCase | RegexOptions.Multiline | RegexOptions.ExplicitCapture | RegexOptions.Compiled | RegexOptions.IgnorePatternWhitespace | RegexOptions.CultureInvariant);
    private ErrorLogEntry _errorEntry;

    protected override void OnLoad(EventArgs e)
    {
      string id = Mask.NullString(this.Request.QueryString["id"]);
      if (id.Length == 0)
        return;
      this._errorEntry = this.ErrorLog.GetError(id);
      if (this._errorEntry == null)
      {
        this.Response.Status = HttpStatus.NotFound.ToString();
      }
      else
      {
        this.PageTitle = string.Format("Error: {0} [{1}]", (object) this._errorEntry.Error.Type, (object) this._errorEntry.Id);
        base.OnLoad(e);
      }
    }

    protected override void RenderContents(HtmlTextWriter writer)
    {
      if (writer == null)
        throw new ArgumentNullException("writer");
      if (this._errorEntry != null)
        this.RenderError(writer);
      else
        ErrorDetailPage.RenderNoError(writer);
    }

    private static void RenderNoError(HtmlTextWriter writer)
    {
      writer.RenderBeginTag(HtmlTextWriterTag.P);
      writer.Write("Error not found in log.");
      writer.RenderEndTag();
      writer.WriteLine();
    }

    private void RenderError(HtmlTextWriter writer)
    {
      Error error = this._errorEntry.Error;
      writer.AddAttribute(HtmlTextWriterAttribute.Id, "PageTitle");
      writer.RenderBeginTag(HtmlTextWriterTag.H1);
      this.HtmlEncode(error.Message, (TextWriter) writer);
      writer.RenderEndTag();
      writer.WriteLine();
      SpeedBar.Render(writer, SpeedBar.Home.Format(this.BasePageName), SpeedBar.Help, SpeedBar.About.Format(this.BasePageName));
      writer.AddAttribute(HtmlTextWriterAttribute.Id, "ErrorTitle");
      writer.RenderBeginTag(HtmlTextWriterTag.P);
      writer.AddAttribute(HtmlTextWriterAttribute.Id, "ErrorType");
      writer.RenderBeginTag(HtmlTextWriterTag.Span);
      this.HtmlEncode(error.Type, (TextWriter) writer);
      writer.RenderEndTag();
      writer.AddAttribute(HtmlTextWriterAttribute.Id, "ErrorTypeMessageSeparator");
      writer.RenderBeginTag(HtmlTextWriterTag.Span);
      writer.Write(": ");
      writer.RenderEndTag();
      writer.AddAttribute(HtmlTextWriterAttribute.Id, "ErrorMessage");
      writer.RenderBeginTag(HtmlTextWriterTag.Span);
      this.HtmlEncode(error.Message, (TextWriter) writer);
      writer.RenderEndTag();
      writer.RenderEndTag();
      writer.WriteLine();
      if (error.Detail.Length != 0)
      {
        writer.AddAttribute(HtmlTextWriterAttribute.Id, "ErrorDetail");
        writer.RenderBeginTag(HtmlTextWriterTag.Pre);
        writer.Flush();
        this.MarkupStackTrace(error.Detail, writer.InnerWriter);
        writer.RenderEndTag();
        writer.WriteLine();
      }
      writer.AddAttribute(HtmlTextWriterAttribute.Id, "ErrorLogTime");
      writer.RenderBeginTag(HtmlTextWriterTag.P);
      this.HtmlEncode(string.Format("Logged on {0} at {1}", (object) error.Time.ToLongDateString(), (object) error.Time.ToLongTimeString()), (TextWriter) writer);
      writer.RenderEndTag();
      writer.WriteLine();
      writer.RenderBeginTag(HtmlTextWriterTag.P);
      writer.Write("See also:");
      writer.RenderEndTag();
      writer.WriteLine();
      writer.RenderBeginTag(HtmlTextWriterTag.Ul);
      if (error.WebHostHtmlMessage.Length != 0)
      {
        writer.RenderBeginTag(HtmlTextWriterTag.Li);
        string str = this.BasePageName + "/html?id=" + HttpUtility.UrlEncode(this._errorEntry.Id);
        writer.AddAttribute(HtmlTextWriterAttribute.Href, str);
        writer.RenderBeginTag(HtmlTextWriterTag.A);
        writer.Write("Original ASP.NET error page");
        writer.RenderEndTag();
        writer.RenderEndTag();
      }
      writer.RenderBeginTag(HtmlTextWriterTag.Li);
      writer.Write("Raw/Source data in ");
      writer.AddAttribute(HtmlTextWriterAttribute.Href, "xml" + this.Request.Url.Query);
      writer.AddAttribute(HtmlTextWriterAttribute.Rel, "alternate");
      writer.AddAttribute(HtmlTextWriterAttribute.Type, "application/xml");
      writer.RenderBeginTag(HtmlTextWriterTag.A);
      writer.Write("XML");
      writer.RenderEndTag();
      writer.Write(" or in ");
      writer.AddAttribute(HtmlTextWriterAttribute.Href, "json" + this.Request.Url.Query);
      writer.AddAttribute(HtmlTextWriterAttribute.Rel, "alternate");
      writer.AddAttribute(HtmlTextWriterAttribute.Type, "application/json");
      writer.RenderBeginTag(HtmlTextWriterTag.A);
      writer.Write("JSON");
      writer.RenderEndTag();
      writer.RenderEndTag();
      writer.RenderEndTag();
      this.RenderCollection(writer, error.ServerVariables, "ServerVariables", "Server Variables");
      base.RenderContents(writer);
    }

    private void RenderCollection(HtmlTextWriter writer, NameValueCollection collection, string id, string title)
    {
      if (collection == null || collection.Count == 0)
        return;
      writer.AddAttribute(HtmlTextWriterAttribute.Id, id);
      writer.RenderBeginTag(HtmlTextWriterTag.Div);
      writer.AddAttribute(HtmlTextWriterAttribute.Class, "table-caption");
      writer.RenderBeginTag(HtmlTextWriterTag.P);
      this.HtmlEncode(title, (TextWriter) writer);
      writer.RenderEndTag();
      writer.WriteLine();
      writer.AddAttribute(HtmlTextWriterAttribute.Class, "scroll-view");
      writer.RenderBeginTag(HtmlTextWriterTag.Div);
      Table table = new Table();
      table.CellSpacing = 0;
      TableRow row1 = new TableRow();
      TableHeaderCell tableHeaderCell1 = new TableHeaderCell();
      tableHeaderCell1.Wrap = false;
      tableHeaderCell1.Text = "Name";
      tableHeaderCell1.CssClass = "name-col";
      row1.Cells.Add((TableCell) tableHeaderCell1);
      TableHeaderCell tableHeaderCell2 = new TableHeaderCell();
      tableHeaderCell2.Wrap = false;
      tableHeaderCell2.Text = "Value";
      tableHeaderCell2.CssClass = "value-col";
      row1.Cells.Add((TableCell) tableHeaderCell2);
      table.Rows.Add(row1);
      string[] allKeys = collection.AllKeys;
      InvariantStringArray.Sort(allKeys);
      for (int index = 0; index < allKeys.Length; ++index)
      {
        string text = allKeys[index];
        TableRow row2 = new TableRow();
        row2.CssClass = index % 2 == 0 ? "even-row" : "odd-row";
        TableCell cell1 = new TableCell();
        cell1.Text = this.HtmlEncode(text);
        cell1.CssClass = "key-col";
        row2.Cells.Add(cell1);
        TableCell cell2 = new TableCell();
        cell2.Text = this.HtmlEncode(collection[text]);
        cell2.CssClass = "value-col";
        row2.Cells.Add(cell2);
        table.Rows.Add(row2);
      }
      table.RenderControl(writer);
      writer.RenderEndTag();
      writer.WriteLine();
      writer.RenderEndTag();
      writer.WriteLine();
    }

    private void MarkupStackTrace(string text, TextWriter writer)
    {
      int startIndex = 0;
      foreach (Match match in ErrorDetailPage._reStackTrace.Matches(text))
      {
        this.HtmlEncode(text.Substring(startIndex, match.Index - startIndex), writer);
        this.MarkupStackFrame(text, match, writer);
        startIndex = match.Index + match.Length;
      }
      this.HtmlEncode(text.Substring(startIndex), writer);
    }

    private void MarkupStackFrame(string text, Match match, TextWriter writer)
    {
      int index1 = match.Index;
      GroupCollection groups = match.Groups;
      Group group1 = groups["type"];
      this.HtmlEncode(text.Substring(index1, group1.Index - index1), writer);
      int index2 = group1.Index;
      writer.Write("<span class='st-frame'>");
      int anchor1 = this.StackFrameSpan(text, index2, "st-type", group1, writer);
      int startIndex1 = this.StackFrameSpan(text, anchor1, "st-method", groups["method"], writer);
      Group group2 = groups["params"];
      this.HtmlEncode(text.Substring(startIndex1, group2.Index - startIndex1), writer);
      writer.Write("<span class='st-params'>(");
      int num1 = 0;
      string str1 = group2.Captures[0].Value;
      char[] chArray = new char[1]{ ',' };
      foreach (string str2 in str1.Split(chArray))
      {
        int length = str2.LastIndexOf(' ');
        if (length <= 0)
        {
          this.Span(writer, "st-param", str2.Trim());
        }
        else
        {
          if (num1++ > 0)
            writer.Write(", ");
          string str3 = str2.Substring(0, length).Trim();
          this.Span(writer, "st-param-type", str3);
          writer.Write(' ');
          string str4 = str2.Substring(length + 1).Trim();
          this.Span(writer, "st-param-name", str4);
        }
      }
      writer.Write(")</span>");
      int anchor2 = group2.Index + group2.Length;
      int anchor3 = this.StackFrameSpan(text, anchor2, "st-file", groups["file"], writer);
      int startIndex2 = this.StackFrameSpan(text, anchor3, "st-line", groups["line"], writer);
      writer.Write("</span>");
      int num2 = match.Index + match.Length;
      this.HtmlEncode(text.Substring(startIndex2, num2 - startIndex2), writer);
    }

    private int StackFrameSpan(string text, int anchor, string klass, Group group, TextWriter writer)
    {
      if (!group.Success)
        return anchor;
      return this.StackFrameSpan(text, anchor, klass, group.Value, group.Index, group.Length, writer);
    }

    private int StackFrameSpan(string text, int anchor, string klass, string value, int index, int length, TextWriter writer)
    {
      this.HtmlEncode(text.Substring(anchor, index - anchor), writer);
      this.Span(writer, klass, value);
      return index + length;
    }

    private void Span(TextWriter writer, string klass, string value)
    {
      writer.Write("<span class='");
      writer.Write(klass);
      writer.Write("'>");
      this.HtmlEncode(value, writer);
      writer.Write("</span>");
    }

    private string HtmlEncode(string text)
    {
      return this.Server.HtmlEncode(text);
    }

    private void HtmlEncode(string text, TextWriter writer)
    {
      this.Server.HtmlEncode(text, writer);
    }
  }
}
