﻿// Decompiled with JetBrains decompiler
// Type: Elmah.ExceptionFilterEventArgs
// Assembly: Elmah, Version=1.2.14706.0, Culture=neutral, PublicKeyToken=null
// MVID: 6B433430-60BC-4287-8770-D3B3555B0D2B
// Assembly location: D:\Mata\transport-corp\trans-corp\transport-corp\App\Bin\Elmah.dll

using System;

namespace Elmah
{
  [Serializable]
  public sealed class ExceptionFilterEventArgs : EventArgs
  {
    private readonly Exception _exception;
    [NonSerialized]
    private readonly object _context;
    private bool _dismissed;

    public Exception Exception
    {
      get
      {
        return this._exception;
      }
    }

    public object Context
    {
      get
      {
        return this._context;
      }
    }

    public bool Dismissed
    {
      get
      {
        return this._dismissed;
      }
    }

    public ExceptionFilterEventArgs(Exception e, object context)
    {
      if (e == null)
        throw new ArgumentNullException("e");
      this._exception = e;
      this._context = context;
    }

    public void Dismiss()
    {
      this._dismissed = true;
    }
  }
}
