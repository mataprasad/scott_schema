﻿// Decompiled with JetBrains decompiler
// Type: Elmah.ErrorMailEventArgs
// Assembly: Elmah, Version=1.2.14706.0, Culture=neutral, PublicKeyToken=null
// MVID: 6B433430-60BC-4287-8770-D3B3555B0D2B
// Assembly location: D:\Mata\transport-corp\trans-corp\transport-corp\App\Bin\Elmah.dll

using System;
using System.Net.Mail;

namespace Elmah
{
  public sealed class ErrorMailEventArgs : EventArgs
  {
    private readonly Error _error;
    private readonly MailMessage _mail;

    public Error Error
    {
      get
      {
        return this._error;
      }
    }

    public MailMessage Mail
    {
      get
      {
        return this._mail;
      }
    }

    public ErrorMailEventArgs(Error error, MailMessage mail)
    {
      if (error == null)
        throw new ArgumentNullException("error");
      if (mail == null)
        throw new ArgumentNullException("mail");
      this._error = error;
      this._mail = mail;
    }
  }
}
