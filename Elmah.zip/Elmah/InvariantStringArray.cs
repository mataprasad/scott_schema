﻿// Decompiled with JetBrains decompiler
// Type: Elmah.InvariantStringArray
// Assembly: Elmah, Version=1.2.14706.0, Culture=neutral, PublicKeyToken=null
// MVID: 6B433430-60BC-4287-8770-D3B3555B0D2B
// Assembly location: D:\Mata\transport-corp\trans-corp\transport-corp\App\Bin\Elmah.dll

using System;
using System.Collections;

namespace Elmah
{
  internal sealed class InvariantStringArray
  {
    private static IComparer InvariantComparer
    {
      get
      {
        return (IComparer) Comparer.DefaultInvariant;
      }
    }

    private InvariantStringArray()
    {
    }

    public static void Sort(string[] keys)
    {
      InvariantStringArray.Sort(keys, 0, keys.Length);
    }

    public static void Sort(string[] keys, int index, int length)
    {
      InvariantStringArray.Sort(keys, (Array) null, index, length);
    }

    public static void Sort(string[] keys, Array items, int index, int length)
    {
      Array.Sort((Array) keys, items, index, length, InvariantStringArray.InvariantComparer);
    }
  }
}
