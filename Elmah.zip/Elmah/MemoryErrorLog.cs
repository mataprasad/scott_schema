﻿// Decompiled with JetBrains decompiler
// Type: Elmah.MemoryErrorLog
// Assembly: Elmah, Version=1.2.14706.0, Culture=neutral, PublicKeyToken=null
// MVID: 6B433430-60BC-4287-8770-D3B3555B0D2B
// Assembly location: D:\Mata\transport-corp\trans-corp\transport-corp\App\Bin\Elmah.dll

using System;
using System.Collections;
using System.Collections.Specialized;
using System.Globalization;
using System.Threading;

namespace Elmah
{
  public sealed class MemoryErrorLog : ErrorLog
  {
    private static readonly ReaderWriterLock _lock = new ReaderWriterLock();
    public static readonly int MaximumSize = 500;
    public static readonly int DefaultSize = 15;
    private static MemoryErrorLog.EntryCollection _entries;
    private readonly int _size;

    public override string Name
    {
      get
      {
        return "In-Memory Error Log";
      }
    }

    public MemoryErrorLog()
      : this(MemoryErrorLog.DefaultSize)
    {
    }

    public MemoryErrorLog(int size)
    {
      if (size < 0 || size > MemoryErrorLog.MaximumSize)
        throw new ArgumentOutOfRangeException("size", (object) size, string.Format("Size must be between 0 and {0}.", (object) MemoryErrorLog.MaximumSize));
      this._size = size;
    }

    public MemoryErrorLog(IDictionary config)
    {
      if (config == null)
      {
        this._size = MemoryErrorLog.DefaultSize;
      }
      else
      {
        string str = Mask.NullString((string) config[(object) "size"]);
        if (str.Length == 0)
        {
          this._size = MemoryErrorLog.DefaultSize;
        }
        else
        {
          this._size = Convert.ToInt32(str, (IFormatProvider) CultureInfo.InvariantCulture);
          this._size = Math.Max(0, Math.Min(MemoryErrorLog.MaximumSize, this._size));
        }
      }
    }

    public override string Log(Error error)
    {
      if (error == null)
        throw new ArgumentNullException("error");
      error = (Error) ((ICloneable) error).Clone();
      error.ApplicationName = this.ApplicationName;
      Guid guid = Guid.NewGuid();
      ErrorLogEntry entry = new ErrorLogEntry((ErrorLog) this, guid.ToString(), error);
      MemoryErrorLog._lock.AcquireWriterLock(-1);
      try
      {
        if (MemoryErrorLog._entries == null)
          MemoryErrorLog._entries = new MemoryErrorLog.EntryCollection(this._size);
        MemoryErrorLog._entries.Add(entry);
      }
      finally
      {
        MemoryErrorLog._lock.ReleaseWriterLock();
      }
      return guid.ToString();
    }

    public override ErrorLogEntry GetError(string id)
    {
      MemoryErrorLog._lock.AcquireReaderLock(-1);
      ErrorLogEntry entry;
      try
      {
        if (MemoryErrorLog._entries == null)
          return (ErrorLogEntry) null;
        entry = MemoryErrorLog._entries[id];
      }
      finally
      {
        MemoryErrorLog._lock.ReleaseReaderLock();
      }
      if (entry == null)
        return (ErrorLogEntry) null;
      Error error = (Error) ((ICloneable) entry.Error).Clone();
      return new ErrorLogEntry((ErrorLog) this, entry.Id, error);
    }

    public override int GetErrors(int pageIndex, int pageSize, IList errorEntryList)
    {
      if (pageIndex < 0)
        throw new ArgumentOutOfRangeException("pageIndex", (object) pageIndex, (string) null);
      if (pageSize < 0)
        throw new ArgumentOutOfRangeException("pageSize", (object) pageSize, (string) null);
      ErrorLogEntry[] errorLogEntryArray = (ErrorLogEntry[]) null;
      MemoryErrorLog._lock.AcquireReaderLock(-1);
      int count;
      try
      {
        if (MemoryErrorLog._entries == null)
          return 0;
        count = MemoryErrorLog._entries.Count;
        int num1 = pageIndex * pageSize;
        int num2 = Math.Min(num1 + pageSize, count);
        int length = Math.Max(0, num2 - num1);
        if (length > 0)
        {
          errorLogEntryArray = new ErrorLogEntry[length];
          int num3 = num2;
          int num4 = 0;
          while (num3 > num1)
            errorLogEntryArray[num4++] = MemoryErrorLog._entries[--num3];
        }
      }
      finally
      {
        MemoryErrorLog._lock.ReleaseReaderLock();
      }
      if (errorEntryList != null && errorLogEntryArray != null)
      {
        foreach (ErrorLogEntry errorLogEntry in errorLogEntryArray)
        {
          Error error = (Error) ((ICloneable) errorLogEntry.Error).Clone();
          errorEntryList.Add((object) new ErrorLogEntry((ErrorLog) this, errorLogEntry.Id, error));
        }
      }
      return count;
    }

    private class EntryCollection : NameObjectCollectionBase
    {
      private readonly int _size;

      public ErrorLogEntry this[int index]
      {
        get
        {
          return (ErrorLogEntry) this.BaseGet(index);
        }
      }

      public ErrorLogEntry this[Guid id]
      {
        get
        {
          return (ErrorLogEntry) this.BaseGet(id.ToString());
        }
      }

      public ErrorLogEntry this[string id]
      {
        get
        {
          return this[new Guid(id)];
        }
      }

      public EntryCollection(int size)
        : base(size)
      {
        this._size = size;
      }

      public void Add(ErrorLogEntry entry)
      {
        if (this.Count == this._size)
          this.BaseRemoveAt(0);
        this.BaseAdd(entry.Id, (object) entry);
      }
    }
  }
}
