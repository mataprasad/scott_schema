﻿// Decompiled with JetBrains decompiler
// Type: Elmah.SqlServerCompactErrorLog
// Assembly: Elmah, Version=1.2.14706.0, Culture=neutral, PublicKeyToken=null
// MVID: 6B433430-60BC-4287-8770-D3B3555B0D2B
// Assembly location: D:\Mata\transport-corp\trans-corp\transport-corp\App\Bin\Elmah.dll

using System;
using System.Collections;
using System.Data;
using System.Data.SqlServerCe;
using System.IO;

namespace Elmah
{
  public class SqlServerCompactErrorLog : ErrorLog
  {
    private readonly string _connectionString;

    public override string Name
    {
      get
      {
        return "SQL Server Compact Error Log";
      }
    }

    public virtual string ConnectionString
    {
      get
      {
        return this._connectionString;
      }
    }

    public SqlServerCompactErrorLog(IDictionary config)
    {
      if (config == null)
        throw new ArgumentNullException("config");
      string connectionString = ConnectionStringHelper.GetConnectionString(config, true);
      if (connectionString.Length == 0)
        throw new ApplicationException("Connection string is missing for the SQL Server Compact error log.");
      this._connectionString = connectionString;
      this.InitializeDatabase();
      this.ApplicationName = Mask.NullString((string) config[(object) "applicationName"]);
    }

    public SqlServerCompactErrorLog(string connectionString)
    {
      if (connectionString == null)
        throw new ArgumentNullException("connectionString");
      if (connectionString.Length == 0)
        throw new ArgumentException((string) null, "connectionString");
      this._connectionString = ConnectionStringHelper.GetResolvedConnectionString(connectionString);
      this.InitializeDatabase();
    }

    private void InitializeDatabase()
    {
      if (File.Exists(ConnectionStringHelper.GetDataSourceFilePath(this.ConnectionString)))
        return;
      using (SqlCeEngine sqlCeEngine = new SqlCeEngine(this.ConnectionString))
        sqlCeEngine.CreateDatabase();
      using (SqlCeConnection sqlCeConnection = new SqlCeConnection(this.ConnectionString))
      {
        using (SqlCeCommand sqlCeCommand = new SqlCeCommand())
        {
          sqlCeConnection.Open();
          SqlCeTransaction sqlCeTransaction = sqlCeConnection.BeginTransaction();
          try
          {
            sqlCeCommand.Connection = sqlCeConnection;
            sqlCeCommand.Transaction = sqlCeTransaction;
            sqlCeCommand.CommandText = "\r\n                        SELECT TABLE_NAME FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'ELMAH_Error'";
            if (sqlCeCommand.ExecuteScalar() == null)
            {
              sqlCeCommand.CommandText = "\r\n                            CREATE TABLE ELMAH_Error (\r\n                                [ErrorId] UNIQUEIDENTIFIER NOT NULL PRIMARY KEY DEFAULT newid(),\r\n                                [Application] NVARCHAR(60) NOT NULL,\r\n                                [Host] NVARCHAR(50) NOT NULL,\r\n                                [Type] NVARCHAR(100) NOT NULL,\r\n                                [Source] NVARCHAR(60) NOT NULL,\r\n                                [Message] NVARCHAR(500) NOT NULL,\r\n                                [User] NVARCHAR(50) NOT NULL,\r\n                                [StatusCode] INT NOT NULL,\r\n                                [TimeUtc] DATETIME NOT NULL,\r\n                                [Sequence] INT IDENTITY (1, 1) NOT NULL,\r\n                                [AllXml] NTEXT NOT NULL\r\n                            )";
              sqlCeCommand.ExecuteNonQuery();
              sqlCeCommand.CommandText = "\r\n                            CREATE NONCLUSTERED INDEX [IX_Error_App_Time_Seq] ON [ELMAH_Error] \r\n                            (\r\n                                [Application]   ASC,\r\n                                [TimeUtc]       DESC,\r\n                                [Sequence]      DESC\r\n                            )";
              sqlCeCommand.ExecuteNonQuery();
            }
            sqlCeTransaction.Commit(CommitMode.Immediate);
          }
          catch (SqlCeException ex)
          {
            sqlCeTransaction.Rollback();
            throw;
          }
        }
      }
    }

    public override string Log(Error error)
    {
      if (error == null)
        throw new ArgumentNullException("error");
      string str = ErrorXml.EncodeString(error);
      Guid guid = Guid.NewGuid();
      using (SqlCeConnection connection = new SqlCeConnection(this.ConnectionString))
      {
        using (SqlCeCommand sqlCeCommand = new SqlCeCommand("\r\n                INSERT INTO ELMAH_Error (\r\n                    [ErrorId], [Application], [Host], \r\n                    [Type], [Source], [Message], [User], [StatusCode], \r\n                    [TimeUtc], [AllXml] )\r\n                VALUES (\r\n                    @ErrorId, @Application, @Host, \r\n                    @Type, @Source, @Message, @User, @StatusCode, \r\n                    @TimeUtc, @AllXml);", connection))
        {
          SqlCeParameterCollection parameters = sqlCeCommand.Parameters;
          parameters.Add("@ErrorId", SqlDbType.UniqueIdentifier).Value = (object) guid;
          parameters.Add("@Application", SqlDbType.NVarChar, 60).Value = (object) this.ApplicationName;
          parameters.Add("@Host", SqlDbType.NVarChar, 30).Value = (object) error.HostName;
          parameters.Add("@Type", SqlDbType.NVarChar, 100).Value = (object) error.Type;
          parameters.Add("@Source", SqlDbType.NVarChar, 60).Value = (object) error.Source;
          parameters.Add("@Message", SqlDbType.NVarChar, 500).Value = (object) error.Message;
          parameters.Add("@User", SqlDbType.NVarChar, 50).Value = (object) error.User;
          parameters.Add("@StatusCode", SqlDbType.Int).Value = (object) error.StatusCode;
          parameters.Add("@TimeUtc", SqlDbType.DateTime).Value = (object) error.Time.ToUniversalTime();
          parameters.Add("@AllXml", SqlDbType.NText).Value = (object) str;
          sqlCeCommand.Connection = connection;
          connection.Open();
          sqlCeCommand.ExecuteNonQuery();
          return guid.ToString();
        }
      }
    }

    public override int GetErrors(int pageIndex, int pageSize, IList errorEntryList)
    {
      if (pageIndex < 0)
        throw new ArgumentOutOfRangeException("pageIndex", (object) pageIndex, (string) null);
      if (pageSize < 0)
        throw new ArgumentOutOfRangeException("pageSize", (object) pageSize, (string) null);
      using (SqlCeConnection connection = new SqlCeConnection(this.ConnectionString))
      {
        connection.Open();
        using (SqlCeCommand sqlCeCommand = new SqlCeCommand("\r\n                SELECT\r\n                    [ErrorId],\r\n                    [Application],\r\n                    [Host],\r\n                    [Type],\r\n                    [Source],\r\n                    [Message],\r\n                    [User],\r\n                    [StatusCode],\r\n                    [TimeUtc]\r\n                FROM\r\n                    [ELMAH_Error]\r\n                ORDER BY\r\n                    [TimeUtc] DESC, \r\n                    [Sequence] DESC\r\n                OFFSET @PageSize * @PageIndex ROWS FETCH NEXT @PageSize ROWS ONLY;\r\n                ", connection))
        {
          SqlCeParameterCollection parameters = sqlCeCommand.Parameters;
          parameters.Add("@PageIndex", SqlDbType.Int).Value = (object) pageIndex;
          parameters.Add("@PageSize", SqlDbType.Int).Value = (object) pageSize;
          parameters.Add("@Application", SqlDbType.NVarChar, 60).Value = (object) this.ApplicationName;
          using (SqlCeDataReader sqlCeDataReader = sqlCeCommand.ExecuteReader())
          {
            if (errorEntryList != null)
            {
              while (sqlCeDataReader.Read())
              {
                string id = sqlCeDataReader["ErrorId"].ToString();
                errorEntryList.Add((object) new ErrorLogEntry((ErrorLog) this, id, new Error()
                {
                  ApplicationName = sqlCeDataReader["Application"].ToString(),
                  HostName = sqlCeDataReader["Host"].ToString(),
                  Type = sqlCeDataReader["Type"].ToString(),
                  Source = sqlCeDataReader["Source"].ToString(),
                  Message = sqlCeDataReader["Message"].ToString(),
                  User = sqlCeDataReader["User"].ToString(),
                  StatusCode = Convert.ToInt32(sqlCeDataReader["StatusCode"]),
                  Time = Convert.ToDateTime(sqlCeDataReader["TimeUtc"]).ToLocalTime()
                }));
              }
            }
          }
        }
        using (SqlCeCommand sqlCeCommand = new SqlCeCommand("\r\n                SELECT COUNT(*) FROM [ELMAH_Error]", connection))
          return (int) sqlCeCommand.ExecuteScalar();
      }
    }

    public override ErrorLogEntry GetError(string id)
    {
      if (id == null)
        throw new ArgumentNullException("id");
      if (id.Length == 0)
        throw new ArgumentException((string) null, "id");
      Guid guid;
      try
      {
        guid = new Guid(id);
      }
      catch (FormatException ex)
      {
        throw new ArgumentException(ex.Message, "id", (Exception) ex);
      }
      using (SqlCeConnection connection = new SqlCeConnection(this.ConnectionString))
      {
        using (SqlCeCommand sqlCeCommand = new SqlCeCommand("\r\n                SELECT \r\n                    [AllXml]\r\n                FROM \r\n                    [ELMAH_Error]\r\n                WHERE\r\n                    [ErrorId] = @ErrorId", connection))
        {
          sqlCeCommand.Parameters.Add("@ErrorId", SqlDbType.UniqueIdentifier).Value = (object) guid;
          connection.Open();
          string xml = (string) sqlCeCommand.ExecuteScalar();
          if (xml == null)
            return (ErrorLogEntry) null;
          Error error = ErrorXml.DecodeString(xml);
          return new ErrorLogEntry((ErrorLog) this, id, error);
        }
      }
    }
  }
}
