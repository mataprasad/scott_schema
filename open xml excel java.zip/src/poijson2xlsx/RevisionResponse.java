/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package poijson2xlsx;

import java.util.Date;

/**
 *
 * @author chauhan
 */
public class RevisionResponse {
    private String revId;
    private Date jcrCreated;

    /**
     * @return the revId
     */
    public String getRevId() {
        return revId;
    }

    /**
     * @param revId the revId to set
     */
    public void setRevId(String revId) {
        this.revId = revId;
    }

    /**
     * @return the jcrCreated
     */
    public Date getJcrCreated() {
        return jcrCreated;
    }

    /**
     * @param jcrCreated the jcrCreated to set
     */
    public void setJcrCreated(Date jcrCreated) {
        this.jcrCreated = jcrCreated;
    }
}
