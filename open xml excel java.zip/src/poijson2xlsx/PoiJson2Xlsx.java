/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package poijson2xlsx;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.Date;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;

/**
 *
 * @author chauhan
 */
public class PoiJson2Xlsx {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        String s="/Users/chauhan/Downloads/";
        //File f=new File(s);
        
        List<RevisionResponse> revList = new ArrayList<RevisionResponse>();
        for (int i = 0; i < 10; i++) {
           RevisionResponse a= new RevisionResponse();
           a.setJcrCreated(Date.valueOf(LocalDate.MAX));
           a.setRevId(""+i);
           revList.add(a);
        }
        
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd_hh_mm_ss");
        String excelFileName = s+"Revisions_" + formatter.format(LocalDateTime.now()) + ".xlsx";
        SXSSFWorkbook wb = (new ExportRevisionResponseExcel()).exportExcel(new String[] { "REVISION ID",
            "CREATION DATE" }, revList);
        
        
         try {
             FileOutputStream outputStream = new FileOutputStream(excelFileName);
            //ByteArrayOutputStream outByteStream = new ByteArrayOutputStream();
            wb.write(outputStream);
            //wb.write(f);
            //byte[] outArray = outByteStream.toByteArray();
            /*response.setContentType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
            response.setContentLength(outArray.length);
            response.setHeader("Expires:", "0"); // eliminates browser caching
            response.setHeader("Content-Disposition", "attachment; filename=" + excelFileName);
            OutputStream outStream = response.getOutputStream();
            outStream.write(outArray);
            outStream.flush();*/
            wb.dispose();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
}
